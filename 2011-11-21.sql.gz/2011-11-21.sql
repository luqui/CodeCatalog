--
-- PostgreSQL database dump
--

SET statement_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = off;
SET check_function_bodies = false;
SET client_min_messages = warning;
SET escape_string_warning = off;

SET search_path = public, pg_catalog;

SET default_tablespace = '';

SET default_with_oids = false;

--
-- Name: auth_group; Type: TABLE; Schema: public; Owner: codecatalog; Tablespace: 
--

CREATE TABLE auth_group (
    id integer NOT NULL,
    name character varying(80) NOT NULL
);


ALTER TABLE public.auth_group OWNER TO codecatalog;

--
-- Name: auth_group_id_seq; Type: SEQUENCE; Schema: public; Owner: codecatalog
--

CREATE SEQUENCE auth_group_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MAXVALUE
    NO MINVALUE
    CACHE 1;


ALTER TABLE public.auth_group_id_seq OWNER TO codecatalog;

--
-- Name: auth_group_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: codecatalog
--

ALTER SEQUENCE auth_group_id_seq OWNED BY auth_group.id;


--
-- Name: auth_group_id_seq; Type: SEQUENCE SET; Schema: public; Owner: codecatalog
--

SELECT pg_catalog.setval('auth_group_id_seq', 1, false);


--
-- Name: auth_group_permissions; Type: TABLE; Schema: public; Owner: codecatalog; Tablespace: 
--

CREATE TABLE auth_group_permissions (
    id integer NOT NULL,
    group_id integer NOT NULL,
    permission_id integer NOT NULL
);


ALTER TABLE public.auth_group_permissions OWNER TO codecatalog;

--
-- Name: auth_group_permissions_id_seq; Type: SEQUENCE; Schema: public; Owner: codecatalog
--

CREATE SEQUENCE auth_group_permissions_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MAXVALUE
    NO MINVALUE
    CACHE 1;


ALTER TABLE public.auth_group_permissions_id_seq OWNER TO codecatalog;

--
-- Name: auth_group_permissions_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: codecatalog
--

ALTER SEQUENCE auth_group_permissions_id_seq OWNED BY auth_group_permissions.id;


--
-- Name: auth_group_permissions_id_seq; Type: SEQUENCE SET; Schema: public; Owner: codecatalog
--

SELECT pg_catalog.setval('auth_group_permissions_id_seq', 1, false);


--
-- Name: auth_message; Type: TABLE; Schema: public; Owner: codecatalog; Tablespace: 
--

CREATE TABLE auth_message (
    id integer NOT NULL,
    user_id integer NOT NULL,
    message text NOT NULL
);


ALTER TABLE public.auth_message OWNER TO codecatalog;

--
-- Name: auth_message_id_seq; Type: SEQUENCE; Schema: public; Owner: codecatalog
--

CREATE SEQUENCE auth_message_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MAXVALUE
    NO MINVALUE
    CACHE 1;


ALTER TABLE public.auth_message_id_seq OWNER TO codecatalog;

--
-- Name: auth_message_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: codecatalog
--

ALTER SEQUENCE auth_message_id_seq OWNED BY auth_message.id;


--
-- Name: auth_message_id_seq; Type: SEQUENCE SET; Schema: public; Owner: codecatalog
--

SELECT pg_catalog.setval('auth_message_id_seq', 1, false);


--
-- Name: auth_permission; Type: TABLE; Schema: public; Owner: codecatalog; Tablespace: 
--

CREATE TABLE auth_permission (
    id integer NOT NULL,
    name character varying(50) NOT NULL,
    content_type_id integer NOT NULL,
    codename character varying(100) NOT NULL
);


ALTER TABLE public.auth_permission OWNER TO codecatalog;

--
-- Name: auth_permission_id_seq; Type: SEQUENCE; Schema: public; Owner: codecatalog
--

CREATE SEQUENCE auth_permission_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MAXVALUE
    NO MINVALUE
    CACHE 1;


ALTER TABLE public.auth_permission_id_seq OWNER TO codecatalog;

--
-- Name: auth_permission_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: codecatalog
--

ALTER SEQUENCE auth_permission_id_seq OWNED BY auth_permission.id;


--
-- Name: auth_permission_id_seq; Type: SEQUENCE SET; Schema: public; Owner: codecatalog
--

SELECT pg_catalog.setval('auth_permission_id_seq', 60, true);


--
-- Name: auth_user; Type: TABLE; Schema: public; Owner: codecatalog; Tablespace: 
--

CREATE TABLE auth_user (
    id integer NOT NULL,
    username character varying(30) NOT NULL,
    first_name character varying(30) NOT NULL,
    last_name character varying(30) NOT NULL,
    email character varying(75) NOT NULL,
    password character varying(128) NOT NULL,
    is_staff boolean NOT NULL,
    is_active boolean NOT NULL,
    is_superuser boolean NOT NULL,
    last_login timestamp with time zone NOT NULL,
    date_joined timestamp with time zone NOT NULL
);


ALTER TABLE public.auth_user OWNER TO codecatalog;

--
-- Name: auth_user_groups; Type: TABLE; Schema: public; Owner: codecatalog; Tablespace: 
--

CREATE TABLE auth_user_groups (
    id integer NOT NULL,
    user_id integer NOT NULL,
    group_id integer NOT NULL
);


ALTER TABLE public.auth_user_groups OWNER TO codecatalog;

--
-- Name: auth_user_groups_id_seq; Type: SEQUENCE; Schema: public; Owner: codecatalog
--

CREATE SEQUENCE auth_user_groups_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MAXVALUE
    NO MINVALUE
    CACHE 1;


ALTER TABLE public.auth_user_groups_id_seq OWNER TO codecatalog;

--
-- Name: auth_user_groups_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: codecatalog
--

ALTER SEQUENCE auth_user_groups_id_seq OWNED BY auth_user_groups.id;


--
-- Name: auth_user_groups_id_seq; Type: SEQUENCE SET; Schema: public; Owner: codecatalog
--

SELECT pg_catalog.setval('auth_user_groups_id_seq', 1, false);


--
-- Name: auth_user_id_seq; Type: SEQUENCE; Schema: public; Owner: codecatalog
--

CREATE SEQUENCE auth_user_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MAXVALUE
    NO MINVALUE
    CACHE 1;


ALTER TABLE public.auth_user_id_seq OWNER TO codecatalog;

--
-- Name: auth_user_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: codecatalog
--

ALTER SEQUENCE auth_user_id_seq OWNED BY auth_user.id;


--
-- Name: auth_user_id_seq; Type: SEQUENCE SET; Schema: public; Owner: codecatalog
--

SELECT pg_catalog.setval('auth_user_id_seq', 50, true);


--
-- Name: auth_user_user_permissions; Type: TABLE; Schema: public; Owner: codecatalog; Tablespace: 
--

CREATE TABLE auth_user_user_permissions (
    id integer NOT NULL,
    user_id integer NOT NULL,
    permission_id integer NOT NULL
);


ALTER TABLE public.auth_user_user_permissions OWNER TO codecatalog;

--
-- Name: auth_user_user_permissions_id_seq; Type: SEQUENCE; Schema: public; Owner: codecatalog
--

CREATE SEQUENCE auth_user_user_permissions_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MAXVALUE
    NO MINVALUE
    CACHE 1;


ALTER TABLE public.auth_user_user_permissions_id_seq OWNER TO codecatalog;

--
-- Name: auth_user_user_permissions_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: codecatalog
--

ALTER SEQUENCE auth_user_user_permissions_id_seq OWNED BY auth_user_user_permissions.id;


--
-- Name: auth_user_user_permissions_id_seq; Type: SEQUENCE SET; Schema: public; Owner: codecatalog
--

SELECT pg_catalog.setval('auth_user_user_permissions_id_seq', 1, false);


--
-- Name: django_content_type; Type: TABLE; Schema: public; Owner: codecatalog; Tablespace: 
--

CREATE TABLE django_content_type (
    id integer NOT NULL,
    name character varying(100) NOT NULL,
    app_label character varying(100) NOT NULL,
    model character varying(100) NOT NULL
);


ALTER TABLE public.django_content_type OWNER TO codecatalog;

--
-- Name: django_content_type_id_seq; Type: SEQUENCE; Schema: public; Owner: codecatalog
--

CREATE SEQUENCE django_content_type_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MAXVALUE
    NO MINVALUE
    CACHE 1;


ALTER TABLE public.django_content_type_id_seq OWNER TO codecatalog;

--
-- Name: django_content_type_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: codecatalog
--

ALTER SEQUENCE django_content_type_id_seq OWNED BY django_content_type.id;


--
-- Name: django_content_type_id_seq; Type: SEQUENCE SET; Schema: public; Owner: codecatalog
--

SELECT pg_catalog.setval('django_content_type_id_seq', 20, true);


--
-- Name: django_openid_auth_association; Type: TABLE; Schema: public; Owner: codecatalog; Tablespace: 
--

CREATE TABLE django_openid_auth_association (
    id integer NOT NULL,
    server_url text NOT NULL,
    handle character varying(255) NOT NULL,
    secret text NOT NULL,
    issued integer NOT NULL,
    lifetime integer NOT NULL,
    assoc_type text NOT NULL
);


ALTER TABLE public.django_openid_auth_association OWNER TO codecatalog;

--
-- Name: django_openid_auth_association_id_seq; Type: SEQUENCE; Schema: public; Owner: codecatalog
--

CREATE SEQUENCE django_openid_auth_association_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MAXVALUE
    NO MINVALUE
    CACHE 1;


ALTER TABLE public.django_openid_auth_association_id_seq OWNER TO codecatalog;

--
-- Name: django_openid_auth_association_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: codecatalog
--

ALTER SEQUENCE django_openid_auth_association_id_seq OWNED BY django_openid_auth_association.id;


--
-- Name: django_openid_auth_association_id_seq; Type: SEQUENCE SET; Schema: public; Owner: codecatalog
--

SELECT pg_catalog.setval('django_openid_auth_association_id_seq', 64, true);


--
-- Name: django_openid_auth_nonce; Type: TABLE; Schema: public; Owner: codecatalog; Tablespace: 
--

CREATE TABLE django_openid_auth_nonce (
    id integer NOT NULL,
    server_url character varying(2047) NOT NULL,
    "timestamp" integer NOT NULL,
    salt character varying(40) NOT NULL
);


ALTER TABLE public.django_openid_auth_nonce OWNER TO codecatalog;

--
-- Name: django_openid_auth_nonce_id_seq; Type: SEQUENCE; Schema: public; Owner: codecatalog
--

CREATE SEQUENCE django_openid_auth_nonce_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MAXVALUE
    NO MINVALUE
    CACHE 1;


ALTER TABLE public.django_openid_auth_nonce_id_seq OWNER TO codecatalog;

--
-- Name: django_openid_auth_nonce_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: codecatalog
--

ALTER SEQUENCE django_openid_auth_nonce_id_seq OWNED BY django_openid_auth_nonce.id;


--
-- Name: django_openid_auth_nonce_id_seq; Type: SEQUENCE SET; Schema: public; Owner: codecatalog
--

SELECT pg_catalog.setval('django_openid_auth_nonce_id_seq', 126, true);


--
-- Name: django_openid_auth_useropenid; Type: TABLE; Schema: public; Owner: codecatalog; Tablespace: 
--

CREATE TABLE django_openid_auth_useropenid (
    id integer NOT NULL,
    user_id integer NOT NULL,
    claimed_id text NOT NULL,
    display_id text NOT NULL
);


ALTER TABLE public.django_openid_auth_useropenid OWNER TO codecatalog;

--
-- Name: django_openid_auth_useropenid_id_seq; Type: SEQUENCE; Schema: public; Owner: codecatalog
--

CREATE SEQUENCE django_openid_auth_useropenid_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MAXVALUE
    NO MINVALUE
    CACHE 1;


ALTER TABLE public.django_openid_auth_useropenid_id_seq OWNER TO codecatalog;

--
-- Name: django_openid_auth_useropenid_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: codecatalog
--

ALTER SEQUENCE django_openid_auth_useropenid_id_seq OWNED BY django_openid_auth_useropenid.id;


--
-- Name: django_openid_auth_useropenid_id_seq; Type: SEQUENCE SET; Schema: public; Owner: codecatalog
--

SELECT pg_catalog.setval('django_openid_auth_useropenid_id_seq', 50, true);


--
-- Name: django_session; Type: TABLE; Schema: public; Owner: codecatalog; Tablespace: 
--

CREATE TABLE django_session (
    session_key character varying(40) NOT NULL,
    session_data text NOT NULL,
    expire_date timestamp with time zone NOT NULL
);


ALTER TABLE public.django_session OWNER TO codecatalog;

--
-- Name: django_site; Type: TABLE; Schema: public; Owner: codecatalog; Tablespace: 
--

CREATE TABLE django_site (
    id integer NOT NULL,
    domain character varying(100) NOT NULL,
    name character varying(50) NOT NULL
);


ALTER TABLE public.django_site OWNER TO codecatalog;

--
-- Name: django_site_id_seq; Type: SEQUENCE; Schema: public; Owner: codecatalog
--

CREATE SEQUENCE django_site_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MAXVALUE
    NO MINVALUE
    CACHE 1;


ALTER TABLE public.django_site_id_seq OWNER TO codecatalog;

--
-- Name: django_site_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: codecatalog
--

ALTER SEQUENCE django_site_id_seq OWNED BY django_site.id;


--
-- Name: django_site_id_seq; Type: SEQUENCE SET; Schema: public; Owner: codecatalog
--

SELECT pg_catalog.setval('django_site_id_seq', 1, true);


--
-- Name: south_migrationhistory; Type: TABLE; Schema: public; Owner: codecatalog; Tablespace: 
--

CREATE TABLE south_migrationhistory (
    id integer NOT NULL,
    app_name character varying(255) NOT NULL,
    migration character varying(255) NOT NULL,
    applied timestamp with time zone NOT NULL
);


ALTER TABLE public.south_migrationhistory OWNER TO codecatalog;

--
-- Name: south_migrationhistory_id_seq; Type: SEQUENCE; Schema: public; Owner: codecatalog
--

CREATE SEQUENCE south_migrationhistory_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MAXVALUE
    NO MINVALUE
    CACHE 1;


ALTER TABLE public.south_migrationhistory_id_seq OWNER TO codecatalog;

--
-- Name: south_migrationhistory_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: codecatalog
--

ALTER SEQUENCE south_migrationhistory_id_seq OWNED BY south_migrationhistory.id;


--
-- Name: south_migrationhistory_id_seq; Type: SEQUENCE SET; Schema: public; Owner: codecatalog
--

SELECT pg_catalog.setval('south_migrationhistory_id_seq', 14, true);


--
-- Name: zoo_bugreport; Type: TABLE; Schema: public; Owner: codecatalog; Tablespace: 
--

CREATE TABLE zoo_bugreport (
    status integer NOT NULL,
    target_versionptr_id integer NOT NULL,
    version_id integer NOT NULL,
    title text NOT NULL
);


ALTER TABLE public.zoo_bugreport OWNER TO codecatalog;

--
-- Name: zoo_dependency; Type: TABLE; Schema: public; Owner: codecatalog; Tablespace: 
--

CREATE TABLE zoo_dependency (
    id integer NOT NULL,
    snippet_id integer NOT NULL,
    target_id integer NOT NULL
);


ALTER TABLE public.zoo_dependency OWNER TO codecatalog;

--
-- Name: zoo_dependency_id_seq; Type: SEQUENCE; Schema: public; Owner: codecatalog
--

CREATE SEQUENCE zoo_dependency_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MAXVALUE
    NO MINVALUE
    CACHE 1;


ALTER TABLE public.zoo_dependency_id_seq OWNER TO codecatalog;

--
-- Name: zoo_dependency_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: codecatalog
--

ALTER SEQUENCE zoo_dependency_id_seq OWNED BY zoo_dependency.id;


--
-- Name: zoo_dependency_id_seq; Type: SEQUENCE SET; Schema: public; Owner: codecatalog
--

SELECT pg_catalog.setval('zoo_dependency_id_seq', 186, true);


--
-- Name: zoo_following; Type: TABLE; Schema: public; Owner: codecatalog; Tablespace: 
--

CREATE TABLE zoo_following (
    new_events boolean DEFAULT false NOT NULL,
    follower_id integer NOT NULL,
    followed_id integer NOT NULL,
    id integer NOT NULL,
    last_check timestamp with time zone NOT NULL
);


ALTER TABLE public.zoo_following OWNER TO codecatalog;

--
-- Name: zoo_following_id_seq; Type: SEQUENCE; Schema: public; Owner: codecatalog
--

CREATE SEQUENCE zoo_following_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MAXVALUE
    NO MINVALUE
    CACHE 1;


ALTER TABLE public.zoo_following_id_seq OWNER TO codecatalog;

--
-- Name: zoo_following_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: codecatalog
--

ALTER SEQUENCE zoo_following_id_seq OWNED BY zoo_following.id;


--
-- Name: zoo_following_id_seq; Type: SEQUENCE SET; Schema: public; Owner: codecatalog
--

SELECT pg_catalog.setval('zoo_following_id_seq', 412, true);


--
-- Name: zoo_snippet; Type: TABLE; Schema: public; Owner: codecatalog; Tablespace: 
--

CREATE TABLE zoo_snippet (
    code text NOT NULL,
    spec_versionptr_id integer NOT NULL,
    version_id integer NOT NULL,
    language text NOT NULL
);


ALTER TABLE public.zoo_snippet OWNER TO codecatalog;

--
-- Name: zoo_spec; Type: TABLE; Schema: public; Owner: codecatalog; Tablespace: 
--

CREATE TABLE zoo_spec (
    spec text NOT NULL,
    version_id integer NOT NULL,
    name character varying(64) NOT NULL,
    summary text NOT NULL,
    status integer NOT NULL
);


ALTER TABLE public.zoo_spec OWNER TO codecatalog;

--
-- Name: zoo_version; Type: TABLE; Schema: public; Owner: codecatalog; Tablespace: 
--

CREATE TABLE zoo_version (
    versionptr_id integer NOT NULL,
    "timestamp" timestamp with time zone NOT NULL,
    id integer NOT NULL,
    user_id integer,
    active boolean DEFAULT false NOT NULL,
    comment text NOT NULL,
    serial integer NOT NULL
);


ALTER TABLE public.zoo_version OWNER TO codecatalog;

--
-- Name: zoo_version_id_seq; Type: SEQUENCE; Schema: public; Owner: codecatalog
--

CREATE SEQUENCE zoo_version_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MAXVALUE
    NO MINVALUE
    CACHE 1;


ALTER TABLE public.zoo_version_id_seq OWNER TO codecatalog;

--
-- Name: zoo_version_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: codecatalog
--

ALTER SEQUENCE zoo_version_id_seq OWNED BY zoo_version.id;


--
-- Name: zoo_version_id_seq; Type: SEQUENCE SET; Schema: public; Owner: codecatalog
--

SELECT pg_catalog.setval('zoo_version_id_seq', 1167, true);


--
-- Name: zoo_versionptr; Type: TABLE; Schema: public; Owner: codecatalog; Tablespace: 
--

CREATE TABLE zoo_versionptr (
    id integer NOT NULL,
    type integer NOT NULL
);


ALTER TABLE public.zoo_versionptr OWNER TO codecatalog;

--
-- Name: zoo_versionptr_id_seq; Type: SEQUENCE; Schema: public; Owner: codecatalog
--

CREATE SEQUENCE zoo_versionptr_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MAXVALUE
    NO MINVALUE
    CACHE 1;


ALTER TABLE public.zoo_versionptr_id_seq OWNER TO codecatalog;

--
-- Name: zoo_versionptr_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: codecatalog
--

ALTER SEQUENCE zoo_versionptr_id_seq OWNED BY zoo_versionptr.id;


--
-- Name: zoo_versionptr_id_seq; Type: SEQUENCE SET; Schema: public; Owner: codecatalog
--

SELECT pg_catalog.setval('zoo_versionptr_id_seq', 435, true);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: codecatalog
--

ALTER TABLE auth_group ALTER COLUMN id SET DEFAULT nextval('auth_group_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: codecatalog
--

ALTER TABLE auth_group_permissions ALTER COLUMN id SET DEFAULT nextval('auth_group_permissions_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: codecatalog
--

ALTER TABLE auth_message ALTER COLUMN id SET DEFAULT nextval('auth_message_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: codecatalog
--

ALTER TABLE auth_permission ALTER COLUMN id SET DEFAULT nextval('auth_permission_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: codecatalog
--

ALTER TABLE auth_user ALTER COLUMN id SET DEFAULT nextval('auth_user_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: codecatalog
--

ALTER TABLE auth_user_groups ALTER COLUMN id SET DEFAULT nextval('auth_user_groups_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: codecatalog
--

ALTER TABLE auth_user_user_permissions ALTER COLUMN id SET DEFAULT nextval('auth_user_user_permissions_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: codecatalog
--

ALTER TABLE django_content_type ALTER COLUMN id SET DEFAULT nextval('django_content_type_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: codecatalog
--

ALTER TABLE django_openid_auth_association ALTER COLUMN id SET DEFAULT nextval('django_openid_auth_association_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: codecatalog
--

ALTER TABLE django_openid_auth_nonce ALTER COLUMN id SET DEFAULT nextval('django_openid_auth_nonce_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: codecatalog
--

ALTER TABLE django_openid_auth_useropenid ALTER COLUMN id SET DEFAULT nextval('django_openid_auth_useropenid_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: codecatalog
--

ALTER TABLE django_site ALTER COLUMN id SET DEFAULT nextval('django_site_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: codecatalog
--

ALTER TABLE south_migrationhistory ALTER COLUMN id SET DEFAULT nextval('south_migrationhistory_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: codecatalog
--

ALTER TABLE zoo_dependency ALTER COLUMN id SET DEFAULT nextval('zoo_dependency_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: codecatalog
--

ALTER TABLE zoo_following ALTER COLUMN id SET DEFAULT nextval('zoo_following_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: codecatalog
--

ALTER TABLE zoo_version ALTER COLUMN id SET DEFAULT nextval('zoo_version_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: codecatalog
--

ALTER TABLE zoo_versionptr ALTER COLUMN id SET DEFAULT nextval('zoo_versionptr_id_seq'::regclass);


--
-- Data for Name: auth_group; Type: TABLE DATA; Schema: public; Owner: codecatalog
--

COPY auth_group (id, name) FROM stdin;
\.


--
-- Data for Name: auth_group_permissions; Type: TABLE DATA; Schema: public; Owner: codecatalog
--

COPY auth_group_permissions (id, group_id, permission_id) FROM stdin;
\.


--
-- Data for Name: auth_message; Type: TABLE DATA; Schema: public; Owner: codecatalog
--

COPY auth_message (id, user_id, message) FROM stdin;
\.


--
-- Data for Name: auth_permission; Type: TABLE DATA; Schema: public; Owner: codecatalog
--

COPY auth_permission (id, name, content_type_id, codename) FROM stdin;
1	Can add permission	1	add_permission
2	Can change permission	1	change_permission
3	Can delete permission	1	delete_permission
4	Can add group	2	add_group
5	Can change group	2	change_group
6	Can delete group	2	delete_group
7	Can add user	3	add_user
8	Can change user	3	change_user
9	Can delete user	3	delete_user
10	Can add message	4	add_message
11	Can change message	4	change_message
12	Can delete message	4	delete_message
13	Can add content type	5	add_contenttype
14	Can change content type	5	change_contenttype
15	Can delete content type	5	delete_contenttype
16	Can add session	6	add_session
17	Can change session	6	change_session
18	Can delete session	6	delete_session
19	Can add site	7	add_site
20	Can change site	7	change_site
21	Can delete site	7	delete_site
22	Can add nonce	8	add_nonce
23	Can change nonce	8	change_nonce
24	Can delete nonce	8	delete_nonce
25	Can add association	9	add_association
26	Can change association	9	change_association
27	Can delete association	9	delete_association
28	Can add user open id	10	add_useropenid
29	Can change user open id	10	change_useropenid
30	Can delete user open id	10	delete_useropenid
31	Can add migration history	11	add_migrationhistory
32	Can change migration history	11	change_migrationhistory
33	Can delete migration history	11	delete_migrationhistory
34	Can add version ptr	12	add_versionptr
35	Can change version ptr	12	change_versionptr
36	Can delete version ptr	12	delete_versionptr
37	Can add version	13	add_version
38	Can change version	13	change_version
39	Can delete version	13	delete_version
40	Can add spec	14	add_spec
41	Can change spec	14	change_spec
42	Can delete spec	14	delete_spec
43	Can add snippet	15	add_snippet
44	Can change snippet	15	change_snippet
45	Can delete snippet	15	delete_snippet
46	Can add vote	16	add_vote
47	Can change vote	16	change_vote
48	Can delete vote	16	delete_vote
49	Can add dependency	17	add_dependency
50	Can change dependency	17	change_dependency
51	Can delete dependency	17	delete_dependency
55	Can add bug report	19	add_bugreport
56	Can change bug report	19	change_bugreport
57	Can delete bug report	19	delete_bugreport
58	Can add following	20	add_following
59	Can change following	20	change_following
60	Can delete following	20	delete_following
\.


--
-- Data for Name: auth_user; Type: TABLE DATA; Schema: public; Owner: codecatalog
--

COPY auth_user (id, username, first_name, last_name, email, password, is_staff, is_active, is_superuser, last_login, date_joined) FROM stdin;
3	Max	Max	Rebuschatis	rebodude@gmail.com	!	f	t	f	2011-03-29 09:59:53.211511+00	2011-03-29 09:59:53.182321+00
4	openiduser	Luke	Palmer	lrpalmer@gmail.com	!	f	t	f	2011-03-29 12:13:48.189633+00	2011-03-29 12:13:48.143472+00
19	Vincent	Vincent	Vazzo	vincent.vazzo@gmail.com	!	f	t	f	2011-04-20 15:28:59.697482+00	2011-04-20 15:28:59.679711+00
5	mathnerd314	Mathnerd	314	mathnerd314.gph@gmail.com	sha1$47c2e$a4e65bb24dfe86a2af4e2b68a35c79f7b8d425f1	f	t	f	2011-04-20 02:37:51.841985+00	2011-04-20 02:37:51.825104+00
20	cadetZemm	Ryan	Arana	ryan.arana@gmail.com	!	f	t	f	2011-04-20 17:14:40.388628+00	2011-04-20 17:14:40.368334+00
6	iconjack	Jack	Kennedy	iconjack@gmail.com	!	f	t	f	2011-04-20 03:34:43.865287+00	2011-04-20 03:34:43.846398+00
7	wgd	Will	Donnelly	will.donnelly@gmail.com	sha1$8fe7c$bfe2efe383b7322002cb861e5ad16e941b647bb1	f	t	f	2011-04-20 03:43:25.193438+00	2011-04-20 03:43:25.175448+00
21	kj	Kevin	Johns	kevin.johns@gmail.com	!	f	t	f	2011-04-20 17:20:26.889605+00	2011-04-20 17:20:26.871216+00
8	openiduser2	Aaron	Culich	aculich@gmail.com	!	f	t	f	2011-04-20 04:01:32.011355+00	2011-04-20 04:01:31.991058+00
9	d	Dan	Haffey	dhaffey@gmail.com	!	f	t	f	2011-04-20 05:18:34.739942+00	2011-04-20 05:18:34.724053+00
22	pjz	Paul	Jimenez	pjimenez3@gmail.com	!	f	t	f	2011-04-20 18:37:49.778863+00	2011-04-20 18:37:49.761587+00
10	openiduser3	David	Waern	david.waern@gmail.com	!	f	t	f	2011-04-20 06:43:34.438467+00	2011-04-20 06:43:34.422319+00
11	openiduser4	José A.	Alonso	josea.alonso@gmail.com	!	f	t	f	2011-04-20 06:48:35.57172+00	2011-04-20 06:48:35.555132+00
12	openiduser5			e@lefant.net	!	f	t	f	2011-04-20 09:27:09.255644+00	2011-04-20 09:27:09.234505+00
24	ncwhitehead	Nicole	Whitehead	ncwhitehead@gmail.com	!	f	t	f	2011-04-21 00:02:46.701639+00	2011-04-20 22:52:03.805931+00
15	joerisamson	Joeri	Samson	joerisamson@gmail.com	!	f	t	f	2011-04-20 10:44:55.521033+00	2011-04-20 10:44:55.505616+00
18	vilhelm_s				!	f	t	f	2011-04-21 02:29:09.562778+00	2011-04-20 14:26:16.013035+00
16	openiduser7	Shae	Erisson	shae.erisson@gmail.com	!	f	t	f	2011-04-20 14:12:55.807096+00	2011-04-20 14:12:55.698915+00
25	Blorgbeard		Blorgbeard		!	f	t	f	2011-04-21 07:17:21.440631+00	2011-04-21 07:17:21.423635+00
17	wizzard	Oleksandr	Nikitin	wizzard0@gmail.com	!	f	t	f	2011-04-20 14:13:39.675944+00	2011-04-20 14:13:39.659912+00
37	openiduser12	Sean	Duckett	sduckett@gmail.com	!	f	t	f	2011-05-27 19:02:14.366418+00	2011-05-27 19:02:14.329576+00
44	tonyg	Tony	Garnock-Jones	tonygarnockjones@gmail.com	sha1$48fff$507f9c8a92ed0f177defb38c89e5de4e3e10948e	f	t	f	2011-07-01 16:31:16.050918+00	2011-07-01 16:31:16.019836+00
46	openiduser18	Vilhelm	Sjöberg	vilhelm.sjoberg@gmail.com	!	f	t	f	2011-07-19 05:17:00.165157+00	2011-07-19 05:17:00.107771+00
26	cruhland	Charles	Ruhland	cruhland@gmail.com	!	f	t	f	2011-04-28 05:43:45.182919+00	2011-04-22 05:51:34.506152+00
31	openiduser9	Grant	Weyburne	weyburne@gmail.com	!	f	t	f	2011-04-29 00:04:09.667445+00	2011-04-29 00:04:09.623619+00
38	Refactor				sha1$3461f$e0c201227e2eda3202758b6c86ba8bc17310f082	f	t	f	2011-05-29 18:37:34.889434+00	2011-05-29 18:37:34.840584+00
49	openiduser20	Alexander	Ivanov	alehander42@gmail.com	sha1$daa63$54d59d9c6e23661bd4249b0f147ada3150728566	f	t	f	2011-08-29 09:55:40.951199+00	2011-08-29 09:47:52.085022+00
45	openiduser17	Ivan	Vodišek	ivanvodisek@gmail.com	!	f	t	f	2011-07-01 21:32:25.397193+00	2011-07-01 21:32:25.360314+00
34	openiduser8	Kirmoar	Kirmoar	kirmoar@googlemail.com	!	f	t	f	2011-05-21 19:18:42.672671+00	2011-05-21 19:18:42.640382+00
28	addmoreice	Arthur	Ice	arthuri@predator-software.com	sha1$35ca7$bda7aba3e9ae874a3f3ec7f31accaaa2ace45323	f	t	f	2011-04-22 16:18:46.147108+00	2011-04-22 16:18:46.100266+00
29	Landei	Daniel	Gronau	danielgronau@googlemail.com	!	f	t	f	2011-09-13 07:58:55.421316+00	2011-04-27 07:29:06.627987+00
35	openiduser11	Wesley	Massuda	wesley.massuda@gmail.com	!	f	t	f	2011-05-22 00:19:36.015443+00	2011-05-22 00:18:36.010574+00
13	voided	Account	Closed	noreply@google.com	!	f	t	f	2011-05-07 08:06:52.558681+00	2011-04-20 10:07:57.286628+00
1	luqui	Luke	Palmer	lrpalmer@gmail.com	sha1$039a1$6454f1d53b7c42fe160d566c58d61248d1996d99	f	t	f	2011-07-08 08:30:18.078706+00	2011-03-26 08:50:20.639527+00
42	joshhead	Joshua	Headapohl	joshhead@gmail.com	!	f	t	f	2011-06-30 02:25:30.193382+00	2011-06-30 02:25:30.106532+00
14	Grzegorz	Grzegorz	Chrupała	pitekus@gmail.com	!	f	t	f	2011-05-23 13:06:54.812132+00	2011-04-20 10:43:11.357785+00
32	openiduser10	yi	huang	yi.codeplayer@gmail.com	!	f	t	f	2011-05-10 15:08:52.166413+00	2011-05-10 15:08:52.125129+00
39	openiduser13	Giovanni	Ruggiero	giovanni.ruggiero@gmail.com	!	f	t	f	2011-06-11 21:41:41.214929+00	2011-06-11 21:41:41.167839+00
30	ichor	Haakon	Gylterud	ichor88@gmail.com	!	f	t	f	2011-07-27 10:28:32.52575+00	2011-04-27 19:24:27.496215+00
23	andrew.radev	Андрей	Радев	andrey.radev@gmail.com	!	f	t	f	2011-05-24 12:02:47.222164+00	2011-04-20 21:00:40.662132+00
36	openiduser6	H	B	hbemail@gmail.com	!	f	t	f	2011-05-25 13:10:12.855172+00	2011-05-25 13:10:12.797165+00
47	openiduser19	Hayden	Cacace	hacacace@gmail.com	!	f	t	f	2011-08-19 23:03:55.320915+00	2011-08-19 23:03:55.165092+00
40	openiduser14	Zohar	Kelrich	lumimies@gmail.com	!	f	t	f	2011-06-16 08:11:17.998229+00	2011-06-16 08:11:17.955523+00
27	projedi	Alexander	Shabalin	projedi666@gmail.com	!	f	t	f	2011-07-08 20:48:41.931046+00	2011-04-22 06:58:13.628293+00
43	openiduser16	Jord	Schneijdenberg	jschneijdenberg@gmail.com	!	f	t	f	2011-06-30 22:51:49.036218+00	2011-06-30 22:51:34.037812+00
33	epsilonhalbe	Martin	Heuschober	epsilonhalbe@gmail.com	!	f	t	f	2011-07-10 17:07:08.213055+00	2011-05-19 21:42:43.491415+00
50	openiduser21	JD	Marrow	jd.marrow@q2creative.com	!	f	t	f	2011-09-14 17:40:02.247018+00	2011-09-14 17:40:01.915474+00
2	max	Max	Rebuschatis	rebodude@gmail.com	sha1$e3f04$d821cd238bfcc8774aa520a08aea759d1716b0eb	f	t	f	2011-07-13 06:28:40.698014+00	2011-03-29 06:38:09.427644+00
48	vincentbuck	Vincent	Buck	info@vincentbuck.com	!	f	t	f	2011-08-21 14:20:08.528793+00	2011-08-21 14:20:08.480355+00
41	openiduser15	Abram	Demski	abramdemski@gmail.com	!	f	t	f	2011-10-12 18:20:29.988224+00	2011-06-29 23:37:33.70667+00
\.


--
-- Data for Name: auth_user_groups; Type: TABLE DATA; Schema: public; Owner: codecatalog
--

COPY auth_user_groups (id, user_id, group_id) FROM stdin;
\.


--
-- Data for Name: auth_user_user_permissions; Type: TABLE DATA; Schema: public; Owner: codecatalog
--

COPY auth_user_user_permissions (id, user_id, permission_id) FROM stdin;
\.


--
-- Data for Name: django_content_type; Type: TABLE DATA; Schema: public; Owner: codecatalog
--

COPY django_content_type (id, name, app_label, model) FROM stdin;
1	permission	auth	permission
2	group	auth	group
3	user	auth	user
4	message	auth	message
5	content type	contenttypes	contenttype
6	session	sessions	session
7	site	sites	site
8	nonce	django_openid_auth	nonce
9	association	django_openid_auth	association
10	user open id	django_openid_auth	useropenid
11	migration history	south	migrationhistory
12	version ptr	zoo	versionptr
13	version	zoo	version
14	spec	zoo	spec
15	snippet	zoo	snippet
16	vote	zoo	vote
17	dependency	zoo	dependency
19	bug report	zoo	bugreport
20	following	zoo	following
\.


--
-- Data for Name: django_openid_auth_association; Type: TABLE DATA; Schema: public; Owner: codecatalog
--

COPY django_openid_auth_association (id, server_url, handle, secret, issued, lifetime, assoc_type) FROM stdin;
7	http://www.myopenid.com/server	{HMAC-SHA1}{4daea6d0}{ozpy2A==}	1FFjCfZDG/hxg3UouLSwSeSm27U=\n	1303291600	1209600	HMAC-SHA1
8	https://www.google.com/accounts/o8/ud?source=profiles	AOQobUcgeOFEzBiz7nlNMvX13HKqrqpJaScT0oplpleE_VMMN0dgFnw8	KZoO6SXY4KUMIsGRzxWyWLolibM=\n	1303308766	46800	HMAC-SHA1
9	http://www.livejournal.com/openid/server.bml	1303309448:pqzjNOBYqTZFmtchB0Ds:5877e60fc0	HD7xVePwaXwS8VgoBKt02GmuyaY=\n	1303309465	1208152	HMAC-SHA1
15	http://wordpress.com/?openidserver=1	{HMAC-SHA1}{4db1991f}{opdsyw==}	OtgZX+zgTFb2RlrnTClriNlI7xY=\n	1303484703	1209600	HMAC-SHA1
48	http://lukepalmer.wordpress.com/?openidserver=1	{HMAC-SHA1}{4e16c014}{ZfYJrA==}	otUtuTX1L4BBMNYaNH5dPkjsKbo=\n	1310113812	1209600	HMAC-SHA1
58	https://open.login.yahooapis.com/openid/op/auth	qG43xJCcFvm2xZT3gGKJd2n3X7EStZIWRD6cSfmQ1RGsKi3jpaNZSLLMkjOJ0hSItrjH8SIqzluelD.HMJPMAhCAQH3JBDnLY0w9KcgeTW4DLtiKlLgaYaUTxokLMF952Q--	h6qLosL/ZNZgYo+qkfwXpzrtPGI=\n	1313936344	14400	HMAC-SHA1
59	http://pip.verisignlabs.com/server	97f00230-cc00-11e0-87fb-d11724faaf02	qcMFLTfzj7XqzpWnEiH+v5HwLmI=\n	1313936374	600	HMAC-SHA1
64	https://www.google.com/accounts/o8/ud	AOQobUcq6lNGyoZAGpkJSh3wqbEM-FWP2NojfJ-XlKyrl-rtymTvYCNk	5xH5pl3xpSe0/26MtWnF4o2EJ8Y=\n	1318443539	46800	HMAC-SHA1
\.


--
-- Data for Name: django_openid_auth_nonce; Type: TABLE DATA; Schema: public; Owner: codecatalog
--

COPY django_openid_auth_nonce (id, server_url, "timestamp", salt) FROM stdin;
1		1301129416	3dlg9J
2		1301228791	CRMpQx
3		1301228819	D9cEHB
4		1301289042	f48qux
5	https://www.google.com/accounts/o8/ud	1301380688	PFu07_wZ52ylFg
6	https://www.google.com/accounts/o8/ud	1301392792	dbWQ_aMjgSuN4Q
7	https://www.google.com/accounts/o8/ud?source=profiles	1301400827	uf0GPF5zwQkUHQ
8		1301409988	ohwsg8
9		1301418902	ACDc5b
10		1301440779	uLrmrz
11		1301673763	qRzMCj
12		1301674263	eLtWEr
13		1301970332	qY0ed4
14		1302077242	I7nrgX
15		1302078214	eFITuR
16		1302198315	nHbnDn
17	https://www.google.com/accounts/o8/ud	1303103288	ett7gL6eTy-QnA
18		1303263175	5ReO2J
19	https://www.google.com/accounts/o8/ud	1303267070	_vS4G4Gp51p4Cg
20	https://www.google.com/accounts/o8/ud	1303270482	zSC2sfDXkpn1IQ
21	https://www.google.com/accounts/o8/ud	1303271004	S9LKtiClACU_4Q
22	https://www.google.com/accounts/o8/ud	1303272091	gWXG0eJpexQxRw
23	https://www.google.com/accounts/o8/ud	1303276713	TSB-XPiklCFaoQ
24	https://www.google.com/accounts/o8/ud	1303281813	7p5K_ZWL66qPJg
25	https://www.google.com/accounts/o8/ud	1303282111	-5gWHiGbZM4JKQ
26	http://www.myopenid.com/server	1303291628	kJ1upg
27	https://www.google.com/accounts/o8/ud	1303294076	phaNcsYo9YEEpA
28	https://www.google.com/accounts/o8/ud	1303296190	DJrUVaV1Pyxahw
29	https://www.google.com/accounts/o8/ud	1303296294	fVQ3aNOTuKAIgA
30	https://www.google.com/accounts/o8/ud?source=profiles	1303308775	qTYeXvWtTsr3Ww
31	https://www.google.com/accounts/o8/ud	1303308818	hRPjO6RKkteJpg
32	http://www.livejournal.com/openid/server.bml	1303309574	jR3QTI
33	https://www.google.com/accounts/o8/ud	1303313338	OZmMeMXL2gH1nQ
34	https://www.google.com/accounts/o8/ud	1303319679	Z8uWBxnFOc8OsA
35	https://www.google.com/accounts/o8/ud	1303320025	1ZmcOQx1LGGHtg
36	https://www.google.com/accounts/o8/ud	1303324669	Q00QDICCJxjPRw
37		1303332429	BHP1Gy
38	https://www.google.com/accounts/o8/ud	1303333239	Zz7DcXjeFbW9wg
39	https://www.google.com/accounts/o8/ud	1303339922	U8QnpdWi8NqKkw
40	https://www.google.com/accounts/o8/ud	1303344165	84huOWOVgeUDXA
41	http://www.livejournal.com/openid/server.bml	1303352948	pIQ09p
42	http://www.myopenid.com/server	1303370240	DuSFkV
43	https://www.google.com/accounts/o8/ud	1303370744	pRRNscmbWNIHYg
44	https://www.google.com/accounts/o8/ud	1303383688	gqYzST_XYFquFg
45	https://www.google.com/accounts/o8/ud	1303410806	6TMxAd9CEc1RrQ
46		1303414167	TyW41p
47	https://www.google.com/accounts/o8/ud	1303451493	HG8fa_FXja52ng
48	https://www.google.com/accounts/o8/ud	1303455493	EJYO1j2ahpE9Kw
49		1303462686	4Z0med
50		1303484710	q8RAnA
51	https://www.google.com/accounts/o8/ud	1303488778	Q2WiiPfP-Ju8zQ
52	https://www.google.com/accounts/o8/ud	1303489125	u4YwyjGgiurCQw
53		1303493372	sd1mYc
54	https://www.google.com/accounts/o8/ud	1303525642	coSIE7qyXDjekg
55	https://www.google.com/accounts/o8/ud	1303531543	CY55GlyzT-YKlA
56		1303765104	IGE1zw
57	https://www.google.com/accounts/o8/ud	1303889346	r94voVWCcFq4Kw
58	https://www.google.com/accounts/o8/ud	1303932266	_P5FGIJ7iBvaDQ
59		1303934523	5vifUH
60		1303941031	NgjnMA
61	https://www.google.com/accounts/o8/ud	1303969424	KMuuS4vVMYS9Kw
62		1304019440	y5DKIQ
63	https://www.google.com/accounts/o8/ud	1304035449	JKsH74X0ep2pqQ
64		1304039067	58s33O
65		1304089902	YZXjRR
66		1304489451	8j0XOU
67	https://www.google.com/accounts/o8/ud	1304499093	zS8VGhn2F8kHAQ
68		1304499095	Mm67hd
69		1304659796	XwthYm
70	https://www.google.com/accounts/o8/ud	1304755612	-fE3xSAAMehSww
71	https://www.google.com/accounts/o8/ud	1304769391	Z3c2LO6lW8foSw
72	https://www.google.com/accounts/o8/ud	1305040131	DTEq6gNO1nrHww
73	https://www.google.com/accounts/o8/ud	1305192565	XVfTrVujHEvihg
74		1305483774	QEPxfX
75	https://www.google.com/accounts/o8/ud	1305625202	KF2nmddZnQtrJQ
76	https://www.google.com/accounts/o8/ud	1305662184	-OeCCQr_3_ZwDQ
77		1305709330	bMnVZ9
78	https://www.google.com/accounts/o8/ud	1305841362	9C3HQS-hXrmTDA
79	https://www.google.com/accounts/o8/ud	1305841375	0ZlbO82EGu0iFA
80	https://www.google.com/accounts/o8/ud	1306005522	XXzS4fThsZ_Vkg
81	https://www.google.com/accounts/o8/ud	1306023515	Ra0ZsVjehvtPtw
82	https://www.google.com/accounts/o8/ud	1306023575	AQb04MSDg8Yehg
83	https://www.google.com/accounts/o8/ud	1306156014	xemTAypAWywrNA
84	https://www.google.com/accounts/o8/ud	1306238566	rHFoZnmJNfW_rA
85	https://www.google.com/accounts/o8/ud	1306309280	EfGTFa0QkBToYg
86	https://www.google.com/accounts/o8/ud	1306329012	kCH7fa5NG1LN8g
87		1306480682	dqIOJp
88	https://www.google.com/accounts/o8/ud	1306522933	9CRCiuG7t4M4jA
89	https://www.google.com/accounts/o8/ud	1306694254	k32tOL1DHpZzQQ
90	https://www.google.com/accounts/o8/ud	1306816445	E2zs4XtGYR-ffw
91	https://www.google.com/accounts/o8/ud	1306830392	AjtclPBSdNg9cw
92	https://www.google.com/accounts/o8/ud	1306830898	UPuNTgQLTKLXlw
93		1306921330	pdRK0s
94	https://www.google.com/accounts/o8/ud	1307828500	84xzFi3FTwNBUQ
95	https://www.google.com/accounts/o8/ud	1308033811	eGGe5Mw8ctmH-Q
96	https://www.google.com/accounts/o8/ud	1308211877	2wc0GCpYiKleBQ
97		1308422926	HeDACF
98	https://www.google.com/accounts/o8/ud	1308743441	352S7_-RZuaFww
99	https://www.google.com/accounts/o8/ud	1308814730	QKV5CIsSIsYYcw
100		1309228201	OOsWwS
101	https://www.google.com/accounts/o8/ud	1309245720	Nknf7wmMC8nClQ
102	https://www.google.com/accounts/o8/ud	1309390653	kzyVvObxkdBe4g
103	https://www.google.com/accounts/o8/ud	1309400729	cQ5snXGspnVaBQ
104	https://www.google.com/accounts/o8/ud	1309474293	j0Y3ZXYV_DXV6A
105	https://www.google.com/accounts/o8/ud	1309474308	I5w0a-hXNnqdGA
106	https://www.google.com/accounts/o8/ud	1309537875	_7eVh84oAzujQg
107	https://www.google.com/accounts/o8/ud	1309555944	dBBBQvPwSbThPA
108	https://www.google.com/accounts/o8/ud	1310030257	IoAduUuZ3PJwwA
109		1310113812	cDOoxG
110	https://www.google.com/accounts/o8/ud	1310158048	YBYR31Oyc3SVRw
111	https://www.google.com/accounts/o8/ud	1310158062	xMJgikoqDukAAg
112	https://www.google.com/accounts/o8/ud	1310158120	FP0zYXSgHIli9g
113	https://www.google.com/accounts/o8/ud	1310317627	LU_QjVrh2KBGhA
114	https://www.google.com/accounts/o8/ud	1310389284	I9sfotOPfLHA3A
115	https://www.google.com/accounts/o8/ud	1310538520	OLK4h-69cHLUPg
116	https://www.google.com/accounts/o8/ud	1311052619	6AoOiftwd9YUTA
117	https://www.google.com/accounts/o8/ud	1311340517	_KAi0wEUS8Msgg
118	https://www.google.com/accounts/o8/ud	1311762512	DhPkuwfcoa_IXQ
119	https://www.google.com/accounts/o8/ud	1313795034	650qY6c-GdoMng
120	http://pip.verisignlabs.com/server	1313936407	Io1G/g==
121	https://www.google.com/accounts/o8/ud	1314611271	TfK5fZNmzw5tPw
122	https://www.google.com/accounts/o8/ud	1314611740	MSf9SZv69FoDsg
123	https://www.google.com/accounts/o8/ud	1315900734	nGVmQs9eltMM9A
124	https://www.google.com/accounts/o8/ud	1316022000	PF_KI8fyhtMKkw
125	https://www.google.com/accounts/o8/ud	1318443540	SzCjBZNBrmC17w
126	https://www.google.com/accounts/o8/ud	1318443629	rCpTk4uE-P5ZQQ
\.


--
-- Data for Name: django_openid_auth_useropenid; Type: TABLE DATA; Schema: public; Owner: codecatalog
--

COPY django_openid_auth_useropenid (id, user_id, claimed_id, display_id) FROM stdin;
1	1	http://lukepalmer.wordpress.com/	http://lukepalmer.wordpress.com/
2	2	https://www.google.com/accounts/o8/id?id=AItOawnuhPLxuIGG0d1leKm39ScU9-iNY2Fk_lI	https://www.google.com/accounts/o8/id?id=AItOawnuhPLxuIGG0d1leKm39ScU9-iNY2Fk_lI
3	3	https://www.google.com/accounts/o8/id?id=AItOawmFDQ6AmMRBNp_lhkm4HlPElwraSus4L88	https://www.google.com/accounts/o8/id?id=AItOawmFDQ6AmMRBNp_lhkm4HlPElwraSus4L88
4	4	https://profiles.google.com/lrpalmer	https://profiles.google.com/lrpalmer
5	5	https://www.google.com/accounts/o8/id?id=AItOawmIP4fUpydgBZm4IZuJF-86sljnGksFE44	https://www.google.com/accounts/o8/id?id=AItOawmIP4fUpydgBZm4IZuJF-86sljnGksFE44
6	6	https://www.google.com/accounts/o8/id?id=AItOawlpVh3wqrxdy9LIesLUGym__kaALs1AtcI	https://www.google.com/accounts/o8/id?id=AItOawlpVh3wqrxdy9LIesLUGym__kaALs1AtcI
7	7	https://www.google.com/accounts/o8/id?id=AItOawlssBdX7Lwoec4c5vI1inNljOj-hdLWKWE	https://www.google.com/accounts/o8/id?id=AItOawlssBdX7Lwoec4c5vI1inNljOj-hdLWKWE
8	8	https://www.google.com/accounts/o8/id?id=AItOawl-gG397GoqFowzZ5lmfOGpxl5N5RMUcMI	https://www.google.com/accounts/o8/id?id=AItOawl-gG397GoqFowzZ5lmfOGpxl5N5RMUcMI
9	9	https://www.google.com/accounts/o8/id?id=AItOawlW9aJbUYzUVup7OKVtYHt8XeZDypEcO7s	https://www.google.com/accounts/o8/id?id=AItOawlW9aJbUYzUVup7OKVtYHt8XeZDypEcO7s
10	10	https://www.google.com/accounts/o8/id?id=AItOawm7QxC9RILmZ4KGUtU326lM5ndnsON6Qts	https://www.google.com/accounts/o8/id?id=AItOawm7QxC9RILmZ4KGUtU326lM5ndnsON6Qts
11	11	https://www.google.com/accounts/o8/id?id=AItOawkJfsMqonnrBU-kLawJZ0jQ08oVrUq8N8Y	https://www.google.com/accounts/o8/id?id=AItOawkJfsMqonnrBU-kLawJZ0jQ08oVrUq8N8Y
12	12	http://lefant.net/	http://lefant.net/
13	13	https://www.google.com/accounts/o8/id?id=AItOawkKrewzGLoaL8YsGCxAnq03ce25aweWZFI	https://www.google.com/accounts/o8/id?id=AItOawkKrewzGLoaL8YsGCxAnq03ce25aweWZFI
14	14	https://www.google.com/accounts/o8/id?id=AItOawm4DkunbRhhM-Ptk17FqVqoClJufnqRGJA	https://www.google.com/accounts/o8/id?id=AItOawm4DkunbRhhM-Ptk17FqVqoClJufnqRGJA
15	15	https://www.google.com/accounts/o8/id?id=AItOawnFEhXx99axJXSGCd4ZU-ZN3d1pCBn0pRQ	https://www.google.com/accounts/o8/id?id=AItOawnFEhXx99axJXSGCd4ZU-ZN3d1pCBn0pRQ
16	16	https://profiles.google.com/shae.erisson	https://profiles.google.com/shae.erisson
17	17	https://www.google.com/accounts/o8/id?id=AItOawk9ERC6sKCTWY3mGtIydihp_PH6s1fReww	https://www.google.com/accounts/o8/id?id=AItOawk9ERC6sKCTWY3mGtIydihp_PH6s1fReww
18	18	http://vilhelm-s.livejournal.com/	http://vilhelm-s.livejournal.com/
19	19	https://www.google.com/accounts/o8/id?id=AItOawmifyOz-0JUhwZVQxSV8vD9eF-pQrw1ARE	https://www.google.com/accounts/o8/id?id=AItOawmifyOz-0JUhwZVQxSV8vD9eF-pQrw1ARE
20	20	https://www.google.com/accounts/o8/id?id=AItOawkG45wsDtHkiyj2cIWWqD_fZnOQWy-gBmY	https://www.google.com/accounts/o8/id?id=AItOawkG45wsDtHkiyj2cIWWqD_fZnOQWy-gBmY
21	21	https://www.google.com/accounts/o8/id?id=AItOawmn5nlXtMciAfWkVD1OlatyNo2AGSgLz1A	https://www.google.com/accounts/o8/id?id=AItOawmn5nlXtMciAfWkVD1OlatyNo2AGSgLz1A
22	22	https://www.google.com/accounts/o8/id?id=AItOawnrqiLgnw-o5Ny6Mei7nx6RpBuexsdlCAI	https://www.google.com/accounts/o8/id?id=AItOawnrqiLgnw-o5Ny6Mei7nx6RpBuexsdlCAI
23	23	https://www.google.com/accounts/o8/id?id=AItOawmFC6yBOgqK4xG7l6f37MhhoMIEHG2QIHw	https://www.google.com/accounts/o8/id?id=AItOawmFC6yBOgqK4xG7l6f37MhhoMIEHG2QIHw
24	24	https://www.google.com/accounts/o8/id?id=AItOawln7Yw9YiM2fmrb1C_3tvNRUTHIBHL1Y2g	https://www.google.com/accounts/o8/id?id=AItOawln7Yw9YiM2fmrb1C_3tvNRUTHIBHL1Y2g
25	25	http://amped.myopenid.com/	http://amped.myopenid.com/
26	26	https://www.google.com/accounts/o8/id?id=AItOawmJuJehEiTZ21ZgsHmQYfNrojBY2PLxL7E	https://www.google.com/accounts/o8/id?id=AItOawmJuJehEiTZ21ZgsHmQYfNrojBY2PLxL7E
27	27	https://www.google.com/accounts/o8/id?id=AItOawnYPDiKX35yteLDkMWksbkTkY-XKA0LjSs	https://www.google.com/accounts/o8/id?id=AItOawnYPDiKX35yteLDkMWksbkTkY-XKA0LjSs
28	28	https://www.google.com/accounts/o8/id?id=AItOawnBKWrrgPQ-HZfU3PsH1_8-Y9VCFw_aWy4	https://www.google.com/accounts/o8/id?id=AItOawnBKWrrgPQ-HZfU3PsH1_8-Y9VCFw_aWy4
29	29	https://www.google.com/accounts/o8/id?id=AItOawk9RG9xJZ4qPHQhceosbA_FCVOwDW2iNE0	https://www.google.com/accounts/o8/id?id=AItOawk9RG9xJZ4qPHQhceosbA_FCVOwDW2iNE0
30	30	https://www.google.com/accounts/o8/id?id=AItOawmUUZ3zRw2e8Cmsel3KJPG9_Yr5lQTRW64	https://www.google.com/accounts/o8/id?id=AItOawmUUZ3zRw2e8Cmsel3KJPG9_Yr5lQTRW64
31	31	https://www.google.com/accounts/o8/id?id=AItOawkbRt3J0nAL2EaWlx34lNq_1I83wvGAJ7k	https://www.google.com/accounts/o8/id?id=AItOawkbRt3J0nAL2EaWlx34lNq_1I83wvGAJ7k
32	32	https://www.google.com/accounts/o8/id?id=AItOawnb_0VtTTgkHjiaq9rwqe1V33UgO2Qauk0	https://www.google.com/accounts/o8/id?id=AItOawnb_0VtTTgkHjiaq9rwqe1V33UgO2Qauk0
33	33	https://www.google.com/accounts/o8/id?id=AItOawmE74FDw2Za5dGPBt5mKjZe3ONQoBi-X0M	https://www.google.com/accounts/o8/id?id=AItOawmE74FDw2Za5dGPBt5mKjZe3ONQoBi-X0M
34	34	https://www.google.com/accounts/o8/id?id=AItOawmzcq1j6R3zh8WDnutlKg0U2MLYsNZxuqw	https://www.google.com/accounts/o8/id?id=AItOawmzcq1j6R3zh8WDnutlKg0U2MLYsNZxuqw
35	35	https://www.google.com/accounts/o8/id?id=AItOawkmMP57aZg967WBZ4sHTkcY71-xWAemIJs	https://www.google.com/accounts/o8/id?id=AItOawkmMP57aZg967WBZ4sHTkcY71-xWAemIJs
36	36	https://www.google.com/accounts/o8/id?id=AItOawkiNk_uBU3v1uYewHwccC6NGPOWM6GvTLM	https://www.google.com/accounts/o8/id?id=AItOawkiNk_uBU3v1uYewHwccC6NGPOWM6GvTLM
37	37	https://www.google.com/accounts/o8/id?id=AItOawndcQeKo6pziu3vJZZyPBG2HVpEPT5gwvM	https://www.google.com/accounts/o8/id?id=AItOawndcQeKo6pziu3vJZZyPBG2HVpEPT5gwvM
38	38	https://www.google.com/accounts/o8/id?id=AItOawnz0fWiCh_6xgIqdQvLsLwJtamS9a7NwYk	https://www.google.com/accounts/o8/id?id=AItOawnz0fWiCh_6xgIqdQvLsLwJtamS9a7NwYk
39	39	https://www.google.com/accounts/o8/id?id=AItOawnVNmvtKOOlh3wFHx1GIbunijePuA-bJ7c	https://www.google.com/accounts/o8/id?id=AItOawnVNmvtKOOlh3wFHx1GIbunijePuA-bJ7c
40	40	https://www.google.com/accounts/o8/id?id=AItOawkByPr1CvtlzTjGrmV2eL2s8oKOtGkGfYg	https://www.google.com/accounts/o8/id?id=AItOawkByPr1CvtlzTjGrmV2eL2s8oKOtGkGfYg
41	41	https://www.google.com/accounts/o8/id?id=AItOawm-QvnZfS5OLyIbIEBNZVTGLrYSBAWCTWY	https://www.google.com/accounts/o8/id?id=AItOawm-QvnZfS5OLyIbIEBNZVTGLrYSBAWCTWY
42	42	https://www.google.com/accounts/o8/id?id=AItOawlQ1iHMlWY0OEglQxEqqIqWW8dkoPDrSgw	https://www.google.com/accounts/o8/id?id=AItOawlQ1iHMlWY0OEglQxEqqIqWW8dkoPDrSgw
48	48	http://vincentbuck.pip.verisignlabs.com/	http://vincentbuck.pip.verisignlabs.com/
43	43	https://www.google.com/accounts/o8/id?id=AItOawlBrQhEWdOE572HoEtTJud2ckrVCst4la8	https://www.google.com/accounts/o8/id?id=AItOawlBrQhEWdOE572HoEtTJud2ckrVCst4la8
44	44	https://www.google.com/accounts/o8/id?id=AItOawmu3do72FZkTau3vndlUv10TrXJ41UclMk	https://www.google.com/accounts/o8/id?id=AItOawmu3do72FZkTau3vndlUv10TrXJ41UclMk
45	45	https://www.google.com/accounts/o8/id?id=AItOawmIg6oefVzEDy85WZS-GDEjhNJ2JWYDvvQ	https://www.google.com/accounts/o8/id?id=AItOawmIg6oefVzEDy85WZS-GDEjhNJ2JWYDvvQ
46	46	https://www.google.com/accounts/o8/id?id=AItOawmRvqdcFw5UDEWU9KPspsR6GC5G28IFyCM	https://www.google.com/accounts/o8/id?id=AItOawmRvqdcFw5UDEWU9KPspsR6GC5G28IFyCM
47	47	https://www.google.com/accounts/o8/id?id=AItOawnsbuiEjcVgo0qRVrxv82qsl1a1Na5kkqk	https://www.google.com/accounts/o8/id?id=AItOawnsbuiEjcVgo0qRVrxv82qsl1a1Na5kkqk
49	49	https://www.google.com/accounts/o8/id?id=AItOawn4REoZVC8b_Lgp1sm3vbPsds6sByeq8iQ	https://www.google.com/accounts/o8/id?id=AItOawn4REoZVC8b_Lgp1sm3vbPsds6sByeq8iQ
50	50	https://www.google.com/accounts/o8/id?id=AItOawmjdee8cuDTU27FBFYBFoN6oyPedff_-VM	https://www.google.com/accounts/o8/id?id=AItOawmjdee8cuDTU27FBFYBFoN6oyPedff_-VM
\.


--
-- Data for Name: django_session; Type: TABLE DATA; Schema: public; Owner: codecatalog
--

COPY django_session (session_key, session_data, expire_date) FROM stdin;
ea1645ef0893d374942b5873ebc0d49c	gAJ9cQFVBk9QRU5JRHECfXEDKFUhX3lhZGlzX3NlcnZpY2VzX19vcGVuaWRfY29uc3VtZXJfcQRj\nb3BlbmlkLnlhZGlzLm1hbmFnZXIKWWFkaXNTZXJ2aWNlTWFuYWdlcgpxBSmBcQZ9cQcoVQhzZXJ2\naWNlc3EIXXEJVQl5YWRpc191cmxxClUgaHR0cDovL2x1a2VwYWxtZXIud29yZHByZXNzLmNvbS9x\nC1UMc3RhcnRpbmdfdXJscQxYGAAAAGx1a2VwYWxtZXIud29yZHByZXNzLmNvbXENVQtzZXNzaW9u\nX2tleXEOaARVCF9jdXJyZW50cQ9jb3BlbmlkLmNvbnN1bWVyLmRpc2NvdmVyCk9wZW5JRFNlcnZp\nY2VFbmRwb2ludApxECmBcRF9cRIoVQpjbGFpbWVkX2lkcRNVIGh0dHA6Ly9sdWtlcGFsbWVyLndv\ncmRwcmVzcy5jb20vcRRVEmRpc3BsYXlfaWRlbnRpZmllcnEVTlUKc2VydmVyX3VybHEWVS9odHRw\nOi8vbHVrZXBhbG1lci53b3JkcHJlc3MuY29tLz9vcGVuaWRzZXJ2ZXI9MXEXVQtjYW5vbmljYWxJ\nRHEYTlUIbG9jYWxfaWRxGVUgaHR0cDovL2x1a2VwYWxtZXIud29yZHByZXNzLmNvbS9xGlUJdHlw\nZV91cmlzcRtdcRxVHGh0dHA6Ly9vcGVuaWQubmV0L3NpZ25vbi8xLjFxHWFVCnVzZWRfeWFkaXNx\nHol1YnViVRtfb3BlbmlkX2NvbnN1bWVyX2xhc3RfdG9rZW5xH2gRdXMuMzg0NmVmZWE2N2NlY2E1\nMDZjMzhjOTgwZDljZjQyNjM=\n	2011-04-07 08:16:19.883799+00
7be7e9554dfae91e35900b88e0417d63	gAJ9cQFVBk9QRU5JRHECfXEDKFUhX3lhZGlzX3NlcnZpY2VzX19vcGVuaWRfY29uc3VtZXJfcQRj\nb3BlbmlkLnlhZGlzLm1hbmFnZXIKWWFkaXNTZXJ2aWNlTWFuYWdlcgpxBSmBcQZ9cQcoVQhzZXJ2\naWNlc3EIXXEJVQl5YWRpc191cmxxClUgaHR0cDovL2x1a2VwYWxtZXIud29yZHByZXNzLmNvbS9x\nC1UMc3RhcnRpbmdfdXJscQxYGAAAAGx1a2VwYWxtZXIud29yZHByZXNzLmNvbXENVQtzZXNzaW9u\nX2tleXEOaARVCF9jdXJyZW50cQ9jb3BlbmlkLmNvbnN1bWVyLmRpc2NvdmVyCk9wZW5JRFNlcnZp\nY2VFbmRwb2ludApxECmBcRF9cRIoVQpjbGFpbWVkX2lkcRNVIGh0dHA6Ly9sdWtlcGFsbWVyLndv\ncmRwcmVzcy5jb20vcRRVEmRpc3BsYXlfaWRlbnRpZmllcnEVTlUKc2VydmVyX3VybHEWVS9odHRw\nOi8vbHVrZXBhbG1lci53b3JkcHJlc3MuY29tLz9vcGVuaWRzZXJ2ZXI9MXEXVQtjYW5vbmljYWxJ\nRHEYTlUIbG9jYWxfaWRxGVUgaHR0cDovL2x1a2VwYWxtZXIud29yZHByZXNzLmNvbS9xGlUJdHlw\nZV91cmlzcRtdcRxVHGh0dHA6Ly9vcGVuaWQubmV0L3NpZ25vbi8xLjFxHWFVCnVzZWRfeWFkaXNx\nHol1YnViVRtfb3BlbmlkX2NvbnN1bWVyX2xhc3RfdG9rZW5xH2gRdXMuMzg0NmVmZWE2N2NlY2E1\nMDZjMzhjOTgwZDljZjQyNjM=\n	2011-04-07 08:16:36.628461+00
4c7e62cf131ce40a7682510116203945	gAJ9cQFVBk9QRU5JRHECfXEDKFUhX3lhZGlzX3NlcnZpY2VzX19vcGVuaWRfY29uc3VtZXJfcQRj\nb3BlbmlkLnlhZGlzLm1hbmFnZXIKWWFkaXNTZXJ2aWNlTWFuYWdlcgpxBSmBcQZ9cQcoVQhzZXJ2\naWNlc3EIXXEJVQl5YWRpc191cmxxClUgaHR0cDovL2x1a2VwYWxtZXIud29yZHByZXNzLmNvbS9x\nC1UMc3RhcnRpbmdfdXJscQxYGAAAAGx1a2VwYWxtZXIud29yZHByZXNzLmNvbXENVQtzZXNzaW9u\nX2tleXEOaARVCF9jdXJyZW50cQ9jb3BlbmlkLmNvbnN1bWVyLmRpc2NvdmVyCk9wZW5JRFNlcnZp\nY2VFbmRwb2ludApxECmBcRF9cRIoVQpjbGFpbWVkX2lkcRNVIGh0dHA6Ly9sdWtlcGFsbWVyLndv\ncmRwcmVzcy5jb20vcRRVEmRpc3BsYXlfaWRlbnRpZmllcnEVTlUKc2VydmVyX3VybHEWVS9odHRw\nOi8vbHVrZXBhbG1lci53b3JkcHJlc3MuY29tLz9vcGVuaWRzZXJ2ZXI9MXEXVQtjYW5vbmljYWxJ\nRHEYTlUIbG9jYWxfaWRxGVUgaHR0cDovL2x1a2VwYWxtZXIud29yZHByZXNzLmNvbS9xGlUJdHlw\nZV91cmlzcRtdcRxVHGh0dHA6Ly9vcGVuaWQubmV0L3NpZ25vbi8xLjFxHWFVCnVzZWRfeWFkaXNx\nHol1YnViVRtfb3BlbmlkX2NvbnN1bWVyX2xhc3RfdG9rZW5xH2gRdXMuMzg0NmVmZWE2N2NlY2E1\nMDZjMzhjOTgwZDljZjQyNjM=\n	2011-04-07 08:16:51.020927+00
ae84ddbf8fe1a19d84ee1a6452b1d1f8	gAJ9cQFVBk9QRU5JRHECfXEDKFUhX3lhZGlzX3NlcnZpY2VzX19vcGVuaWRfY29uc3VtZXJfcQRj\nb3BlbmlkLnlhZGlzLm1hbmFnZXIKWWFkaXNTZXJ2aWNlTWFuYWdlcgpxBSmBcQZ9cQcoVQhzZXJ2\naWNlc3EIXXEJVQl5YWRpc191cmxxClUgaHR0cDovL2x1a2VwYWxtZXIud29yZHByZXNzLmNvbS9x\nC1UMc3RhcnRpbmdfdXJscQxYGAAAAGx1a2VwYWxtZXIud29yZHByZXNzLmNvbXENVQtzZXNzaW9u\nX2tleXEOaARVCF9jdXJyZW50cQ9jb3BlbmlkLmNvbnN1bWVyLmRpc2NvdmVyCk9wZW5JRFNlcnZp\nY2VFbmRwb2ludApxECmBcRF9cRIoVQpjbGFpbWVkX2lkcRNVIGh0dHA6Ly9sdWtlcGFsbWVyLndv\ncmRwcmVzcy5jb20vcRRVEmRpc3BsYXlfaWRlbnRpZmllcnEVTlUKc2VydmVyX3VybHEWVS9odHRw\nOi8vbHVrZXBhbG1lci53b3JkcHJlc3MuY29tLz9vcGVuaWRzZXJ2ZXI9MXEXVQtjYW5vbmljYWxJ\nRHEYTlUIbG9jYWxfaWRxGVUgaHR0cDovL2x1a2VwYWxtZXIud29yZHByZXNzLmNvbS9xGlUJdHlw\nZV91cmlzcRtdcRxVHGh0dHA6Ly9vcGVuaWQubmV0L3NpZ25vbi8xLjFxHWFVCnVzZWRfeWFkaXNx\nHol1YnViVRtfb3BlbmlkX2NvbnN1bWVyX2xhc3RfdG9rZW5xH2gRdXMuMzg0NmVmZWE2N2NlY2E1\nMDZjMzhjOTgwZDljZjQyNjM=\n	2011-04-07 08:17:50.676683+00
81a38022cab5aaa083f4c4561d22a186	gAJ9cQEoVQZPUEVOSURxAn1xA1USX2F1dGhfdXNlcl9iYWNrZW5kcQRVJWRqYW5nb19vcGVuaWRf\nYXV0aC5hdXRoLk9wZW5JREJhY2tlbmRxBVUNX2F1dGhfdXNlcl9pZHEGigECdS45ODJhMjg3MzNh\nODdhYmFiNjYxZTgwZDg3MzQ3MjAwZQ==\n	2011-04-12 06:38:09.504675+00
5a30a0226402f58fd0b3deadc0aeb202	gAJ9cQEoVQZPUEVOSURxAn1xA1USX2F1dGhfdXNlcl9iYWNrZW5kcQRVJWRqYW5nb19vcGVuaWRf\nYXV0aC5hdXRoLk9wZW5JREJhY2tlbmRxBVUNX2F1dGhfdXNlcl9pZHEGSwF1LmM4MGJjNTI3M2Uw\nOTM1YmQ4ZWY5NDhlODZiNGU4NWI2\n	2011-04-10 12:27:02.554726+00
42270732dfe9a674612ace21e57984fb	gAJ9cQEoVQZPUEVOSURxAn1xA1USX2F1dGhfdXNlcl9iYWNrZW5kcQRVJWRqYW5nb19vcGVuaWRf\nYXV0aC5hdXRoLk9wZW5JREJhY2tlbmRxBVUNX2F1dGhfdXNlcl9pZHEGSwF1LmM4MGJjNTI3M2Uw\nOTM1YmQ4ZWY5NDhlODZiNGU4NWI2\n	2011-04-11 05:10:45.046429+00
e74345091415e4da48463ec3d02bd9ee	gAJ9cQEoVQZPUEVOSURxAn1xA1USX2F1dGhfdXNlcl9iYWNrZW5kcQRVJWRqYW5nb19vcGVuaWRf\nYXV0aC5hdXRoLk9wZW5JREJhY2tlbmRxBVUNX2F1dGhfdXNlcl9pZHEGigEDdS5kYWY3ODYxN2Rk\nNGRkMzk0YjUyNTBiZjhmNzg0MGZkNg==\n	2011-04-12 09:59:53.238222+00
65c71bb2028dd4d7267285c02d20a18f	gAJ9cQEoVQZPUEVOSURxAn1xA1USX2F1dGhfdXNlcl9iYWNrZW5kcQRVJWRqYW5nb19vcGVuaWRf\nYXV0aC5hdXRoLk9wZW5JREJhY2tlbmRxBVUNX2F1dGhfdXNlcl9pZHEGSwF1LmM4MGJjNTI3M2Uw\nOTM1YmQ4ZWY5NDhlODZiNGU4NWI2\n	2011-04-12 17:15:06.110272+00
a9031633b36a35a7941df942de2e3b93	gAJ9cQEoVQZPUEVOSURxAn1xA1USX2F1dGhfdXNlcl9iYWNrZW5kcQRVJWRqYW5nb19vcGVuaWRf\nYXV0aC5hdXRoLk9wZW5JREJhY2tlbmRxBVUNX2F1dGhfdXNlcl9pZHEGSwF1LmM4MGJjNTI3M2Uw\nOTM1YmQ4ZWY5NDhlODZiNGU4NWI2\n	2011-04-12 23:19:41.293099+00
626cd35ee6c5449cb4227cbc6c2c801b	MjgyNjcyMTJkMjMxZjcwNzYwZmEzMGMyYzkyMjE1OGViNzEzMmI1MDqAAn1xAShVBk9QRU5JRHEC\nfXEDVRJfYXV0aF91c2VyX2JhY2tlbmRxBFUlZGphbmdvX29wZW5pZF9hdXRoLmF1dGguT3BlbklE\nQmFja2VuZHEFVQ1fYXV0aF91c2VyX2lkcQZLAXUu\n	2011-04-15 16:02:46.890844+00
b06a9b3485cafed535429b4785dcf30c	gAJ9cQEoVQZPUEVOSURxAn1xA1USX2F1dGhfdXNlcl9iYWNrZW5kcQRVJWRqYW5nb19vcGVuaWRf\nYXV0aC5hdXRoLk9wZW5JREJhY2tlbmRxBVUNX2F1dGhfdXNlcl9pZHEGSwF1LmM4MGJjNTI3M2Uw\nOTM1YmQ4ZWY5NDhlODZiNGU4NWI2\n	2011-04-15 16:11:06.129555+00
0f926077af062db467e3948f319f5cfb	MjgyNjcyMTJkMjMxZjcwNzYwZmEzMGMyYzkyMjE1OGViNzEzMmI1MDqAAn1xAShVBk9QRU5JRHEC\nfXEDVRJfYXV0aF91c2VyX2JhY2tlbmRxBFUlZGphbmdvX29wZW5pZF9hdXRoLmF1dGguT3BlbklE\nQmFja2VuZHEFVQ1fYXV0aF91c2VyX2lkcQZLAXUu\n	2011-04-21 17:45:15.849352+00
a3bcc47b664005de792c74716b484e01	N2M0NTMwNDM3MGM2MWI4NzExOTdlMWU2MDhhNjhhMTI1NDhkODk4MjqAAn1xAShVBk9QRU5JRHEC\nfXEDVRJfYXV0aF91c2VyX2JhY2tlbmRxBFUlZGphbmdvX29wZW5pZF9hdXRoLmF1dGguT3BlbklE\nQmFja2VuZHEFVQ1fYXV0aF91c2VyX2lkcQZLAnUu\n	2011-05-02 05:08:09.294642+00
4febba3cf8eb884ea801cc6acebbd759	NmM3ODIzODY0N2Q4NWRmNzc1MDhkNTNmYzE1OTQxMmZhNGY5OWJiYTqAAn1xAVUGT1BFTklEcQJ9\ncQMoVSFfeWFkaXNfc2VydmljZXNfX29wZW5pZF9jb25zdW1lcl9xBGNvcGVuaWQueWFkaXMubWFu\nYWdlcgpZYWRpc1NlcnZpY2VNYW5hZ2VyCnEFKYFxBn1xByhVCHNlcnZpY2VzcQhdcQlVCXlhZGlz\nX3VybHEKVSVodHRwczovL3d3dy5nb29nbGUuY29tL2FjY291bnRzL284L2lkcQtVDHN0YXJ0aW5n\nX3VybHEMWCUAAABodHRwczovL3d3dy5nb29nbGUuY29tL2FjY291bnRzL284L2lkcQ1VC3Nlc3Np\nb25fa2V5cQ5oBFUIX2N1cnJlbnRxD2NvcGVuaWQuY29uc3VtZXIuZGlzY292ZXIKT3BlbklEU2Vy\ndmljZUVuZHBvaW50CnEQKYFxEX1xEihVCmNsYWltZWRfaWRxE05VEmRpc3BsYXlfaWRlbnRpZmll\ncnEUTlUKc2VydmVyX3VybHEVVSVodHRwczovL3d3dy5nb29nbGUuY29tL2FjY291bnRzL284L3Vk\ncRZVC2Nhbm9uaWNhbElEcRdOVQhsb2NhbF9pZHEYTlUJdHlwZV91cmlzcRldcRooVSdodHRwOi8v\nc3BlY3Mub3BlbmlkLm5ldC9hdXRoLzIuMC9zZXJ2ZXJxG1UcaHR0cDovL29wZW5pZC5uZXQvc3J2\nL2F4LzEuMHEcVTRodHRwOi8vc3BlY3Mub3BlbmlkLm5ldC9leHRlbnNpb25zL3VpLzEuMC9tb2Rl\nL3BvcHVwcR1VLmh0dHA6Ly9zcGVjcy5vcGVuaWQubmV0L2V4dGVuc2lvbnMvdWkvMS4wL2ljb25x\nHlUraHR0cDovL3NwZWNzLm9wZW5pZC5uZXQvZXh0ZW5zaW9ucy9wYXBlLzEuMHEfZVUKdXNlZF95\nYWRpc3EgiHVidWJVG19vcGVuaWRfY29uc3VtZXJfbGFzdF90b2tlbnEhaBF1cy4=\n	2011-05-04 02:37:26.075689+00
5c331e3764686b4325e3cad9a9d3e9cc	MjgyNjcyMTJkMjMxZjcwNzYwZmEzMGMyYzkyMjE1OGViNzEzMmI1MDqAAn1xAShVBk9QRU5JRHEC\nfXEDVRJfYXV0aF91c2VyX2JhY2tlbmRxBFUlZGphbmdvX29wZW5pZF9hdXRoLmF1dGguT3BlbklE\nQmFja2VuZHEFVQ1fYXV0aF91c2VyX2lkcQZLAXUu\n	2011-05-04 01:32:57.200797+00
61e2c8e10f1f0f98e749ea69d45b5b17	OWEyZDQ3MjVhNDllZjI2Yzk4ZTQ0NWFhYWM0ZWNhYzNkNWVmZTc0MDqAAn1xAShVBk9QRU5JRHEC\nfXEDVRJfYXV0aF91c2VyX2JhY2tlbmRxBFUlZGphbmdvX29wZW5pZF9hdXRoLmF1dGguT3BlbklE\nQmFja2VuZHEFVQ1fYXV0aF91c2VyX2lkcQaKAQV1Lg==\n	2011-05-04 02:37:51.845009+00
02ab2f5ef67bdc4a3ed295dbf7424dac	YTE3NDliMmM2ZTM0MTdjZjExNWI5YmJlMTgyMDFkMTJmZjA0NWY1ZTqAAn1xAShVBk9QRU5JRHEC\nfXEDVRJfYXV0aF91c2VyX2JhY2tlbmRxBFUlZGphbmdvX29wZW5pZF9hdXRoLmF1dGguT3BlbklE\nQmFja2VuZHEFVQ1fYXV0aF91c2VyX2lkcQaKAQZ1Lg==\n	2011-05-04 03:34:43.868581+00
95b91ff0c40fdd3209c158a868b696c6	OGRmNDgzNjM1MzMwNmJhMWM2N2YyMTEyZDFmYTFkZDc4NjhlY2Y0MzqAAn1xAShVBk9QRU5JRHEC\nfXEDVRJfYXV0aF91c2VyX2JhY2tlbmRxBFUlZGphbmdvX29wZW5pZF9hdXRoLmF1dGguT3BlbklE\nQmFja2VuZHEFVQ1fYXV0aF91c2VyX2lkcQaKAQd1Lg==\n	2011-05-04 03:43:25.197289+00
68b1fbffbf28c31a6910b3c3398f716d	Njc2OGJiZjFiM2U0Y2I2MjJlZGU5NmUxMmZiZjI0MDY4ZmUyYTk4NTqAAn1xAShVBk9QRU5JRHEC\nfXEDVRJfYXV0aF91c2VyX2JhY2tlbmRxBFUlZGphbmdvX29wZW5pZF9hdXRoLmF1dGguT3BlbklE\nQmFja2VuZHEFVQ1fYXV0aF91c2VyX2lkcQaKAQh1Lg==\n	2011-05-04 04:01:32.01489+00
db0f1e533ebdb6c2cf7adf632596f39e	YmQzNjM2ZmFhMWU1N2Y2NmQzYTRlMzI5YzEyOTRlZDVkY2YyYmM1OTqAAn1xAShVBk9QRU5JRHEC\nfXEDVRJfYXV0aF91c2VyX2JhY2tlbmRxBFUlZGphbmdvX29wZW5pZF9hdXRoLmF1dGguT3BlbklE\nQmFja2VuZHEFVQ1fYXV0aF91c2VyX2lkcQaKAQl1Lg==\n	2011-05-04 05:18:34.742996+00
1f97e009ce500efba015881bdbe77ed8	YjhmMmE0ODgzMTJiYjc2NzZiMzQzNjc1Y2VlNDJkMDlkN2Q1MGJjMTqAAn1xAShVBk9QRU5JRHEC\nfXEDVRJfYXV0aF91c2VyX2JhY2tlbmRxBFUlZGphbmdvX29wZW5pZF9hdXRoLmF1dGguT3BlbklE\nQmFja2VuZHEFVQ1fYXV0aF91c2VyX2lkcQaKAQp1Lg==\n	2011-05-04 06:43:34.4416+00
329862d32bd4ec2f5954754afd0ef0ba	ZDVjZmExODE2NGNlMWZmZDMzYWYzM2FlNTU3NzQyNzRiYTIyZmNiNzqAAn1xAShVBk9QRU5JRHEC\nfXEDVRJfYXV0aF91c2VyX2JhY2tlbmRxBFUlZGphbmdvX29wZW5pZF9hdXRoLmF1dGguT3BlbklE\nQmFja2VuZHEFVQ1fYXV0aF91c2VyX2lkcQaKAQt1Lg==\n	2011-05-04 06:48:35.574852+00
8b7f78433969b33a6cc9d51c2706ef98	ZjU1NmQ4NjEyYTBkZWE3MmNjZjg3ZWMyNjk4ZjdmY2UwYmJjMWMwNDqAAn1xAVUGT1BFTklEcQJ9\ncQNzLg==\n	2011-05-04 06:50:57.019761+00
4354fd8031a56e8bdcac941a44df55a4	YWQzNDBiN2U2ZTJhNmI1OGM1ZmRkOTcyMzUxNDE1M2M3ZjE4OTEwNjqAAn1xAShVBk9QRU5JRHEC\nfXEDVRJfYXV0aF91c2VyX2JhY2tlbmRxBFUlZGphbmdvX29wZW5pZF9hdXRoLmF1dGguT3BlbklE\nQmFja2VuZHEFVQ1fYXV0aF91c2VyX2lkcQaKAQx1Lg==\n	2011-05-04 09:27:09.260321+00
500ebe8ab0e18127ef2b30e371498b29	YTU1NWQxNWVmNWNhNGUyYTNhNmI0MGQzZDBkNjgxODU2ZmYxMmRjNTqAAn1xAShVBk9QRU5JRHEC\nfXEDVRJfYXV0aF91c2VyX2JhY2tlbmRxBFUlZGphbmdvX29wZW5pZF9hdXRoLmF1dGguT3BlbklE\nQmFja2VuZHEFVQ1fYXV0aF91c2VyX2lkcQaKAQ11Lg==\n	2011-05-04 10:07:57.31018+00
e7f9124181a447ac674d263d6f79fad4	ZDc5MzFmNDU3MDhiOGFiNDkyZTg1NzViNDQwMDE0OWFjNWRkNGU2YzqAAn1xAShVBk9QRU5JRHEC\nfXEDVRJfYXV0aF91c2VyX2JhY2tlbmRxBFUlZGphbmdvX29wZW5pZF9hdXRoLmF1dGguT3BlbklE\nQmFja2VuZHEFVQ1fYXV0aF91c2VyX2lkcQaKAQ91Lg==\n	2011-05-04 10:44:55.524077+00
2ea039527b8a7c3ecd729869dd23b3da	OGUzMGYwMDI4ZTNkNDRiNGNlNTYzNTU2OWIwNGVhOWViMjQyZWZhNTqAAn1xAS4=\n	2011-05-04 10:51:53.049654+00
f3a22c380747677e0f15c936ef6f8160	YWVmNDI3Njk1ZDk0Njg4MGY2YzgzNTQwZmYyM2ZiMmNkYzU5YjI0NDqAAn1xAShVBk9QRU5JRHEC\nfXEDVRJfYXV0aF91c2VyX2JhY2tlbmRxBFUlZGphbmdvX29wZW5pZF9hdXRoLmF1dGguT3BlbklE\nQmFja2VuZHEFVQ1fYXV0aF91c2VyX2lkcQaKARF1Lg==\n	2011-05-04 14:13:39.679132+00
805c00e70f2c504e7eee87d97fdefa1e	OGUzMGYwMDI4ZTNkNDRiNGNlNTYzNTU2OWIwNGVhOWViMjQyZWZhNTqAAn1xAS4=\n	2011-05-04 14:17:08.610573+00
51ad5cad7312fd3f9bea1cead83baebf	OTg0MjZiOTBlMTYwOWY1MDlmNmE2NTdmNDhmYjA3ZGJlMDdhMzk4NzqAAn1xAShVBk9QRU5JRHEC\nfXEDVRJfYXV0aF91c2VyX2JhY2tlbmRxBFUlZGphbmdvX29wZW5pZF9hdXRoLmF1dGguT3BlbklE\nQmFja2VuZHEFVQ1fYXV0aF91c2VyX2lkcQaKARJ1Lg==\n	2011-05-04 14:26:16.026691+00
216cb99c439a07d780d21b80ee377140	MWJjMjc2NDdjZjViNWM2M2RjZmYxNGQzM2VlNWEyNjNhYjhmNWU3OTqAAn1xAVUGT1BFTklEcQJ9\ncQMoVSFfeWFkaXNfc2VydmljZXNfX29wZW5pZF9jb25zdW1lcl9xBGNvcGVuaWQueWFkaXMubWFu\nYWdlcgpZYWRpc1NlcnZpY2VNYW5hZ2VyCnEFKYFxBn1xByhVCHNlcnZpY2VzcQhdcQlVCXlhZGlz\nX3VybHEKVRVodHRwczovL21lLnlhaG9vLmNvbS9xC1UMc3RhcnRpbmdfdXJscQxYFAAAAGh0dHA6\nLy9tZS55YWhvby5jb20vcQ1VC3Nlc3Npb25fa2V5cQ5oBFUIX2N1cnJlbnRxD2NvcGVuaWQuY29u\nc3VtZXIuZGlzY292ZXIKT3BlbklEU2VydmljZUVuZHBvaW50CnEQKYFxEX1xEihVCmNsYWltZWRf\naWRxE05VEmRpc3BsYXlfaWRlbnRpZmllcnEUTlUKc2VydmVyX3VybHEVVS9odHRwczovL29wZW4u\nbG9naW4ueWFob29hcGlzLmNvbS9vcGVuaWQvb3AvYXV0aHEWVQtjYW5vbmljYWxJRHEXTlUIbG9j\nYWxfaWRxGE5VCXR5cGVfdXJpc3EZXXEaKFUnaHR0cDovL3NwZWNzLm9wZW5pZC5uZXQvYXV0aC8y\nLjAvc2VydmVycRtVK2h0dHA6Ly9zcGVjcy5vcGVuaWQubmV0L2V4dGVuc2lvbnMvcGFwZS8xLjBx\nHFUcaHR0cDovL29wZW5pZC5uZXQvc3J2L2F4LzEuMHEdVSxodHRwOi8vc3BlY3Mub3BlbmlkLm5l\ndC9leHRlbnNpb25zL29hdXRoLzEuMHEeVTNodHRwOi8vc3BlY3Mub3BlbmlkLm5ldC9leHRlbnNp\nb25zL3VpLzEuMC9sYW5nLXByZWZxH1U0aHR0cDovL3NwZWNzLm9wZW5pZC5uZXQvZXh0ZW5zaW9u\ncy91aS8xLjAvbW9kZS9wb3B1cHEgVU9odHRwOi8vc2NoZW1hcy54bWxzb2FwLm9yZy93cy8yMDA1\nLzA1L2lkZW50aXR5L2NsYWltcy9wcml2YXRlcGVyc29uYWxpZGVudGlmaWVycSFVOmh0dHA6Ly93\nd3cuaWRtYW5hZ2VtZW50Lmdvdi9zY2hlbWEvMjAwOS8wNS9pY2FtL25vLXBpaS5wZGZxIlVHaHR0\ncDovL3d3dy5pZG1hbmFnZW1lbnQuZ292L3NjaGVtYS8yMDA5LzA1L2ljYW0vb3BlbmlkLXRydXN0\nLWxldmVsMS5wZGZxI1VEaHR0cDovL2NzcmMubmlzdC5nb3YvcHVibGljYXRpb25zL25pc3RwdWJz\nLzgwMC02My9TUDgwMC02M1YxXzBfMi5wZGZxJGVVCnVzZWRfeWFkaXNxJYh1YnViVRtfb3Blbmlk\nX2NvbnN1bWVyX2xhc3RfdG9rZW5xJmgRdXMu\n	2011-05-04 15:25:58.388373+00
fb6e0cdef2b202d7533d6b4d2d7f7f49	Mjg1MjgwMjQxOWQxMzhiYzBmOWQ3NDJkMTNiMjQwZDQxZWNlNzYyNzqAAn1xAShVBk9QRU5JRHEC\nfXEDVRJfYXV0aF91c2VyX2JhY2tlbmRxBFUlZGphbmdvX29wZW5pZF9hdXRoLmF1dGguT3BlbklE\nQmFja2VuZHEFVQ1fYXV0aF91c2VyX2lkcQaKARN1Lg==\n	2011-05-04 15:28:59.701221+00
77afe38ac20c69b0ce114da01ff69d73	NzA0NjRiZmJlNThmNGNlMjBhYjY2Yjc4NmJiODA3ZGNkOWU4MjQ0MDqAAn1xAShVBk9QRU5JRHEC\nfXEDVRJfYXV0aF91c2VyX2JhY2tlbmRxBFUlZGphbmdvX29wZW5pZF9hdXRoLmF1dGguT3BlbklE\nQmFja2VuZHEFVQ1fYXV0aF91c2VyX2lkcQaKARR1Lg==\n	2011-05-04 17:14:40.392081+00
e63ab7dd64481e0c5c258d48ed60095b	YWU2OTJjNjM4ODU5MDY4NTZkOTk3ZGJmOTBiNjE5OGMxNWRmNmM1NzqAAn1xAShVBk9QRU5JRHEC\nfXEDVRJfYXV0aF91c2VyX2JhY2tlbmRxBFUlZGphbmdvX29wZW5pZF9hdXRoLmF1dGguT3BlbklE\nQmFja2VuZHEFVQ1fYXV0aF91c2VyX2lkcQaKARV1Lg==\n	2011-05-04 17:20:26.89279+00
cdc7b500f5dce4fd56c8fe7db5e47a6c	ZDdjMDY2ZjIzMTEwMTY3ZTI3YjQ2ZTAxYWI1NTcwZGRhYzAxZDE3ZTqAAn1xAShVBk9QRU5JRHEC\nfXEDVRJfYXV0aF91c2VyX2JhY2tlbmRxBFUlZGphbmdvX29wZW5pZF9hdXRoLmF1dGguT3BlbklE\nQmFja2VuZHEFVQ1fYXV0aF91c2VyX2lkcQaKARZ1Lg==\n	2011-05-04 18:37:49.782058+00
73159474aedfd5debfabb7c6042478a1	MjgyNjcyMTJkMjMxZjcwNzYwZmEzMGMyYzkyMjE1OGViNzEzMmI1MDqAAn1xAShVBk9QRU5JRHEC\nfXEDVRJfYXV0aF91c2VyX2JhY2tlbmRxBFUlZGphbmdvX29wZW5pZF9hdXRoLmF1dGguT3BlbklE\nQmFja2VuZHEFVQ1fYXV0aF91c2VyX2lkcQZLAXUu\n	2011-05-04 20:47:09.468998+00
fc45dcc2cdff4fd1205955cadb0fe999	Nzc3MWIzMGY0N2I2MWY1ZWEzYzAwMjUxODI4MGNiZGZkNWU5NDJhOTqAAn1xAShVBk9QRU5JRHEC\nfXEDVRJfYXV0aF91c2VyX2JhY2tlbmRxBFUlZGphbmdvX29wZW5pZF9hdXRoLmF1dGguT3BlbklE\nQmFja2VuZHEFVQ1fYXV0aF91c2VyX2lkcQaKARd1Lg==\n	2011-05-04 21:00:40.747011+00
b22bb0798dc7b38a9ace60993be865fd	NjM4NGM1MjMxZTM5ODYxYjAxODBlODM0ZjRkMzdlMzk5MDFlNGY1MTqAAn1xAShVBk9QRU5JRHEC\nfXEDVRJfYXV0aF91c2VyX2JhY2tlbmRxBFUlZGphbmdvX29wZW5pZF9hdXRoLmF1dGguT3BlbklE\nQmFja2VuZHEFVQ1fYXV0aF91c2VyX2lkcQaKARh1Lg==\n	2011-05-04 22:52:03.892364+00
3313dfe94bbb1f4799faa9206cc2dc3c	NmM3ODIzODY0N2Q4NWRmNzc1MDhkNTNmYzE1OTQxMmZhNGY5OWJiYTqAAn1xAVUGT1BFTklEcQJ9\ncQMoVSFfeWFkaXNfc2VydmljZXNfX29wZW5pZF9jb25zdW1lcl9xBGNvcGVuaWQueWFkaXMubWFu\nYWdlcgpZYWRpc1NlcnZpY2VNYW5hZ2VyCnEFKYFxBn1xByhVCHNlcnZpY2VzcQhdcQlVCXlhZGlz\nX3VybHEKVSVodHRwczovL3d3dy5nb29nbGUuY29tL2FjY291bnRzL284L2lkcQtVDHN0YXJ0aW5n\nX3VybHEMWCUAAABodHRwczovL3d3dy5nb29nbGUuY29tL2FjY291bnRzL284L2lkcQ1VC3Nlc3Np\nb25fa2V5cQ5oBFUIX2N1cnJlbnRxD2NvcGVuaWQuY29uc3VtZXIuZGlzY292ZXIKT3BlbklEU2Vy\ndmljZUVuZHBvaW50CnEQKYFxEX1xEihVCmNsYWltZWRfaWRxE05VEmRpc3BsYXlfaWRlbnRpZmll\ncnEUTlUKc2VydmVyX3VybHEVVSVodHRwczovL3d3dy5nb29nbGUuY29tL2FjY291bnRzL284L3Vk\ncRZVC2Nhbm9uaWNhbElEcRdOVQhsb2NhbF9pZHEYTlUJdHlwZV91cmlzcRldcRooVSdodHRwOi8v\nc3BlY3Mub3BlbmlkLm5ldC9hdXRoLzIuMC9zZXJ2ZXJxG1UcaHR0cDovL29wZW5pZC5uZXQvc3J2\nL2F4LzEuMHEcVTRodHRwOi8vc3BlY3Mub3BlbmlkLm5ldC9leHRlbnNpb25zL3VpLzEuMC9tb2Rl\nL3BvcHVwcR1VLmh0dHA6Ly9zcGVjcy5vcGVuaWQubmV0L2V4dGVuc2lvbnMvdWkvMS4wL2ljb25x\nHlUraHR0cDovL3NwZWNzLm9wZW5pZC5uZXQvZXh0ZW5zaW9ucy9wYXBlLzEuMHEfZVUKdXNlZF95\nYWRpc3EgiHVidWJVG19vcGVuaWRfY29uc3VtZXJfbGFzdF90b2tlbnEhaBF1cy4=\n	2011-05-04 23:47:06.448853+00
dbb3bc383dd5a84165fa44ac68e492c8	MmMzYjQzMzQ0ZjQ3MDY3NjBhMzBjMjNmMGZjOTU3OGQ4N2E1MmZjOTqAAn1xAShVBk9QRU5JRHEC\nfXEDVRJfYXV0aF91c2VyX2JhY2tlbmRxBFUlZGphbmdvX29wZW5pZF9hdXRoLmF1dGguT3BlbklE\nQmFja2VuZHEFVQ1fYXV0aF91c2VyX2lkcQZLGHUu\n	2011-05-05 00:02:46.704815+00
5e0b8ceee428a724d94c30f588a258cb	MTNjYTZkMDQ3ZTc5NWVlZGU4MDc3YmE5MmM1NTQzMDZhNmE0YjcyYjqAAn1xAShVBk9QRU5JRHEC\nfXEDVRJfYXV0aF91c2VyX2JhY2tlbmRxBFUlZGphbmdvX29wZW5pZF9hdXRoLmF1dGguT3BlbklE\nQmFja2VuZHEFVQ1fYXV0aF91c2VyX2lkcQZLEnUu\n	2011-05-05 02:29:09.566277+00
6f2cad1c74a23829e4b1e0021ec30c28	Yzc3ZTRiN2E5MzdiNzYxNDJiMjE1Y2RkZWY3MDYzZjcwMzFkMjZiODqAAn1xAShVBk9QRU5JRHEC\nfXEDVRJfYXV0aF91c2VyX2JhY2tlbmRxBFUlZGphbmdvX29wZW5pZF9hdXRoLmF1dGguT3BlbklE\nQmFja2VuZHEFVQ1fYXV0aF91c2VyX2lkcQaKARl1Lg==\n	2011-05-05 07:17:21.443696+00
3efa9a7d7bd6bfe6d2f3a3819ce47709	MGZlOTBjOWRhZTk3ODhmNDEyOTJkMDE3MzI5NzdhMzAwZTEwMDJhZjqAAn1xAShVBk9QRU5JRHEC\nfXEDVRJfYXV0aF91c2VyX2JhY2tlbmRxBFUlZGphbmdvX29wZW5pZF9hdXRoLmF1dGguT3BlbklE\nQmFja2VuZHEFVQ1fYXV0aF91c2VyX2lkcQZLDXUu\n	2011-05-05 07:25:45.504724+00
8b4078c29409e5f8c5ff2012ddaeded7	YjFmOWUyMzMwZTFhNzQ5NWZkMDk4NzdiMTgyMDljYjVkMWQxYTUzMTqAAn1xAShVBk9QRU5JRHEC\nfXEDVRJfYXV0aF91c2VyX2JhY2tlbmRxBFUlZGphbmdvX29wZW5pZF9hdXRoLmF1dGguT3BlbklE\nQmFja2VuZHEFVQ1fYXV0aF91c2VyX2lkcQZLF3Uu\n	2011-05-05 11:01:30.295218+00
c82121bed83cf8c4341c1e39d7de438f	MGZlOTBjOWRhZTk3ODhmNDEyOTJkMDE3MzI5NzdhMzAwZTEwMDJhZjqAAn1xAShVBk9QRU5JRHEC\nfXEDVRJfYXV0aF91c2VyX2JhY2tlbmRxBFUlZGphbmdvX29wZW5pZF9hdXRoLmF1dGguT3BlbklE\nQmFja2VuZHEFVQ1fYXV0aF91c2VyX2lkcQZLDXUu\n	2011-05-05 18:33:27.204376+00
261f1731589fb326789d2bdd88067330	MjgyNjcyMTJkMjMxZjcwNzYwZmEzMGMyYzkyMjE1OGViNzEzMmI1MDqAAn1xAShVBk9QRU5JRHEC\nfXEDVRJfYXV0aF91c2VyX2JhY2tlbmRxBFUlZGphbmdvX29wZW5pZF9hdXRoLmF1dGguT3BlbklE\nQmFja2VuZHEFVQ1fYXV0aF91c2VyX2lkcQZLAXUu\n	2011-05-05 19:29:29.846014+00
9d6b32794f5888910cda207fc651b0d5	ZjU1NmQ4NjEyYTBkZWE3MmNjZjg3ZWMyNjk4ZjdmY2UwYmJjMWMwNDqAAn1xAVUGT1BFTklEcQJ9\ncQNzLg==\n	2011-05-06 05:53:24.318325+00
ea174af7042f98d3de7c1e40e0bd0b97	OGUzMGYwMDI4ZTNkNDRiNGNlNTYzNTU2OWIwNGVhOWViMjQyZWZhNTqAAn1xAS4=\n	2011-05-06 05:57:04.899357+00
ef7ea8d7edde00cff052b097fb35d544	OGUzMGYwMDI4ZTNkNDRiNGNlNTYzNTU2OWIwNGVhOWViMjQyZWZhNTqAAn1xAS4=\n	2011-05-06 05:59:03.042537+00
5cb11dae34ba7860387c7ad41e9e5e03	NmM2ZWM4YjM4NjViYTYyOTlhMjNmOTk1M2Q0NGI0NzhjOGMwY2E3MjqAAn1xAShVBk9QRU5JRHEC\nfXEDVRJfYXV0aF91c2VyX2JhY2tlbmRxBFUlZGphbmdvX29wZW5pZF9hdXRoLmF1dGguT3BlbklE\nQmFja2VuZHEFVQ1fYXV0aF91c2VyX2lkcQaKARt1Lg==\n	2011-05-06 06:58:13.67836+00
c2b7db1e8cc2f4ab3eb7013ddbe7dc81	MjgyNjcyMTJkMjMxZjcwNzYwZmEzMGMyYzkyMjE1OGViNzEzMmI1MDqAAn1xAShVBk9QRU5JRHEC\nfXEDVRJfYXV0aF91c2VyX2JhY2tlbmRxBFUlZGphbmdvX29wZW5pZF9hdXRoLmF1dGguT3BlbklE\nQmFja2VuZHEFVQ1fYXV0aF91c2VyX2lkcQZLAXUu\n	2011-05-06 08:58:07.296096+00
27f0522713d08a0523d2607bcbfc73bd	MjgyNjcyMTJkMjMxZjcwNzYwZmEzMGMyYzkyMjE1OGViNzEzMmI1MDqAAn1xAShVBk9QRU5JRHEC\nfXEDVRJfYXV0aF91c2VyX2JhY2tlbmRxBFUlZGphbmdvX29wZW5pZF9hdXRoLmF1dGguT3BlbklE\nQmFja2VuZHEFVQ1fYXV0aF91c2VyX2lkcQZLAXUu\n	2011-05-06 15:05:11.714455+00
1a417c11c83613aa294d7f78a538a302	MGZlOTBjOWRhZTk3ODhmNDEyOTJkMDE3MzI5NzdhMzAwZTEwMDJhZjqAAn1xAShVBk9QRU5JRHEC\nfXEDVRJfYXV0aF91c2VyX2JhY2tlbmRxBFUlZGphbmdvX29wZW5pZF9hdXRoLmF1dGguT3BlbklE\nQmFja2VuZHEFVQ1fYXV0aF91c2VyX2lkcQZLDXUu\n	2011-05-06 16:12:59.034204+00
9498c0b1b27dd066e94a2e3a716773d0	OGUzMGYwMDI4ZTNkNDRiNGNlNTYzNTU2OWIwNGVhOWViMjQyZWZhNTqAAn1xAS4=\n	2011-05-21 08:12:47.469802+00
97941589e8f8d3d9b32b6c28c7deaaa1	YjFmOWUyMzMwZTFhNzQ5NWZkMDk4NzdiMTgyMDljYjVkMWQxYTUzMTqAAn1xAShVBk9QRU5JRHEC\nfXEDVRJfYXV0aF91c2VyX2JhY2tlbmRxBFUlZGphbmdvX29wZW5pZF9hdXRoLmF1dGguT3BlbklE\nQmFja2VuZHEFVQ1fYXV0aF91c2VyX2lkcQZLF3Uu\n	2011-05-21 11:56:31.749641+00
65c16d1255decfc8edbd2e53d404d611	NWIyNTJmODQ1NThhZTM1M2YwZDRiM2YxZjU0MWI4NzA2YjUwMjIwMTqAAn1xAShVBk9QRU5JRHEC\nfXEDVRJfYXV0aF91c2VyX2JhY2tlbmRxBFUlZGphbmdvX29wZW5pZF9hdXRoLmF1dGguT3BlbklE\nQmFja2VuZHEFVQ1fYXV0aF91c2VyX2lkcQaKASB1Lg==\n	2011-05-24 15:08:52.173665+00
6872cd207b3bd74feb32e259f75a75b4	N2M0NTMwNDM3MGM2MWI4NzExOTdlMWU2MDhhNjhhMTI1NDhkODk4MjqAAn1xAShVBk9QRU5JRHEC\nfXEDVRJfYXV0aF91c2VyX2JhY2tlbmRxBFUlZGphbmdvX29wZW5pZF9hdXRoLmF1dGguT3BlbklE\nQmFja2VuZHEFVQ1fYXV0aF91c2VyX2lkcQZLAnUu\n	2011-05-26 09:29:25.4254+00
e74e5a1edc9bb943bb3899c0d0b8460a	MjgyNjcyMTJkMjMxZjcwNzYwZmEzMGMyYzkyMjE1OGViNzEzMmI1MDqAAn1xAShVBk9QRU5JRHEC\nfXEDVRJfYXV0aF91c2VyX2JhY2tlbmRxBFUlZGphbmdvX29wZW5pZF9hdXRoLmF1dGguT3BlbklE\nQmFja2VuZHEFVQ1fYXV0aF91c2VyX2lkcQZLAXUu\n	2011-05-29 18:22:54.74918+00
ab7fb5aa13ea78eee12af4799b0e9bd8	NGQ2MTIyOGUwMThhNTAwYjc2MjQyYjRmZWQ0NjMzOGY4Y2NmOGE0MDqAAn1xAShVBk9QRU5JRHEC\nfXEDVRJfYXV0aF91c2VyX2JhY2tlbmRxBFUlZGphbmdvX29wZW5pZF9hdXRoLmF1dGguT3BlbklE\nQmFja2VuZHEFVQ1fYXV0aF91c2VyX2lkcQZLHXUu\n	2011-05-31 09:40:02.58079+00
6caeee260cbb8d7666971ec85565a61b	NGQ2MTIyOGUwMThhNTAwYjc2MjQyYjRmZWQ0NjMzOGY4Y2NmOGE0MDqAAn1xAShVBk9QRU5JRHEC\nfXEDVRJfYXV0aF91c2VyX2JhY2tlbmRxBFUlZGphbmdvX29wZW5pZF9hdXRoLmF1dGguT3BlbklE\nQmFja2VuZHEFVQ1fYXV0aF91c2VyX2lkcQZLHXUu\n	2011-05-31 19:56:25.75361+00
f4ebff4f158acf34e769e08c0ec9a69f	MjgyNjcyMTJkMjMxZjcwNzYwZmEzMGMyYzkyMjE1OGViNzEzMmI1MDqAAn1xAShVBk9QRU5JRHEC\nfXEDVRJfYXV0aF91c2VyX2JhY2tlbmRxBFUlZGphbmdvX29wZW5pZF9hdXRoLmF1dGguT3BlbklE\nQmFja2VuZHEFVQ1fYXV0aF91c2VyX2lkcQZLAXUu\n	2011-06-01 09:02:24.789093+00
e687702cdd7af9ce7ce47d4473567201	MjUzZGYwMDQ2ZmFkOWU2NDZiNWY0ODVlY2FhNTkyZjVjMmZiOGNmOTqAAn1xAShVBk9QRU5JRHEC\nfXEDVRJfYXV0aF91c2VyX2JhY2tlbmRxBFUlZGphbmdvX29wZW5pZF9hdXRoLmF1dGguT3BlbklE\nQmFja2VuZHEFVQ1fYXV0aF91c2VyX2lkcQaKASF1Lg==\n	2011-06-02 21:42:43.526057+00
cabb8746e4327adc17eb732cd9720930	YWMyNTc0Y2ExNzdlMDIxZDBmNjM1ZTZhN2M4YzY2ODNmMzMxOTQ5MTqAAn1xAShVBk9QRU5JRHEC\nfXEDVRJfYXV0aF91c2VyX2JhY2tlbmRxBFUlZGphbmdvX29wZW5pZF9hdXRoLmF1dGguT3BlbklE\nQmFja2VuZHEFVQ1fYXV0aF91c2VyX2lkcQZLIXUu\n	2011-06-02 21:42:56.030663+00
53816190b396e284bb33175aba4fb75b	NjliYTQzZjJlYjU3YWQ4NGUxYmM3NjE1MWRjMmI5MGI2ZTcxNTkxNDqAAn1xAShVBk9QRU5JRHEC\nfXEDVRJfYXV0aF91c2VyX2JhY2tlbmRxBFUlZGphbmdvX29wZW5pZF9hdXRoLmF1dGguT3BlbklE\nQmFja2VuZHEFVQ1fYXV0aF91c2VyX2lkcQaKASJ1Lg==\n	2011-06-04 19:18:42.676652+00
bcfa02b1b39e5c13482702c5409966e1	OWYzNGVhZjlkNTIzMTcyYTliNTFmZGEyZmE2MDdmNGFjMDNhZTY0ZDqAAn1xAShVBk9QRU5JRHEC\nfXEDVRJfYXV0aF91c2VyX2JhY2tlbmRxBFUlZGphbmdvX29wZW5pZF9hdXRoLmF1dGguT3BlbklE\nQmFja2VuZHEFVQ1fYXV0aF91c2VyX2lkcQZLDnUu\n	2011-06-06 13:06:54.823178+00
99f841b784108a35f7963ba340e17112	Y2QyYWFhZWYzNTlkMzM2NDMyMDVlZDYzMjgzMjcwMDdiN2E1ODY3NDqAAn1xAShVBk9QRU5JRHEC\nfXEDVQ1fYXV0aF91c2VyX2lkcQRLI1USX2F1dGhfdXNlcl9iYWNrZW5kcQVVJWRqYW5nb19vcGVu\naWRfYXV0aC5hdXRoLk9wZW5JREJhY2tlbmRxBnUu\n	2011-06-05 00:19:36.022155+00
4d1b8ee573781f418b2f7edded527541	YjFmOWUyMzMwZTFhNzQ5NWZkMDk4NzdiMTgyMDljYjVkMWQxYTUzMTqAAn1xAShVBk9QRU5JRHEC\nfXEDVRJfYXV0aF91c2VyX2JhY2tlbmRxBFUlZGphbmdvX29wZW5pZF9hdXRoLmF1dGguT3BlbklE\nQmFja2VuZHEFVQ1fYXV0aF91c2VyX2lkcQZLF3Uu\n	2011-06-07 12:02:47.22601+00
adf421fcd3e20dd341a86866626d9e28	M2Q4ZTQxMGVmZGEzNTZlOTEwNzY1OTM3MTE3ODcxYzY1NTE0ZTkxZjqAAn1xAShVBk9QRU5JRHEC\nfXEDVRJfYXV0aF91c2VyX2JhY2tlbmRxBFUlZGphbmdvX29wZW5pZF9hdXRoLmF1dGguT3BlbklE\nQmFja2VuZHEFVQ1fYXV0aF91c2VyX2lkcQaKASR1Lg==\n	2011-06-08 13:10:12.862421+00
ed7edbd21eb52603fef04a7009595343	OWFkZGY0ZjU1ZTVkNWQ4YzYyYjZiNDA4Y2Q3NDZkYjdjNjUyMGQxZTqAAn1xAShVBk9QRU5JRHEC\nfXEDVRJfYXV0aF91c2VyX2JhY2tlbmRxBFUlZGphbmdvX29wZW5pZF9hdXRoLmF1dGguT3BlbklE\nQmFja2VuZHEFVQ1fYXV0aF91c2VyX2lkcQaKARx1Lg==\n	2011-05-06 16:18:46.154205+00
0d3c830484673a4b24397c69cf7f778c	ZjU1NmQ4NjEyYTBkZWE3MmNjZjg3ZWMyNjk4ZjdmY2UwYmJjMWMwNDqAAn1xAVUGT1BFTklEcQJ9\ncQNzLg==\n	2011-05-06 16:23:01.794378+00
2a961d79ca8c334a734ecc9cebd090d5	MjgyNjcyMTJkMjMxZjcwNzYwZmEzMGMyYzkyMjE1OGViNzEzMmI1MDqAAn1xAShVBk9QRU5JRHEC\nfXEDVRJfYXV0aF91c2VyX2JhY2tlbmRxBFUlZGphbmdvX29wZW5pZF9hdXRoLmF1dGguT3BlbklE\nQmFja2VuZHEFVQ1fYXV0aF91c2VyX2lkcQZLAXUu\n	2011-05-09 20:58:25.320036+00
16762840111551e816ca02aabd61bcea	MjgyNjcyMTJkMjMxZjcwNzYwZmEzMGMyYzkyMjE1OGViNzEzMmI1MDqAAn1xAShVBk9QRU5JRHEC\nfXEDVRJfYXV0aF91c2VyX2JhY2tlbmRxBFUlZGphbmdvX29wZW5pZF9hdXRoLmF1dGguT3BlbklE\nQmFja2VuZHEFVQ1fYXV0aF91c2VyX2lkcQZLAXUu\n	2011-05-06 17:29:32.586013+00
2e0fd63da61c831a6d5f1e662dc2bce5	NmM3ODIzODY0N2Q4NWRmNzc1MDhkNTNmYzE1OTQxMmZhNGY5OWJiYTqAAn1xAVUGT1BFTklEcQJ9\ncQMoVSFfeWFkaXNfc2VydmljZXNfX29wZW5pZF9jb25zdW1lcl9xBGNvcGVuaWQueWFkaXMubWFu\nYWdlcgpZYWRpc1NlcnZpY2VNYW5hZ2VyCnEFKYFxBn1xByhVCHNlcnZpY2VzcQhdcQlVCXlhZGlz\nX3VybHEKVSVodHRwczovL3d3dy5nb29nbGUuY29tL2FjY291bnRzL284L2lkcQtVDHN0YXJ0aW5n\nX3VybHEMWCUAAABodHRwczovL3d3dy5nb29nbGUuY29tL2FjY291bnRzL284L2lkcQ1VC3Nlc3Np\nb25fa2V5cQ5oBFUIX2N1cnJlbnRxD2NvcGVuaWQuY29uc3VtZXIuZGlzY292ZXIKT3BlbklEU2Vy\ndmljZUVuZHBvaW50CnEQKYFxEX1xEihVCmNsYWltZWRfaWRxE05VEmRpc3BsYXlfaWRlbnRpZmll\ncnEUTlUKc2VydmVyX3VybHEVVSVodHRwczovL3d3dy5nb29nbGUuY29tL2FjY291bnRzL284L3Vk\ncRZVC2Nhbm9uaWNhbElEcRdOVQhsb2NhbF9pZHEYTlUJdHlwZV91cmlzcRldcRooVSdodHRwOi8v\nc3BlY3Mub3BlbmlkLm5ldC9hdXRoLzIuMC9zZXJ2ZXJxG1UcaHR0cDovL29wZW5pZC5uZXQvc3J2\nL2F4LzEuMHEcVTRodHRwOi8vc3BlY3Mub3BlbmlkLm5ldC9leHRlbnNpb25zL3VpLzEuMC9tb2Rl\nL3BvcHVwcR1VLmh0dHA6Ly9zcGVjcy5vcGVuaWQubmV0L2V4dGVuc2lvbnMvdWkvMS4wL2ljb25x\nHlUraHR0cDovL3NwZWNzLm9wZW5pZC5uZXQvZXh0ZW5zaW9ucy9wYXBlLzEuMHEfZVUKdXNlZF95\nYWRpc3EgiHVidWJVG19vcGVuaWRfY29uc3VtZXJfbGFzdF90b2tlbnEhaBF1cy4=\n	2011-05-06 18:48:26.448116+00
09e1112e8df668547ad892a5c30cb502	ODdkNWRmOWM4OTFkYTU0NTA4N2VhOGQ2OGRhZDNjMTU3MThhM2RlYTqAAn1xAShVBk9QRU5JRHEC\nfXEDVRJfYXV0aF91c2VyX2JhY2tlbmRxBFUlZGphbmdvX29wZW5pZF9hdXRoLmF1dGguT3BlbklE\nQmFja2VuZHEFVQ1fYXV0aF91c2VyX2lkcQaKAR11Lg==\n	2011-05-11 07:29:06.685721+00
10d02c878b46b021bcc0100d6a329b70	NWMzNzQ2MGU2OWRjYTEwN2ZlNzU3YWJiNTgwMmQ1ZGYyNTRiNzU3ZjqAAn1xAShVBk9QRU5JRHEC\nfXEDVRJfYXV0aF91c2VyX2JhY2tlbmRxBFUlZGphbmdvX29wZW5pZF9hdXRoLmF1dGguT3BlbklE\nQmFja2VuZHEFVQ1fYXV0aF91c2VyX2lkcQaKAR51Lg==\n	2011-05-11 19:24:27.535074+00
1fb1c7b0234643c52d2b421e525d0983	MjgyNjcyMTJkMjMxZjcwNzYwZmEzMGMyYzkyMjE1OGViNzEzMmI1MDqAAn1xAShVBk9QRU5JRHEC\nfXEDVRJfYXV0aF91c2VyX2JhY2tlbmRxBFUlZGphbmdvX29wZW5pZF9hdXRoLmF1dGguT3BlbklE\nQmFja2VuZHEFVQ1fYXV0aF91c2VyX2lkcQZLAXUu\n	2011-05-11 20:02:03.963973+00
eb3373d669da05366d20edd54c1bc543	MjgyNjcyMTJkMjMxZjcwNzYwZmEzMGMyYzkyMjE1OGViNzEzMmI1MDqAAn1xAShVBk9QRU5JRHEC\nfXEDVRJfYXV0aF91c2VyX2JhY2tlbmRxBFUlZGphbmdvX29wZW5pZF9hdXRoLmF1dGguT3BlbklE\nQmFja2VuZHEFVQ1fYXV0aF91c2VyX2lkcQZLAXUu\n	2011-05-18 06:10:51.683205+00
98e3c66c82741ddd3a66c7dde9f0f025	MjgyNjcyMTJkMjMxZjcwNzYwZmEzMGMyYzkyMjE1OGViNzEzMmI1MDqAAn1xAShVBk9QRU5JRHEC\nfXEDVRJfYXV0aF91c2VyX2JhY2tlbmRxBFUlZGphbmdvX29wZW5pZF9hdXRoLmF1dGguT3BlbklE\nQmFja2VuZHEFVQ1fYXV0aF91c2VyX2lkcQZLAXUu\n	2011-05-11 21:50:31.696354+00
590d8d3da6c47bd722a50e9bb7398e0c	OGUzMGYwMDI4ZTNkNDRiNGNlNTYzNTU2OWIwNGVhOWViMjQyZWZhNTqAAn1xAS4=\n	2011-05-12 07:09:06.74405+00
fd81444002a2a1c41424bd3929856e6e	MjgyNjcyMTJkMjMxZjcwNzYwZmEzMGMyYzkyMjE1OGViNzEzMmI1MDqAAn1xAShVBk9QRU5JRHEC\nfXEDVRJfYXV0aF91c2VyX2JhY2tlbmRxBFUlZGphbmdvX29wZW5pZF9hdXRoLmF1dGguT3BlbklE\nQmFja2VuZHEFVQ1fYXV0aF91c2VyX2lkcQZLAXUu\n	2011-05-12 19:37:20.488395+00
d8c09187c290f6988a724cd1ff1a582e	MGMxZThkMTY0NzA5NWRmYjA3ZjNmMzM5YjhiMmU1MGRmZGM2M2IyNzqAAn1xAShVBk9QRU5JRHEC\nfXEDVRJfYXV0aF91c2VyX2JhY2tlbmRxBFUlZGphbmdvX29wZW5pZF9hdXRoLmF1dGguT3BlbklE\nQmFja2VuZHEFVQ1fYXV0aF91c2VyX2lkcQaKAR91Lg==\n	2011-05-13 00:04:09.674736+00
08b0e2f723c0604e1a8feac6d1b970ad	MjgyNjcyMTJkMjMxZjcwNzYwZmEzMGMyYzkyMjE1OGViNzEzMmI1MDqAAn1xAShVBk9QRU5JRHEC\nfXEDVRJfYXV0aF91c2VyX2JhY2tlbmRxBFUlZGphbmdvX29wZW5pZF9hdXRoLmF1dGguT3BlbklE\nQmFja2VuZHEFVQ1fYXV0aF91c2VyX2lkcQZLAXUu\n	2011-05-13 01:04:27.94514+00
b53eb7fe132fb8452696515a320935d1	MjgyNjcyMTJkMjMxZjcwNzYwZmEzMGMyYzkyMjE1OGViNzEzMmI1MDqAAn1xAShVBk9QRU5JRHEC\nfXEDVRJfYXV0aF91c2VyX2JhY2tlbmRxBFUlZGphbmdvX29wZW5pZF9hdXRoLmF1dGguT3BlbklE\nQmFja2VuZHEFVQ1fYXV0aF91c2VyX2lkcQZLAXUu\n	2011-05-13 15:11:42.70874+00
18adceff00fcbe2caefa9efc16b1978d	N2M0NTMwNDM3MGM2MWI4NzExOTdlMWU2MDhhNjhhMTI1NDhkODk4MjqAAn1xAShVBk9QRU5JRHEC\nfXEDVRJfYXV0aF91c2VyX2JhY2tlbmRxBFUlZGphbmdvX29wZW5pZF9hdXRoLmF1dGguT3BlbklE\nQmFja2VuZHEFVQ1fYXV0aF91c2VyX2lkcQZLAnUu\n	2011-05-18 08:51:33.979756+00
6adc146d0ccf0e5234c8ad2676dd533c	MjgyNjcyMTJkMjMxZjcwNzYwZmEzMGMyYzkyMjE1OGViNzEzMmI1MDqAAn1xAShVBk9QRU5JRHEC\nfXEDVRJfYXV0aF91c2VyX2JhY2tlbmRxBFUlZGphbmdvX29wZW5pZF9hdXRoLmF1dGguT3BlbklE\nQmFja2VuZHEFVQ1fYXV0aF91c2VyX2lkcQZLAXUu\n	2011-05-18 08:51:36.235741+00
c86f0bf67a3ea768a6e599f0d550b49f	MjgyNjcyMTJkMjMxZjcwNzYwZmEzMGMyYzkyMjE1OGViNzEzMmI1MDqAAn1xAShVBk9QRU5JRHEC\nfXEDVRJfYXV0aF91c2VyX2JhY2tlbmRxBFUlZGphbmdvX29wZW5pZF9hdXRoLmF1dGguT3BlbklE\nQmFja2VuZHEFVQ1fYXV0aF91c2VyX2lkcQZLAXUu\n	2011-05-20 05:30:15.067664+00
6f753159c9c9f983ed8a29ee431c2c27	NmM3ODIzODY0N2Q4NWRmNzc1MDhkNTNmYzE1OTQxMmZhNGY5OWJiYTqAAn1xAVUGT1BFTklEcQJ9\ncQMoVSFfeWFkaXNfc2VydmljZXNfX29wZW5pZF9jb25zdW1lcl9xBGNvcGVuaWQueWFkaXMubWFu\nYWdlcgpZYWRpc1NlcnZpY2VNYW5hZ2VyCnEFKYFxBn1xByhVCHNlcnZpY2VzcQhdcQlVCXlhZGlz\nX3VybHEKVSVodHRwczovL3d3dy5nb29nbGUuY29tL2FjY291bnRzL284L2lkcQtVDHN0YXJ0aW5n\nX3VybHEMWCUAAABodHRwczovL3d3dy5nb29nbGUuY29tL2FjY291bnRzL284L2lkcQ1VC3Nlc3Np\nb25fa2V5cQ5oBFUIX2N1cnJlbnRxD2NvcGVuaWQuY29uc3VtZXIuZGlzY292ZXIKT3BlbklEU2Vy\ndmljZUVuZHBvaW50CnEQKYFxEX1xEihVCmNsYWltZWRfaWRxE05VEmRpc3BsYXlfaWRlbnRpZmll\ncnEUTlUKc2VydmVyX3VybHEVVSVodHRwczovL3d3dy5nb29nbGUuY29tL2FjY291bnRzL284L3Vk\ncRZVC2Nhbm9uaWNhbElEcRdOVQhsb2NhbF9pZHEYTlUJdHlwZV91cmlzcRldcRooVSdodHRwOi8v\nc3BlY3Mub3BlbmlkLm5ldC9hdXRoLzIuMC9zZXJ2ZXJxG1UcaHR0cDovL29wZW5pZC5uZXQvc3J2\nL2F4LzEuMHEcVTRodHRwOi8vc3BlY3Mub3BlbmlkLm5ldC9leHRlbnNpb25zL3VpLzEuMC9tb2Rl\nL3BvcHVwcR1VLmh0dHA6Ly9zcGVjcy5vcGVuaWQubmV0L2V4dGVuc2lvbnMvdWkvMS4wL2ljb25x\nHlUraHR0cDovL3NwZWNzLm9wZW5pZC5uZXQvZXh0ZW5zaW9ucy9wYXBlLzEuMHEfZVUKdXNlZF95\nYWRpc3EgiHVidWJVG19vcGVuaWRfY29uc3VtZXJfbGFzdF90b2tlbnEhaBF1cy4=\n	2011-06-02 21:42:37.502253+00
ac46c1db27b141f06854339dede4c514	MjgyNjcyMTJkMjMxZjcwNzYwZmEzMGMyYzkyMjE1OGViNzEzMmI1MDqAAn1xAShVBk9QRU5JRHEC\nfXEDVRJfYXV0aF91c2VyX2JhY2tlbmRxBFUlZGphbmdvX29wZW5pZF9hdXRoLmF1dGguT3BlbklE\nQmFja2VuZHEFVQ1fYXV0aF91c2VyX2lkcQZLAXUu\n	2011-06-10 07:19:29.627382+00
920a28e56f41559348a4edb3e3032338	NWE0ODc4MjQ2MWE1NzI1Y2NjOGRlNGQ5Mjg3OGM2MGY4MWIyYTg4YjqAAn1xAShVBk9QRU5JRHEC\nfXEDVRJfYXV0aF91c2VyX2JhY2tlbmRxBFUlZGphbmdvX29wZW5pZF9hdXRoLmF1dGguT3BlbklE\nQmFja2VuZHEFVQ1fYXV0aF91c2VyX2lkcQaKASV1Lg==\n	2011-06-10 19:02:14.369705+00
f8225461317ed0b901383f6dcc58055c	YjZkNzI0OTUxYzc0NTc4MTBmZTZmMmI3MDBjZjJhYTM5MjUzNzMzZDqAAn1xAShVBk9QRU5JRHEC\nfXEDVRJfYXV0aF91c2VyX2JhY2tlbmRxBFUlZGphbmdvX29wZW5pZF9hdXRoLmF1dGguT3BlbklE\nQmFja2VuZHEFVQ1fYXV0aF91c2VyX2lkcQaKASZ1Lg==\n	2011-06-12 18:37:34.893035+00
4637448a79d53ac8233fe7f4d6c51bf0	N2M0NTMwNDM3MGM2MWI4NzExOTdlMWU2MDhhNjhhMTI1NDhkODk4MjqAAn1xAShVBk9QRU5JRHEC\nfXEDVRJfYXV0aF91c2VyX2JhY2tlbmRxBFUlZGphbmdvX29wZW5pZF9hdXRoLmF1dGguT3BlbklE\nQmFja2VuZHEFVQ1fYXV0aF91c2VyX2lkcQZLAnUu\n	2011-06-14 04:34:06.32398+00
52524290fec6e935a283fe254f71da91	N2M0NTMwNDM3MGM2MWI4NzExOTdlMWU2MDhhNjhhMTI1NDhkODk4MjqAAn1xAShVBk9QRU5JRHEC\nfXEDVRJfYXV0aF91c2VyX2JhY2tlbmRxBFUlZGphbmdvX29wZW5pZF9hdXRoLmF1dGguT3BlbklE\nQmFja2VuZHEFVQ1fYXV0aF91c2VyX2lkcQZLAnUu\n	2011-06-14 08:26:32.813586+00
a2d201f635ff9a28fd8f5916d398e104	N2M0NTMwNDM3MGM2MWI4NzExOTdlMWU2MDhhNjhhMTI1NDhkODk4MjqAAn1xAShVBk9QRU5JRHEC\nfXEDVRJfYXV0aF91c2VyX2JhY2tlbmRxBFUlZGphbmdvX29wZW5pZF9hdXRoLmF1dGguT3BlbklE\nQmFja2VuZHEFVQ1fYXV0aF91c2VyX2lkcQZLAnUu\n	2011-06-14 08:34:59.136972+00
7fdeec925c2c7a2bdfc023f3da478d36	MjVmYzFjMTBhNGUxZDNjMWY4MzQyNTJmODQzN2M4YjZiYmJjZGRkYzqAAn1xAShVBk9QRU5JRHEC\nfXEDVRJfYXV0aF91c2VyX2JhY2tlbmRxBFUlZGphbmdvX29wZW5pZF9hdXRoLmF1dGguT3BlbklE\nQmFja2VuZHEFVQ1fYXV0aF91c2VyX2lkcQaKATB1Lg==\n	2011-09-04 14:20:08.535834+00
23375c5f1d1b607b1d70c11c4ed6ff3a	MjgyNjcyMTJkMjMxZjcwNzYwZmEzMGMyYzkyMjE1OGViNzEzMmI1MDqAAn1xAShVBk9QRU5JRHEC\nfXEDVRJfYXV0aF91c2VyX2JhY2tlbmRxBFUlZGphbmdvX29wZW5pZF9hdXRoLmF1dGguT3BlbklE\nQmFja2VuZHEFVQ1fYXV0aF91c2VyX2lkcQZLAXUu\n	2011-06-15 09:42:11.664111+00
ddb301d31b9b940d5a90a0a0460d7b49	MWJjMjc2NDdjZjViNWM2M2RjZmYxNGQzM2VlNWEyNjNhYjhmNWU3OTqAAn1xAVUGT1BFTklEcQJ9\ncQMoVSFfeWFkaXNfc2VydmljZXNfX29wZW5pZF9jb25zdW1lcl9xBGNvcGVuaWQueWFkaXMubWFu\nYWdlcgpZYWRpc1NlcnZpY2VNYW5hZ2VyCnEFKYFxBn1xByhVCHNlcnZpY2VzcQhdcQlVCXlhZGlz\nX3VybHEKVRVodHRwczovL21lLnlhaG9vLmNvbS9xC1UMc3RhcnRpbmdfdXJscQxYFAAAAGh0dHA6\nLy9tZS55YWhvby5jb20vcQ1VC3Nlc3Npb25fa2V5cQ5oBFUIX2N1cnJlbnRxD2NvcGVuaWQuY29u\nc3VtZXIuZGlzY292ZXIKT3BlbklEU2VydmljZUVuZHBvaW50CnEQKYFxEX1xEihVCmNsYWltZWRf\naWRxE05VEmRpc3BsYXlfaWRlbnRpZmllcnEUTlUKc2VydmVyX3VybHEVVS9odHRwczovL29wZW4u\nbG9naW4ueWFob29hcGlzLmNvbS9vcGVuaWQvb3AvYXV0aHEWVQtjYW5vbmljYWxJRHEXTlUIbG9j\nYWxfaWRxGE5VCXR5cGVfdXJpc3EZXXEaKFUnaHR0cDovL3NwZWNzLm9wZW5pZC5uZXQvYXV0aC8y\nLjAvc2VydmVycRtVK2h0dHA6Ly9zcGVjcy5vcGVuaWQubmV0L2V4dGVuc2lvbnMvcGFwZS8xLjBx\nHFUcaHR0cDovL29wZW5pZC5uZXQvc3J2L2F4LzEuMHEdVSxodHRwOi8vc3BlY3Mub3BlbmlkLm5l\ndC9leHRlbnNpb25zL29hdXRoLzEuMHEeVTNodHRwOi8vc3BlY3Mub3BlbmlkLm5ldC9leHRlbnNp\nb25zL3VpLzEuMC9sYW5nLXByZWZxH1U0aHR0cDovL3NwZWNzLm9wZW5pZC5uZXQvZXh0ZW5zaW9u\ncy91aS8xLjAvbW9kZS9wb3B1cHEgVU9odHRwOi8vc2NoZW1hcy54bWxzb2FwLm9yZy93cy8yMDA1\nLzA1L2lkZW50aXR5L2NsYWltcy9wcml2YXRlcGVyc29uYWxpZGVudGlmaWVycSFVOmh0dHA6Ly93\nd3cuaWRtYW5hZ2VtZW50Lmdvdi9zY2hlbWEvMjAwOS8wNS9pY2FtL25vLXBpaS5wZGZxIlVHaHR0\ncDovL3d3dy5pZG1hbmFnZW1lbnQuZ292L3NjaGVtYS8yMDA5LzA1L2ljYW0vb3BlbmlkLXRydXN0\nLWxldmVsMS5wZGZxI1VEaHR0cDovL2NzcmMubmlzdC5nb3YvcHVibGljYXRpb25zL25pc3RwdWJz\nLzgwMC02My9TUDgwMC02M1YxXzBfMi5wZGZxJGVVCnVzZWRfeWFkaXNxJYh1YnViVRtfb3Blbmlk\nX2NvbnN1bWVyX2xhc3RfdG9rZW5xJmgRdXMu\n	2011-06-17 22:44:19.039198+00
c0a4a5c3fa18f2ca4b9d9b1fc1ca0224	ZTk5ZDc0NTNhZGYzMWQ2ZjY1ZTJjN2YxNzVjMGM5ODllMGYwYzgxYzqAAn1xAShVBk9QRU5JRHEC\nfXEDVRJfYXV0aF91c2VyX2JhY2tlbmRxBFUlZGphbmdvX29wZW5pZF9hdXRoLmF1dGguT3BlbklE\nQmFja2VuZHEFVQ1fYXV0aF91c2VyX2lkcQaKASd1Lg==\n	2011-06-25 21:41:41.222221+00
b600fbcf50ef107ceb99ca34d21f78a2	N2VmYjE5ZGU4NTViZTE0OGQxMjkyMzMxZTNlYTRhOTI3ODgyMGYyNTqAAn1xAShVBk9QRU5JRHEC\nfXEDVRJfYXV0aF91c2VyX2JhY2tlbmRxBFUlZGphbmdvX29wZW5pZF9hdXRoLmF1dGguT3BlbklE\nQmFja2VuZHEFVQ1fYXV0aF91c2VyX2lkcQZLMXUu\n	2011-09-12 09:55:40.956624+00
91dfbd6f794218221aaeccc7071a06bd	N2M0NTMwNDM3MGM2MWI4NzExOTdlMWU2MDhhNjhhMTI1NDhkODk4MjqAAn1xAShVBk9QRU5JRHEC\nfXEDVRJfYXV0aF91c2VyX2JhY2tlbmRxBFUlZGphbmdvX29wZW5pZF9hdXRoLmF1dGguT3BlbklE\nQmFja2VuZHEFVQ1fYXV0aF91c2VyX2lkcQZLAnUu\n	2011-06-28 06:43:32.03107+00
e7db7ac5cccab51f0d6d3095cf2d84ff	MGJiOGJmODYyMmFjMTY5NmI5Yzc2MjQzOWM4NDZlZjcwNTVhMzY1ZTqAAn1xAShVBk9QRU5JRHEC\nfXEDVRJfYXV0aF91c2VyX2JhY2tlbmRxBFUlZGphbmdvX29wZW5pZF9hdXRoLmF1dGguT3BlbklE\nQmFja2VuZHEFVQ1fYXV0aF91c2VyX2lkcQaKASh1Lg==\n	2011-06-30 08:11:18.003519+00
bf39f460fc5b4114551e16484250649f	MzcwODVjYjMxMWFhYTAxZDE1YjNjZWZlNzQ3Y2M5OTI5NDhmZTZiZjqAAn1xAShVBk9QRU5JRHEC\nfXEDVRJfYXV0aF91c2VyX2JhY2tlbmRxBFUlZGphbmdvX29wZW5pZF9hdXRoLmF1dGguT3BlbklE\nQmFja2VuZHEFVQ1fYXV0aF91c2VyX2lkcQaKATJ1Lg==\n	2011-09-28 17:40:02.25129+00
7af7f6cb420d891a450a856a3268ddf7	MjgyNjcyMTJkMjMxZjcwNzYwZmEzMGMyYzkyMjE1OGViNzEzMmI1MDqAAn1xAShVBk9QRU5JRHEC\nfXEDVRJfYXV0aF91c2VyX2JhY2tlbmRxBFUlZGphbmdvX29wZW5pZF9hdXRoLmF1dGguT3BlbklE\nQmFja2VuZHEFVQ1fYXV0aF91c2VyX2lkcQZLAXUu\n	2011-07-02 18:48:58.979142+00
d2186b50981fb47646f12b081e4d7a5e	NGIxYmRhNWZkOTlkYTliZTZlMmUzN2NkODBkNTdiOWM3ZDMzZGM1MzqAAn1xAShVBk9QRU5JRHEC\nfXEDVQ1fYXV0aF91c2VyX2lkcQRLKVUSX2F1dGhfdXNlcl9iYWNrZW5kcQVVJWRqYW5nb19vcGVu\naWRfYXV0aC5hdXRoLk9wZW5JREJhY2tlbmRxBnUu\n	2011-10-26 18:20:29.997817+00
dc6fee46d72b569df5f965b00530f609	NGQ2MTIyOGUwMThhNTAwYjc2MjQyYjRmZWQ0NjMzOGY4Y2NmOGE0MDqAAn1xAShVBk9QRU5JRHEC\nfXEDVRJfYXV0aF91c2VyX2JhY2tlbmRxBFUlZGphbmdvX29wZW5pZF9hdXRoLmF1dGguT3BlbklE\nQmFja2VuZHEFVQ1fYXV0aF91c2VyX2lkcQZLHXUu\n	2011-07-06 11:50:42.505455+00
d9364391970c9027691f8a62218ded96	N2M0NTMwNDM3MGM2MWI4NzExOTdlMWU2MDhhNjhhMTI1NDhkODk4MjqAAn1xAShVBk9QRU5JRHEC\nfXEDVRJfYXV0aF91c2VyX2JhY2tlbmRxBFUlZGphbmdvX29wZW5pZF9hdXRoLmF1dGguT3BlbklE\nQmFja2VuZHEFVQ1fYXV0aF91c2VyX2lkcQZLAnUu\n	2011-07-07 07:38:51.217252+00
c8e722c33f30e67c1876ca96ed6198ed	MjgyNjcyMTJkMjMxZjcwNzYwZmEzMGMyYzkyMjE1OGViNzEzMmI1MDqAAn1xAShVBk9QRU5JRHEC\nfXEDVRJfYXV0aF91c2VyX2JhY2tlbmRxBFUlZGphbmdvX29wZW5pZF9hdXRoLmF1dGguT3BlbklE\nQmFja2VuZHEFVQ1fYXV0aF91c2VyX2lkcQZLAXUu\n	2011-07-12 02:30:02.516893+00
ae4d74ca319fdf88d6294ab917241a73	N2M0NTMwNDM3MGM2MWI4NzExOTdlMWU2MDhhNjhhMTI1NDhkODk4MjqAAn1xAShVBk9QRU5JRHEC\nfXEDVRJfYXV0aF91c2VyX2JhY2tlbmRxBFUlZGphbmdvX29wZW5pZF9hdXRoLmF1dGguT3BlbklE\nQmFja2VuZHEFVQ1fYXV0aF91c2VyX2lkcQZLAnUu\n	2011-07-12 07:22:00.638575+00
dfe65a4a5df3fe7a20a179cb1f7f1076	YTRlNTViMTg2NDM1NTc5NTdiZjEzZjBjN2VkYjZhMWY1ZjFjYWFkNzqAAn1xAShVBk9QRU5JRHEC\nfXEDVRJfYXV0aF91c2VyX2JhY2tlbmRxBFUlZGphbmdvX29wZW5pZF9hdXRoLmF1dGguT3BlbklE\nQmFja2VuZHEFVQ1fYXV0aF91c2VyX2lkcQaKASl1Lg==\n	2011-07-13 23:37:33.761369+00
4c2ec714e05f72652ebfa545b939715d	MWJjMjc2NDdjZjViNWM2M2RjZmYxNGQzM2VlNWEyNjNhYjhmNWU3OTqAAn1xAVUGT1BFTklEcQJ9\ncQMoVSFfeWFkaXNfc2VydmljZXNfX29wZW5pZF9jb25zdW1lcl9xBGNvcGVuaWQueWFkaXMubWFu\nYWdlcgpZYWRpc1NlcnZpY2VNYW5hZ2VyCnEFKYFxBn1xByhVCHNlcnZpY2VzcQhdcQlVCXlhZGlz\nX3VybHEKVRVodHRwczovL21lLnlhaG9vLmNvbS9xC1UMc3RhcnRpbmdfdXJscQxYFAAAAGh0dHA6\nLy9tZS55YWhvby5jb20vcQ1VC3Nlc3Npb25fa2V5cQ5oBFUIX2N1cnJlbnRxD2NvcGVuaWQuY29u\nc3VtZXIuZGlzY292ZXIKT3BlbklEU2VydmljZUVuZHBvaW50CnEQKYFxEX1xEihVCmNsYWltZWRf\naWRxE05VEmRpc3BsYXlfaWRlbnRpZmllcnEUTlUKc2VydmVyX3VybHEVVS9odHRwczovL29wZW4u\nbG9naW4ueWFob29hcGlzLmNvbS9vcGVuaWQvb3AvYXV0aHEWVQtjYW5vbmljYWxJRHEXTlUIbG9j\nYWxfaWRxGE5VCXR5cGVfdXJpc3EZXXEaKFUnaHR0cDovL3NwZWNzLm9wZW5pZC5uZXQvYXV0aC8y\nLjAvc2VydmVycRtVK2h0dHA6Ly9zcGVjcy5vcGVuaWQubmV0L2V4dGVuc2lvbnMvcGFwZS8xLjBx\nHFUcaHR0cDovL29wZW5pZC5uZXQvc3J2L2F4LzEuMHEdVSxodHRwOi8vc3BlY3Mub3BlbmlkLm5l\ndC9leHRlbnNpb25zL29hdXRoLzEuMHEeVTNodHRwOi8vc3BlY3Mub3BlbmlkLm5ldC9leHRlbnNp\nb25zL3VpLzEuMC9sYW5nLXByZWZxH1U0aHR0cDovL3NwZWNzLm9wZW5pZC5uZXQvZXh0ZW5zaW9u\ncy91aS8xLjAvbW9kZS9wb3B1cHEgVU9odHRwOi8vc2NoZW1hcy54bWxzb2FwLm9yZy93cy8yMDA1\nLzA1L2lkZW50aXR5L2NsYWltcy9wcml2YXRlcGVyc29uYWxpZGVudGlmaWVycSFVOmh0dHA6Ly93\nd3cuaWRtYW5hZ2VtZW50Lmdvdi9zY2hlbWEvMjAwOS8wNS9pY2FtL25vLXBpaS5wZGZxIlVHaHR0\ncDovL3d3dy5pZG1hbmFnZW1lbnQuZ292L3NjaGVtYS8yMDA5LzA1L2ljYW0vb3BlbmlkLXRydXN0\nLWxldmVsMS5wZGZxI1VEaHR0cDovL2NzcmMubmlzdC5nb3YvcHVibGljYXRpb25zL25pc3RwdWJz\nLzgwMC02My9TUDgwMC02M1YxXzBfMi5wZGZxJGVVCnVzZWRfeWFkaXNxJYh1YnViVRtfb3Blbmlk\nX2NvbnN1bWVyX2xhc3RfdG9rZW5xJmgRdXMu\n	2011-07-14 02:25:17.63147+00
616302d633de7c1f4a42715032f4987b	OGUzMGYwMDI4ZTNkNDRiNGNlNTYzNTU2OWIwNGVhOWViMjQyZWZhNTqAAn1xAS4=\n	2011-07-14 02:29:26.426371+00
6995b05af1dbd4af259c330e3d813d74	MzlhMjYzYmI4ZDAyYjY2YTFkMGM0MGIzZGNjZjc5YzY5NGIwMThjYTqAAn1xAShVBk9QRU5JRHEC\nfXEDVQ1fYXV0aF91c2VyX2lkcQRLK1USX2F1dGhfdXNlcl9iYWNrZW5kcQVVJWRqYW5nb19vcGVu\naWRfYXV0aC5hdXRoLk9wZW5JREJhY2tlbmRxBnUu\n	2011-07-14 22:51:49.042089+00
32ac55608173917818290e2aa6576e16	YTg1ZjNkZGY3MmJjNjlhNjkxODdiY2ZiNmEzZmFmYjdmZTc2YTVjZDqAAn1xAShVBk9QRU5JRHEC\nfXEDVRJfYXV0aF91c2VyX2JhY2tlbmRxBFUlZGphbmdvX29wZW5pZF9hdXRoLmF1dGguT3BlbklE\nQmFja2VuZHEFVQ1fYXV0aF91c2VyX2lkcQaKASx1Lg==\n	2011-07-15 16:31:16.058134+00
add2df599d53fdd6abf34ac35523b46c	YThhMTcyZGViZjQwMGFmMzYwODRhODEyNmU1YzEyNWVjMjg1YjJiMDqAAn1xAShVBk9QRU5JRHEC\nfXEDVRJfYXV0aF91c2VyX2JhY2tlbmRxBFUlZGphbmdvX29wZW5pZF9hdXRoLmF1dGguT3BlbklE\nQmFja2VuZHEFVQ1fYXV0aF91c2VyX2lkcQaKAS11Lg==\n	2011-07-15 21:32:25.404424+00
dedacb3a36102d3a93a8d3d61426eb0d	NGQ2MTIyOGUwMThhNTAwYjc2MjQyYjRmZWQ0NjMzOGY4Y2NmOGE0MDqAAn1xAShVBk9QRU5JRHEC\nfXEDVRJfYXV0aF91c2VyX2JhY2tlbmRxBFUlZGphbmdvX29wZW5pZF9hdXRoLmF1dGguT3BlbklE\nQmFja2VuZHEFVQ1fYXV0aF91c2VyX2lkcQZLHXUu\n	2011-07-21 09:17:37.985384+00
16cb489a28c3e3f07f0ad54382ec3cc9	MjgyNjcyMTJkMjMxZjcwNzYwZmEzMGMyYzkyMjE1OGViNzEzMmI1MDqAAn1xAShVBk9QRU5JRHEC\nfXEDVRJfYXV0aF91c2VyX2JhY2tlbmRxBFUlZGphbmdvX29wZW5pZF9hdXRoLmF1dGguT3BlbklE\nQmFja2VuZHEFVQ1fYXV0aF91c2VyX2lkcQZLAXUu\n	2011-07-22 08:30:18.083025+00
7fdc4620c2184884edb2afbed5b016f4	MDY5NzA5NzYzNTc0MTI5NzYwMDBiNjk0NWExOTY0OWU2ZTFkOTkyODqAAn1xAShVBk9QRU5JRHEC\nfXEDVRJfYXV0aF91c2VyX2JhY2tlbmRxBFUlZGphbmdvX29wZW5pZF9hdXRoLmF1dGguT3BlbklE\nQmFja2VuZHEFVQ1fYXV0aF91c2VyX2lkcQZLG3Uu\n	2011-07-22 20:48:41.935195+00
26712b28e941962ecedb4adeccd34b20	YWMyNTc0Y2ExNzdlMDIxZDBmNjM1ZTZhN2M4YzY2ODNmMzMxOTQ5MTqAAn1xAShVBk9QRU5JRHEC\nfXEDVRJfYXV0aF91c2VyX2JhY2tlbmRxBFUlZGphbmdvX29wZW5pZF9hdXRoLmF1dGguT3BlbklE\nQmFja2VuZHEFVQ1fYXV0aF91c2VyX2lkcQZLIXUu\n	2011-07-24 17:07:08.216422+00
e81f867a6e9002ce039dbc05586d0b3e	NGQ2MTIyOGUwMThhNTAwYjc2MjQyYjRmZWQ0NjMzOGY4Y2NmOGE0MDqAAn1xAShVBk9QRU5JRHEC\nfXEDVRJfYXV0aF91c2VyX2JhY2tlbmRxBFUlZGphbmdvX29wZW5pZF9hdXRoLmF1dGguT3BlbklE\nQmFja2VuZHEFVQ1fYXV0aF91c2VyX2lkcQZLHXUu\n	2011-07-25 13:01:24.61043+00
4839c43420ced955952b8df5f472eb89	N2M0NTMwNDM3MGM2MWI4NzExOTdlMWU2MDhhNjhhMTI1NDhkODk4MjqAAn1xAShVBk9QRU5JRHEC\nfXEDVRJfYXV0aF91c2VyX2JhY2tlbmRxBFUlZGphbmdvX29wZW5pZF9hdXRoLmF1dGguT3BlbklE\nQmFja2VuZHEFVQ1fYXV0aF91c2VyX2lkcQZLAnUu\n	2011-07-27 06:28:40.707187+00
788f87e18b824928b282b0ab087a727d	MGM2NGM4MjBiNGU2NjdhOTQ3ODk5Njk5NmIwZDViODNmYjNmOWFhODqAAn1xAShVBk9QRU5JRHEC\nfXEDVRJfYXV0aF91c2VyX2JhY2tlbmRxBFUlZGphbmdvX29wZW5pZF9hdXRoLmF1dGguT3BlbklE\nQmFja2VuZHEFVQ1fYXV0aF91c2VyX2lkcQaKAS51Lg==\n	2011-08-02 05:17:00.176252+00
335faa2012bcfe6d5e206945786ef174	NGQ2MTIyOGUwMThhNTAwYjc2MjQyYjRmZWQ0NjMzOGY4Y2NmOGE0MDqAAn1xAShVBk9QRU5JRHEC\nfXEDVRJfYXV0aF91c2VyX2JhY2tlbmRxBFUlZGphbmdvX29wZW5pZF9hdXRoLmF1dGguT3BlbklE\nQmFja2VuZHEFVQ1fYXV0aF91c2VyX2lkcQZLHXUu\n	2011-08-05 13:15:18.249184+00
ba76fb680730c80bdaac5ddd77995695	NzExOGJjYjg4MjU2MzllY2FlYTFjMzExMWIxMWVjMWQwNmM3YTFhNjqAAn1xAShVBk9QRU5JRHEC\nfXEDVRJfYXV0aF91c2VyX2JhY2tlbmRxBFUlZGphbmdvX29wZW5pZF9hdXRoLmF1dGguT3BlbklE\nQmFja2VuZHEFVQ1fYXV0aF91c2VyX2lkcQZLHnUu\n	2011-08-10 10:28:32.532995+00
7bf1b0223557439a7a8ff5c4c0f5603f	NmM3ODIzODY0N2Q4NWRmNzc1MDhkNTNmYzE1OTQxMmZhNGY5OWJiYTqAAn1xAVUGT1BFTklEcQJ9\ncQMoVSFfeWFkaXNfc2VydmljZXNfX29wZW5pZF9jb25zdW1lcl9xBGNvcGVuaWQueWFkaXMubWFu\nYWdlcgpZYWRpc1NlcnZpY2VNYW5hZ2VyCnEFKYFxBn1xByhVCHNlcnZpY2VzcQhdcQlVCXlhZGlz\nX3VybHEKVSVodHRwczovL3d3dy5nb29nbGUuY29tL2FjY291bnRzL284L2lkcQtVDHN0YXJ0aW5n\nX3VybHEMWCUAAABodHRwczovL3d3dy5nb29nbGUuY29tL2FjY291bnRzL284L2lkcQ1VC3Nlc3Np\nb25fa2V5cQ5oBFUIX2N1cnJlbnRxD2NvcGVuaWQuY29uc3VtZXIuZGlzY292ZXIKT3BlbklEU2Vy\ndmljZUVuZHBvaW50CnEQKYFxEX1xEihVCmNsYWltZWRfaWRxE05VEmRpc3BsYXlfaWRlbnRpZmll\ncnEUTlUKc2VydmVyX3VybHEVVSVodHRwczovL3d3dy5nb29nbGUuY29tL2FjY291bnRzL284L3Vk\ncRZVC2Nhbm9uaWNhbElEcRdOVQhsb2NhbF9pZHEYTlUJdHlwZV91cmlzcRldcRooVSdodHRwOi8v\nc3BlY3Mub3BlbmlkLm5ldC9hdXRoLzIuMC9zZXJ2ZXJxG1UcaHR0cDovL29wZW5pZC5uZXQvc3J2\nL2F4LzEuMHEcVTRodHRwOi8vc3BlY3Mub3BlbmlkLm5ldC9leHRlbnNpb25zL3VpLzEuMC9tb2Rl\nL3BvcHVwcR1VLmh0dHA6Ly9zcGVjcy5vcGVuaWQubmV0L2V4dGVuc2lvbnMvdWkvMS4wL2ljb25x\nHlUraHR0cDovL3NwZWNzLm9wZW5pZC5uZXQvZXh0ZW5zaW9ucy9wYXBlLzEuMHEfZVUKdXNlZF95\nYWRpc3EgiHVidWJVG19vcGVuaWRfY29uc3VtZXJfbGFzdF90b2tlbnEhaBF1cy4=\n	2011-09-02 23:00:42.822223+00
62cb846efd73259123ae1fe5dfcf3044	NDgxMmI5NjkzOGMxZjcyNzIwNGIzZTI3N2MzNGZhZDc4NmYwMDg1ZDqAAn1xAShVBk9QRU5JRHEC\nfXEDVRJfYXV0aF91c2VyX2JhY2tlbmRxBFUlZGphbmdvX29wZW5pZF9hdXRoLmF1dGguT3BlbklE\nQmFja2VuZHEFVQ1fYXV0aF91c2VyX2lkcQaKAS91Lg==\n	2011-09-02 23:03:55.327207+00
937db06a0cecadf7f5361f14358d7728	NGQ2MTIyOGUwMThhNTAwYjc2MjQyYjRmZWQ0NjMzOGY4Y2NmOGE0MDqAAn1xAShVBk9QRU5JRHEC\nfXEDVRJfYXV0aF91c2VyX2JhY2tlbmRxBFUlZGphbmdvX29wZW5pZF9hdXRoLmF1dGguT3BlbklE\nQmFja2VuZHEFVQ1fYXV0aF91c2VyX2lkcQZLHXUu\n	2011-09-27 07:58:55.428451+00
5a70b45bd42a0edd9f23c792bb679dc7	NmM3ODIzODY0N2Q4NWRmNzc1MDhkNTNmYzE1OTQxMmZhNGY5OWJiYTqAAn1xAVUGT1BFTklEcQJ9\ncQMoVSFfeWFkaXNfc2VydmljZXNfX29wZW5pZF9jb25zdW1lcl9xBGNvcGVuaWQueWFkaXMubWFu\nYWdlcgpZYWRpc1NlcnZpY2VNYW5hZ2VyCnEFKYFxBn1xByhVCHNlcnZpY2VzcQhdcQlVCXlhZGlz\nX3VybHEKVSVodHRwczovL3d3dy5nb29nbGUuY29tL2FjY291bnRzL284L2lkcQtVDHN0YXJ0aW5n\nX3VybHEMWCUAAABodHRwczovL3d3dy5nb29nbGUuY29tL2FjY291bnRzL284L2lkcQ1VC3Nlc3Np\nb25fa2V5cQ5oBFUIX2N1cnJlbnRxD2NvcGVuaWQuY29uc3VtZXIuZGlzY292ZXIKT3BlbklEU2Vy\ndmljZUVuZHBvaW50CnEQKYFxEX1xEihVCmNsYWltZWRfaWRxE05VEmRpc3BsYXlfaWRlbnRpZmll\ncnEUTlUKc2VydmVyX3VybHEVVSVodHRwczovL3d3dy5nb29nbGUuY29tL2FjY291bnRzL284L3Vk\ncRZVC2Nhbm9uaWNhbElEcRdOVQhsb2NhbF9pZHEYTlUJdHlwZV91cmlzcRldcRooVSdodHRwOi8v\nc3BlY3Mub3BlbmlkLm5ldC9hdXRoLzIuMC9zZXJ2ZXJxG1UcaHR0cDovL29wZW5pZC5uZXQvc3J2\nL2F4LzEuMHEcVTRodHRwOi8vc3BlY3Mub3BlbmlkLm5ldC9leHRlbnNpb25zL3VpLzEuMC9tb2Rl\nL3BvcHVwcR1VLmh0dHA6Ly9zcGVjcy5vcGVuaWQubmV0L2V4dGVuc2lvbnMvdWkvMS4wL2ljb25x\nHlUraHR0cDovL3NwZWNzLm9wZW5pZC5uZXQvZXh0ZW5zaW9ucy9wYXBlLzEuMHEfZVUKdXNlZF95\nYWRpc3EgiHVidWJVG19vcGVuaWRfY29uc3VtZXJfbGFzdF90b2tlbnEhaBF1cy4=\n	2011-10-04 15:00:20.217536+00
\.


--
-- Data for Name: django_site; Type: TABLE DATA; Schema: public; Owner: codecatalog
--

COPY django_site (id, domain, name) FROM stdin;
1	example.com	example.com
\.


--
-- Data for Name: south_migrationhistory; Type: TABLE DATA; Schema: public; Owner: codecatalog
--

COPY south_migrationhistory (id, app_name, migration, applied) FROM stdin;
1	zoo	0001_initial	2011-03-24 08:19:13.205971+00
2	zoo	0002_auto__add_dependency__chg_field_spec_name	2011-03-24 19:05:34.84329+00
3	zoo	0003_rename_vote_date_to_vote_timestamp	2011-03-28 07:01:24.357939+00
4	zoo	0004_auto__add_comment	2011-03-28 07:01:24.497677+00
5	zoo	0005_auto__del_comment__add_bugreport__add_field_version_comment	2011-03-29 13:05:28.797666+00
6	zoo	0006_auto__add_field_versionptr_type	2011-04-02 07:45:53.081344+00
7	zoo	0007_annotate_versionptrs	2011-04-02 07:47:30.696744+00
8	zoo	0008_auto__add_following	2011-04-02 07:47:30.809021+00
9	zoo	0009_auto__add_field_spec_status	2011-04-18 11:48:00.952979+00
10	zoo	0010_auto__del_vote__del_field_versionptr_votes	2011-05-08 10:20:56.146946+00
11	zoo	0011_auto__del_field_version_approved	2011-05-14 04:22:57.357145+00
12	zoo	0012_auto__add_field_version_serial	2011-05-14 04:22:57.713756+00
13	zoo	0013_add_serial_ids	2011-05-14 04:22:59.560267+00
14	zoo	0014_auto__add_unique_version_versionptr_serial	2011-05-14 04:22:59.654242+00
\.


--
-- Data for Name: zoo_bugreport; Type: TABLE DATA; Schema: public; Owner: codecatalog
--

COPY zoo_bugreport (status, target_versionptr_id, version_id, title) FROM stdin;
0	26	150	Implementation assumes that indentation is made of spaces
0	26	151	Implementation assumes that indentation is made of spaces
0	65	169	I refuse to monkeypatch!
0	26	176	Empty text causes this method to crash
1	26	190	Empty text causes this method to crash
0	29	197	The spec name and snippet names are still out of sync.
0	76	206	Function does not "remove and return"
1	76	240	Function does not "remove and return"
2	29	489	The spec name and snippet names are still out of sync.
0	169	504	If PriorityQueue is initializes with out of order elements, heap invariant is broken
1	169	506	If PriorityQueue is initializes with out of order elements, heap invariant is broken
0	19	512	`maximum_by` duplicates built-in functionality
1	19	516	`maximum_by` duplicates built-in functionality
0	196	539	Should be phrased as a function
2	196	566	Should be phrased as a function
0	205	569	Indentation needs to be fixed.
0	188	574	Could be replaced with simple_lowest_factor?
0	195	575	Eliminate globals?
2	188	576	Could be replaced with simple_lowest_factor?
0	205	581	Indentation needs to be fixed.
0	208	583	Looks like it works in python 2.6 to me.
2	205	586	Indentation needs to be fixed.
2	208	592	Looks like it works in python 2.6 to me.
0	218	604	Is the Math.random() line correct?
0	276	777	Does not work in IE
0	276	778	Does not work in IE8
0	293	823	What is a "timestamp object"?
0	303	827	Where does .autocomplete come from?
0	302	828	I have no idea how to use this function
0	195	830	Eliminate globals?
0	236	889	
2	236	891	xs[0] is never visited
0	306	919	There is already a standard function for this
0	306	922	There is already a standard function for this
0	403	1104	Does not work in IE8 and possibly other IE versions
1	293	1137	What is a "timestamp object"?
1	293	1140	What is a "timestamp object"?
\.


--
-- Data for Name: zoo_dependency; Type: TABLE DATA; Schema: public; Owner: codecatalog
--

COPY zoo_dependency (id, snippet_id, target_id) FROM stdin;
1	32	11
2	61	21
3	69	23
4	89	23
5	90	23
6	99	15
7	104	15
8	109	15
9	120	15
10	121	15
11	145	15
12	149	15
13	155	25
14	182	23
15	217	78
16	224	80
17	224	82
18	228	78
19	229	80
20	229	82
21	231	15
22	257	90
23	259	88
24	262	90
25	263	90
26	266	88
27	270	90
28	279	94
29	279	96
30	279	21
31	286	94
32	286	96
33	286	21
34	297	68
35	300	94
36	300	96
37	300	21
38	310	107
39	323	107
40	323	113
41	323	111
42	359	90
43	361	90
44	362	19
45	368	21
46	373	135
47	373	137
48	398	145
49	398	13
50	399	145
51	399	13
52	410	149
53	411	149
54	411	107
55	414	13
56	414	145
57	418	21
58	448	15
59	450	15
60	451	15
61	453	11
62	456	168
63	469	15
64	469	174
65	472	90
66	475	15
67	481	21
68	497	29
69	497	68
70	498	15
71	502	168
72	505	11
73	526	192
74	558	15
75	561	15
76	580	15
77	590	213
78	594	15
79	600	215
80	605	215
81	605	217
82	609	213
83	609	221
84	610	213
85	611	213
86	617	225
87	626	229
88	628	229
89	657	239
90	663	213
91	663	221
92	665	213
93	665	221
94	666	213
95	666	221
96	669	15
97	671	15
98	671	38
99	672	15
100	672	38
101	673	15
102	673	38
103	675	15
104	675	38
105	678	15
106	678	38
107	679	19
108	684	15
109	684	245
110	684	38
111	687	15
112	692	15
113	713	15
114	718	15
115	733	15
116	733	259
117	740	251
118	746	15
119	746	36
120	759	15
121	761	15
122	761	269
123	763	15
124	764	15
125	765	15
126	765	271
127	765	36
128	766	15
129	766	271
130	770	273
131	772	273
132	773	273
133	774	15
134	774	275
135	775	15
136	775	275
137	776	15
138	776	271
139	818	15
140	819	15
141	820	15
142	821	15
143	846	15
144	847	15
145	847	275
146	854	312
147	865	314
148	865	316
149	887	278
150	921	213
151	921	221
152	928	34
153	931	322
154	941	343
155	941	347
156	959	88
157	973	192
158	1000	322
159	1006	278
160	1024	192
161	1024	371
162	1033	322
163	1064	278
164	1073	322
165	1078	356
166	1078	377
167	1081	356
168	1081	377
169	1098	15
170	1103	15
171	1109	213
172	1125	411
173	1128	411
174	1128	44
175	1130	229
176	1136	414
177	1136	415
178	1138	414
179	1138	415
180	1139	414
181	1139	415
182	1145	416
183	1146	414
184	1146	415
185	1151	418
186	1155	422
\.


--
-- Data for Name: zoo_following; Type: TABLE DATA; Schema: public; Owner: codecatalog
--

COPY zoo_following (new_events, follower_id, followed_id, id, last_check) FROM stdin;
f	1	86	1	2011-04-02 19:25:18.416875+00
f	1	87	2	2011-04-02 19:25:18.633802+00
f	2	75	3	2011-04-03 00:16:01.282297+00
f	2	77	5	2011-04-03 00:17:04.147239+00
f	2	66	6	2011-04-03 01:55:05.21897+00
f	1	88	7	2011-04-03 02:27:15.456121+00
f	1	89	8	2011-04-03 02:27:15.565157+00
f	2	90	9	2011-04-03 02:30:47.101219+00
f	2	91	10	2011-04-03 02:30:47.233749+00
f	1	92	11	2011-04-03 02:41:37.15882+00
f	1	93	12	2011-04-03 02:41:37.342803+00
f	1	96	15	2011-04-03 03:33:43.599585+00
f	1	97	16	2011-04-03 03:33:43.726414+00
f	1	98	17	2011-04-03 03:35:24.86493+00
f	1	100	19	2011-04-03 03:35:25.778961+00
f	2	103	22	2011-04-03 04:43:36.842667+00
f	2	104	23	2011-04-03 04:43:36.97424+00
f	2	105	26	2011-04-03 05:09:56.970597+00
f	2	107	28	2011-04-03 05:13:03.57549+00
f	2	108	29	2011-04-03 05:13:03.811033+00
f	2	110	31	2011-04-03 05:14:06.363505+00
f	2	111	32	2011-04-03 05:15:29.368166+00
f	2	112	33	2011-04-03 05:15:29.498896+00
f	2	113	34	2011-04-03 05:16:52.652498+00
f	2	114	35	2011-04-03 05:16:52.902126+00
f	1	99	18	2011-04-03 05:22:07.455268+00
f	1	109	36	2011-04-03 05:32:47.802415+00
f	2	76	4	2011-04-03 05:33:36.210022+00
f	2	109	30	2011-04-03 05:33:45.230846+00
f	1	126	38	2011-04-03 23:11:25.952864+00
f	1	129	39	2011-04-04 05:19:58.582437+00
f	1	135	41	2011-04-04 05:31:45.199654+00
f	1	136	42	2011-04-04 05:45:16.569781+00
f	1	137	43	2011-04-04 05:47:41.757057+00
f	1	138	44	2011-04-04 05:49:42.906276+00
f	1	139	45	2011-04-04 05:50:29.512072+00
f	1	140	46	2011-04-04 05:51:04.278945+00
f	1	141	47	2011-04-04 05:52:44.038062+00
f	1	143	48	2011-04-04 05:58:50.747387+00
f	2	106	27	2011-04-04 07:45:14.890471+00
f	1	125	37	2011-04-05 01:44:44.307223+00
f	1	145	49	2011-04-06 03:33:20.929127+00
f	1	147	50	2011-04-06 03:38:46.132195+00
f	1	149	52	2011-04-06 04:44:25.733631+00
f	1	150	53	2011-04-06 04:44:25.896947+00
f	1	151	54	2011-04-06 04:45:15.284767+00
f	1	152	55	2011-04-06 04:45:15.43205+00
f	1	148	51	2011-04-06 04:54:07.546766+00
f	1	142	56	2011-04-06 08:45:08.896972+00
f	1	78	57	2011-04-09 16:52:24.98959+00
f	1	153	58	2011-04-09 17:21:50.903043+00
f	1	164	59	2011-04-09 20:53:15.268831+00
f	2	173	67	2011-04-11 09:00:23.88912+00
f	1	174	68	2011-04-17 02:57:54.190137+00
f	1	176	69	2011-04-17 03:04:03.732319+00
f	1	177	70	2011-04-17 03:05:30.43262+00
f	1	178	71	2011-04-17 04:45:40.9579+00
f	1	179	72	2011-04-17 04:45:41.145416+00
f	1	180	73	2011-04-17 05:47:54.844111+00
f	1	101	78	2011-04-17 06:11:43.682433+00
f	1	71	79	2011-04-17 06:13:52.592911+00
f	1	182	80	2011-04-17 06:16:48.452483+00
f	1	183	81	2011-04-17 06:16:48.819661+00
f	1	102	82	2011-04-17 06:20:20.850126+00
f	1	49	83	2011-04-17 06:26:33.259908+00
f	1	168	84	2011-04-17 09:08:07.189365+00
f	1	170	85	2011-04-17 10:42:14.135218+00
f	1	171	86	2011-04-17 10:43:44.251629+00
f	2	184	88	2011-04-18 05:10:12.349509+00
f	1	184	87	2011-04-18 05:10:52.958158+00
f	1	172	89	2011-04-18 09:55:44.337522+00
f	1	65	90	2011-04-18 09:56:51.862931+00
f	17	69	108	2011-04-20 14:16:21.612187+00
f	1	181	74	2011-04-20 20:47:31.277312+00
f	1	69	77	2011-04-20 20:47:53.174616+00
f	1	186	96	2011-04-20 07:44:58.93886+00
t	9	185	93	2011-04-20 05:32:07.293942+00
f	1	185	97	2011-04-20 07:46:52.818239+00
f	1	192	103	2011-04-20 11:06:49.226975+00
f	1	193	104	2011-04-20 11:06:49.359703+00
f	1	191	105	2011-04-20 11:08:37.032379+00
f	2	168	62	2011-05-04 08:52:13.977683+00
f	13	196	126	2011-04-21 07:57:55.32431+00
t	22	196	112	2011-04-20 18:45:02.338372+00
f	13	197	127	2011-04-21 07:58:47.002309+00
f	1	30	76	2011-06-28 04:15:02.715476+00
t	18	195	110	2011-04-20 14:31:54.204985+00
f	26	220	152	2011-04-28 05:44:05.813867+00
t	9	20	95	2011-04-20 05:33:32.394914+00
f	1	213	139	2011-04-22 15:39:13.89691+00
f	13	210	133	2011-04-21 20:43:00.646042+00
f	1	207	131	2011-04-22 08:58:11.870547+00
f	2	101	20	2011-06-08 09:20:44.042302+00
f	13	201	116	2011-05-07 08:11:29.810143+00
f	13	207	124	2011-04-21 20:43:23.365518+00
f	13	206	123	2011-04-21 20:47:30.520043+00
t	24	204	120	2011-04-20 23:46:42.812623+00
f	1	206	130	2011-04-22 08:58:17.958647+00
f	1	210	132	2011-04-22 08:58:24.509651+00
f	1	212	136	2011-04-22 17:29:35.910961+00
f	1	190	135	2011-04-22 09:01:17.485451+00
t	14	190	101	2011-05-23 13:11:19.015111+00
t	18	194	109	2011-04-20 14:31:54.132104+00
f	1	194	137	2011-04-22 09:08:05.80207+00
t	24	209	134	2011-04-21 21:04:54.641797+00
f	1	209	138	2011-04-22 10:39:06.745356+00
f	1	214	140	2011-04-22 15:39:14.016664+00
f	1	133	40	2011-04-28 06:57:35.617139+00
f	13	208	125	2011-04-22 16:13:08.562099+00
f	13	212	142	2011-04-22 16:14:51.403283+00
f	1	204	146	2011-04-22 18:20:32.882934+00
f	1	205	145	2011-04-22 18:13:59.322343+00
f	1	217	149	2011-04-22 18:38:32.944669+00
t	28	204	143	2011-04-22 16:19:00.847425+00
f	1	218	150	2011-04-22 18:38:33.044238+00
f	1	219	151	2011-04-22 18:39:29.205391+00
f	1	215	147	2011-04-22 18:28:35.434964+00
f	1	216	148	2011-04-22 18:28:35.544369+00
f	1	189	141	2011-05-25 08:28:10.666438+00
f	26	221	153	2011-04-23 03:21:36.700225+00
t	28	205	144	2011-04-22 16:19:51.53121+00
t	24	205	121	2011-04-20 23:46:42.885946+00
t	25	205	122	2011-04-21 07:18:20.834304+00
f	26	223	155	2011-04-23 03:22:36.952305+00
t	22	188	111	2011-04-20 18:40:06.729096+00
t	9	19	94	2011-04-20 05:32:20.417671+00
f	13	200	115	2011-05-07 08:09:07.420439+00
f	13	187	98	2011-05-07 08:09:02.140463+00
f	23	198	113	2011-04-28 14:25:54.290351+00
f	2	171	65	2011-05-04 08:52:35.137724+00
t	7	30	91	2011-04-20 03:46:12.318267+00
f	13	202	117	2011-05-07 08:08:46.503839+00
t	26	222	154	2011-04-23 03:21:36.86438+00
f	1	167	61	2011-05-11 08:21:08.933791+00
f	1	166	60	2011-05-11 08:20:53.757396+00
f	1	94	13	2011-05-27 09:55:05.45058+00
t	17	30	106	2011-04-20 14:15:20.239322+00
t	23	33	129	2011-04-21 11:30:21.785879+00
t	14	189	100	2011-05-23 13:08:56.260085+00
t	14	191	102	2011-05-23 13:07:03.214347+00
f	1	95	14	2011-05-30 05:09:38.080478+00
f	2	102	21	2011-06-08 09:20:51.116668+00
f	2	170	64	2011-06-08 09:20:56.050825+00
f	2	169	63	2011-06-08 09:21:05.890418+00
f	2	172	66	2011-06-08 09:21:10.364038+00
f	2	69	24	2011-06-08 09:21:13.916148+00
f	2	33	25	2011-06-08 09:21:17.141115+00
t	17	33	107	2011-04-20 14:18:17.239011+00
f	26	224	156	2011-04-23 03:53:29.792852+00
f	23	199	114	2011-04-23 06:06:41.773068+00
f	1	220	157	2011-04-23 18:10:42.732244+00
f	1	225	158	2011-04-23 19:29:35.963814+00
f	1	226	159	2011-04-23 19:29:36.159826+00
f	1	227	160	2011-04-23 19:34:16.788399+00
f	1	228	161	2011-04-23 19:34:16.944166+00
f	1	229	162	2011-04-23 19:47:18.644639+00
f	1	230	163	2011-04-23 19:47:18.784486+00
f	1	231	164	2011-04-23 19:54:02.700945+00
f	1	232	165	2011-04-23 19:54:02.840516+00
f	1	233	166	2011-04-23 23:37:40.251212+00
f	1	234	167	2011-04-24 08:07:10.235082+00
f	1	235	168	2011-04-24 08:07:10.368115+00
f	1	198	169	2011-04-24 20:19:22.856418+00
f	29	237	171	2011-04-27 07:30:46.667511+00
f	29	238	172	2011-04-27 07:30:46.840835+00
f	1	202	173	2011-04-27 20:02:10.20182+00
f	1	200	174	2011-04-27 20:02:20.841147+00
f	1	187	175	2011-04-27 20:02:27.797554+00
f	1	203	176	2011-04-27 20:02:51.305133+00
f	1	188	177	2011-04-27 20:03:23.517177+00
f	1	201	178	2011-04-27 20:05:47.880504+00
f	1	239	179	2011-04-27 20:46:46.755323+00
f	1	240	180	2011-04-27 20:46:46.855119+00
f	1	241	181	2011-04-27 20:47:38.322842+00
f	1	242	182	2011-04-27 20:47:38.419096+00
f	1	327	281	2011-05-21 03:46:54.54564+00
f	2	308	259	2011-05-18 07:20:00.405437+00
f	26	133	184	2011-04-28 07:07:59.824175+00
f	2	39	185	2011-05-05 07:34:24.866438+00
f	2	309	260	2011-05-18 07:20:00.580053+00
f	1	244	188	2011-05-06 05:30:39.699283+00
f	1	134	189	2011-05-06 11:12:02.011492+00
f	1	245	190	2011-05-06 11:17:36.083386+00
f	1	246	191	2011-05-06 11:17:36.227537+00
f	2	303	251	2011-06-08 09:21:26.743968+00
f	2	272	223	2011-06-08 09:21:29.924391+00
f	1	243	192	2011-05-06 11:25:32.686278+00
f	13	188	99	2011-05-07 08:07:52.172566+00
f	13	203	118	2011-05-07 08:08:55.093122+00
f	1	29	193	2011-05-08 02:42:44.737918+00
f	1	247	194	2011-05-08 03:10:10.522474+00
f	1	248	195	2011-05-08 03:10:10.85462+00
f	1	249	196	2011-05-08 03:25:40.998517+00
f	1	250	197	2011-05-08 03:25:41.330375+00
f	1	251	198	2011-05-08 03:34:14.894165+00
f	1	252	199	2011-05-08 03:34:15.298618+00
f	1	253	200	2011-05-08 04:55:21.121229+00
f	1	254	201	2011-05-08 04:55:21.709578+00
f	1	255	202	2011-05-08 04:56:56.625462+00
f	1	256	203	2011-05-08 04:56:56.953711+00
f	1	257	204	2011-05-08 05:39:31.261962+00
f	1	258	205	2011-05-08 05:39:31.614431+00
f	1	259	206	2011-05-08 05:50:54.288994+00
f	1	260	207	2011-05-08 05:50:54.684773+00
f	1	261	208	2011-05-08 05:52:41.116714+00
f	1	262	209	2011-05-08 06:26:00.186613+00
f	1	263	210	2011-05-08 06:26:03.835493+00
f	1	264	211	2011-05-08 06:56:51.389994+00
f	2	266	213	2011-06-08 09:21:34.043619+00
f	1	266	215	2011-05-09 07:09:16.496805+00
f	1	303	261	2011-05-18 09:05:00.122147+00
f	2	265	224	2011-06-08 09:21:37.438399+00
t	29	339	293	2011-05-25 07:36:25.988758+00
f	1	268	217	2011-05-09 07:18:39.863264+00
f	2	276	228	2011-06-08 09:21:40.869734+00
f	2	269	218	2011-05-11 05:25:11.031582+00
f	2	270	219	2011-05-11 05:25:11.220242+00
f	2	166	220	2011-05-11 05:25:54.318826+00
f	2	167	221	2011-05-11 05:28:35.642508+00
f	2	271	222	2011-05-11 05:30:44.47769+00
f	2	274	226	2011-05-11 08:05:06.186915+00
f	29	307	256	2011-05-19 20:09:30.717453+00
f	1	272	229	2011-05-11 08:17:15.420313+00
f	1	265	212	2011-05-11 08:20:28.801466+00
f	2	275	227	2011-06-08 09:21:44.148499+00
f	1	312	264	2011-05-19 22:56:06.463663+00
f	1	277	230	2011-05-11 08:25:04.952515+00
f	2	273	225	2011-06-08 09:21:47.02953+00
f	2	267	214	2011-06-08 09:21:49.703392+00
f	1	275	231	2011-05-11 08:29:18.723576+00
f	2	293	245	2011-07-13 07:52:11.410794+00
f	1	273	232	2011-05-11 08:30:18.063587+00
f	2	278	233	2011-05-12 08:56:26.242934+00
f	2	279	234	2011-05-12 08:56:26.418859+00
f	1	280	235	2011-05-13 05:55:35.910637+00
f	1	282	237	2011-05-13 05:55:36.029724+00
f	1	283	238	2011-05-13 05:55:36.139517+00
f	1	284	239	2011-05-13 15:24:41.804232+00
f	1	285	240	2011-05-13 15:24:41.962388+00
f	1	286	241	2011-05-13 15:30:38.324796+00
f	2	287	242	2011-05-16 05:09:49.323786+00
f	2	289	243	2011-05-16 05:09:58.715451+00
f	2	291	244	2011-05-16 05:09:59.891437+00
f	2	295	246	2011-05-16 05:10:18.546471+00
f	2	297	247	2011-05-16 05:10:19.352082+00
f	2	299	248	2011-05-16 05:10:21.959841+00
f	1	313	265	2011-05-19 22:56:06.587468+00
f	1	328	282	2011-05-21 03:46:54.968825+00
f	2	302	250	2011-06-08 09:21:55.971318+00
f	1	281	236	2011-06-08 09:58:32.941857+00
f	1	335	289	2011-05-23 22:39:18.096961+00
f	1	267	216	2011-05-16 10:05:08.696588+00
f	1	236	170	2011-05-23 02:15:56.117717+00
f	1	304	252	2011-05-16 10:39:37.90774+00
f	29	306	255	2011-06-22 11:54:37.696594+00
f	1	305	253	2011-05-16 10:40:02.25893+00
f	1	158	254	2011-05-16 10:56:38.28408+00
f	1	311	266	2011-05-19 23:07:46.756293+00
f	1	329	283	2011-05-23 02:17:32.717757+00
f	1	330	284	2011-05-23 03:20:41.155341+00
f	1	331	285	2011-05-23 03:20:41.589343+00
f	1	307	258	2011-05-18 00:25:44.495141+00
f	1	310	267	2011-05-19 23:07:57.734769+00
f	1	332	286	2011-05-23 03:54:37.870251+00
f	1	314	268	2011-05-19 23:18:59.533528+00
f	1	315	269	2011-05-19 23:18:59.649609+00
f	1	316	270	2011-05-19 23:20:22.926028+00
f	1	317	271	2011-05-19 23:20:23.092517+00
f	1	318	272	2011-05-19 23:22:15.673855+00
f	1	319	273	2011-05-19 23:22:15.807216+00
f	1	320	274	2011-05-20 04:37:50.180288+00
f	1	321	275	2011-05-20 04:37:50.517693+00
f	1	322	276	2011-05-20 05:12:35.611566+00
f	1	323	277	2011-05-20 05:12:36.067163+00
f	29	311	263	2011-05-20 08:59:44.457187+00
f	29	310	262	2011-05-20 09:00:25.617686+00
f	1	324	278	2011-05-21 03:07:04.431212+00
f	1	325	279	2011-05-21 03:07:05.002597+00
f	1	326	280	2011-05-21 03:10:30.131127+00
f	1	333	287	2011-05-23 03:54:38.111983+00
f	29	334	288	2011-05-23 14:04:33.73947+00
f	1	336	290	2011-05-23 22:39:18.3171+00
t	1	301	249	2011-05-16 09:22:26.711258+00
f	1	337	291	2011-05-23 23:18:00.125576+00
f	1	338	292	2011-05-23 23:18:00.317458+00
t	24	30	119	2011-04-20 23:44:57.804877+00
f	2	19	294	2011-05-25 07:41:27.109629+00
t	26	189	183	2011-04-28 06:06:56.226283+00
f	2	189	295	2011-05-25 07:42:49.886523+00
f	1	306	257	2011-05-25 08:28:14.24418+00
f	1	339	296	2011-05-25 08:30:13.596637+00
f	1	340	297	2011-05-25 08:32:57.54084+00
f	1	341	298	2011-05-25 08:32:57.65915+00
f	29	342	299	2011-05-26 06:26:05.447572+00
f	1	343	300	2011-05-26 20:42:21.936566+00
f	1	344	301	2011-05-26 20:42:22.0652+00
f	1	345	302	2011-05-26 20:52:21.77616+00
f	1	346	303	2011-05-26 20:52:21.920745+00
f	1	347	304	2011-05-26 21:10:14.153979+00
f	1	348	305	2011-05-26 21:10:14.276499+00
f	1	349	306	2011-05-26 21:13:04.102493+00
f	1	350	307	2011-05-26 21:13:04.228553+00
f	1	46	308	2011-05-26 21:26:16.74363+00
f	1	9	309	2011-05-27 07:20:28.493852+00
f	1	1	310	2011-05-27 08:39:02.305403+00
f	2	94	311	2011-05-27 09:50:43.914771+00
f	1	115	312	2011-05-27 09:57:31.730157+00
f	1	48	313	2011-05-27 10:04:34.666208+00
f	1	25	314	2011-05-27 10:04:59.194388+00
f	1	62	315	2011-05-27 10:05:36.946046+00
f	1	84	316	2011-05-27 10:11:28.946255+00
f	1	42	317	2011-05-27 11:50:51.744303+00
f	1	222	318	2011-05-27 23:15:14.028548+00
f	38	95	320	2011-05-29 18:39:08.069743+00
f	38	47	321	2011-05-29 18:49:12.159789+00
f	38	43	322	2011-05-29 19:05:22.056391+00
f	1	73	319	2011-05-31 09:32:41.884434+00
f	1	351	324	2011-05-31 23:10:51.228381+00
f	1	352	325	2011-05-31 23:10:51.383981+00
f	1	353	326	2011-05-31 23:50:35.279401+00
f	1	354	327	2011-06-01 01:25:22.420557+00
f	1	355	328	2011-06-01 01:25:22.561019+00
f	1	356	329	2011-06-01 09:42:01.932831+00
f	1	357	330	2011-06-01 09:42:02.389199+00
f	1	154	331	2011-06-01 10:09:21.216944+00
f	1	358	332	2011-06-03 07:40:47.359357+00
f	1	359	333	2011-06-03 07:40:47.887097+00
f	1	360	334	2011-06-03 07:45:26.510637+00
f	1	361	335	2011-06-03 07:45:26.743264+00
f	1	362	336	2011-06-03 08:34:45.639605+00
f	1	363	337	2011-06-03 08:34:45.787404+00
f	1	364	338	2011-06-03 08:37:11.027729+00
f	1	365	339	2011-06-07 04:20:47.48726+00
f	1	366	340	2011-06-07 04:20:48.279824+00
f	1	367	341	2011-06-07 04:23:21.812178+00
f	1	368	342	2011-06-07 04:23:22.376953+00
f	1	369	343	2011-06-07 07:34:18.889162+00
f	1	370	344	2011-06-07 07:34:19.246427+00
f	2	244	187	2011-06-08 09:21:20.429104+00
f	2	243	186	2011-06-08 09:21:23.792935+00
f	2	73	323	2011-06-08 09:21:58.935277+00
f	2	281	345	2011-06-08 09:24:46.047819+00
f	1	371	346	2011-06-10 05:45:31.939273+00
f	1	372	347	2011-06-10 05:45:32.085058+00
f	1	373	348	2011-06-10 05:49:07.726517+00
f	1	374	349	2011-06-10 05:49:07.935829+00
f	1	375	350	2011-06-10 10:39:26.43117+00
f	1	376	351	2011-06-10 10:39:26.559913+00
f	1	377	352	2011-06-11 10:19:16.696337+00
f	1	378	353	2011-06-11 10:19:17.153719+00
f	1	379	354	2011-06-11 10:32:39.708582+00
f	1	380	355	2011-06-11 10:38:27.444558+00
f	1	381	356	2011-06-11 10:38:27.678537+00
f	1	382	357	2011-06-11 10:43:22.758097+00
f	1	383	358	2011-06-11 10:43:23.094464+00
f	1	384	359	2011-06-14 05:34:23.543348+00
f	1	385	360	2011-06-14 05:34:23.687824+00
f	1	386	361	2011-06-14 08:20:31.406277+00
f	1	387	362	2011-06-14 08:20:31.533087+00
f	1	388	363	2011-06-14 21:01:08.299068+00
f	1	389	364	2011-06-14 21:01:08.723383+00
f	1	390	365	2011-06-18 18:48:35.04818+00
f	1	391	366	2011-06-18 18:48:35.468944+00
f	1	392	367	2011-06-18 20:51:51.627672+00
f	1	393	368	2011-06-18 21:02:12.921763+00
f	1	394	369	2011-06-18 21:02:13.496925+00
f	29	395	370	2011-06-22 11:52:41.160253+00
f	2	27	371	2011-06-25 06:56:16.855715+00
f	29	396	372	2011-06-27 13:19:17.925588+00
f	29	397	373	2011-06-27 13:28:54.497587+00
t	7	33	92	2011-04-20 03:48:31.614504+00
t	23	30	128	2011-04-21 11:30:01.209596+00
f	2	30	374	2011-06-28 03:46:16.550103+00
f	2	398	375	2011-06-28 03:53:28.824037+00
f	2	399	376	2011-06-28 03:53:29.041032+00
f	1	400	377	2011-06-28 04:13:55.425202+00
f	1	33	75	2011-06-28 04:15:09.712059+00
f	2	402	380	2011-06-28 06:23:31.949132+00
f	2	403	381	2011-06-28 06:23:32.129395+00
f	2	404	382	2011-06-28 07:24:28.938448+00
f	1	401	378	2011-06-28 07:26:27.450461+00
f	1	405	383	2011-06-30 07:46:43.75269+00
f	1	406	384	2011-06-30 07:46:44.253411+00
f	1	407	385	2011-07-08 08:36:06.75643+00
f	1	408	386	2011-07-08 08:36:08.603828+00
f	1	409	387	2011-07-09 13:38:35.287479+00
f	1	410	388	2011-07-09 13:38:35.705839+00
f	1	411	389	2011-07-09 13:48:57.247071+00
f	1	412	390	2011-07-09 13:48:57.415507+00
f	1	44	391	2011-07-09 13:54:38.578154+00
f	29	413	392	2011-07-11 13:01:45.132827+00
f	2	414	393	2011-07-13 07:18:41.787592+00
f	2	415	394	2011-07-13 07:20:59.929128+00
f	2	294	395	2011-07-13 07:22:30.779064+00
t	2	301	396	2011-07-13 07:22:59.325498+00
f	2	401	379	2011-07-13 07:44:01.657785+00
f	46	417	398	2011-07-19 05:21:04.190656+00
f	46	195	399	2011-07-19 05:22:42.785434+00
f	2	418	400	2011-07-20 06:46:36.844058+00
f	2	419	401	2011-07-20 06:46:37.092439+00
f	2	420	402	2011-07-20 06:47:52.127307+00
f	2	421	403	2011-07-20 06:47:52.300421+00
f	2	422	404	2011-07-20 07:00:35.056955+00
f	2	423	405	2011-07-20 07:00:35.214754+00
f	2	430	406	2011-07-20 07:27:24.455611+00
f	2	431	407	2011-07-20 07:38:49.098013+00
f	2	432	408	2011-07-20 07:40:28.328391+00
f	2	433	409	2011-07-20 07:42:52.4208+00
f	2	416	410	2011-07-25 07:17:22.367716+00
t	46	416	397	2011-07-19 05:21:04.093393+00
f	49	434	411	2011-08-29 09:49:40.787952+00
f	49	435	412	2011-08-29 09:49:40.987473+00
\.


--
-- Data for Name: zoo_snippet; Type: TABLE DATA; Schema: public; Owner: codecatalog
--

COPY zoo_snippet (code, spec_versionptr_id, version_id, language) FROM stdin;
def hello():\n    print "Hello, World!"	1	2	python
def hola():\n    print "Hola, Mundo!"	3	4	python
def bonjour():\n    print "Bonjour."\n	5	6	python
def hello():\n    print "Hello, World!"\n	1	7	python
def hola():\n    print "Hola, Mundo!"\n	3	8	python
def bonjour():\n    print "Bonjour tout le monde!"\n	5	9	python
def distinct_by(f, xs):\n    cur = None\n    for x in xs:\n        fx = f(x)\n        if cur != fx:\n            cur = fx\n            yield x\n	7	15	python
def traverse_cons_list(conslist):\n    while conslist is not ():\n        (x,xs) = conslist\n        yield x\n        conslist = xs\n	9	20	python
import heapq\n	11	25	python
def shortest_path(children, success, init):\n    seen = {}\n    q = [(0, init, ())]\n    if success(init):\n        return ()\n    while q:\n        (weight, elem, tail) = heapq.heappop(q)\n        if elem in seen: continue\n        seen[elem] = 1\n\n        for (cweight,child,edge) in children(elem):\n            if success(child): return tuple(traverse_cons_list((edge,tail)))\n            heapq.heappush(q, (weight+cweight,child, (edge,tail)))\n    return None\n	13	30	python
def shortest_path(children, success, init):\n    seen = {}\n    q = [(0, init, ())]\n    if success(init):\n        return ()\n    while q:\n        (weight, elem, tail) = heapq.heappop(q)\n        if elem in seen: continue\n        seen[elem] = 1\n\n        for (cweight,child,edge) in children(elem):\n            if success(child): return tuple(traverse_cons_list((edge,tail)))\n            heapq.heappush(q, (weight+cweight,child, (edge,tail)))\n    return None\n	13	32	python
var elt = function(name, attrs) {\n        var r = $('<' + name + ' />');\n        if (attrs) {\n            for (var i in attrs) {\n                r.attr(i, attrs[i]);\n            }\n        }\n        for (var i = 2; i < arguments.length; ++i) {\n            r.append(arguments[i]);\n        }\n        return r;\n    };\n	15	36	python
var elt = function(name, attrs) {\n    var r = $('<' + name + ' />');\n    if (attrs) {\n        for (var i in attrs) {\n            r.attr(i, attrs[i]);\n        }\n    }\n    for (var i = 2; i < arguments.length; ++i) {\n        r.append(arguments[i]);\n    }\n    return r;\n};\n	15	37	javascript
var reload = function() { document.location.reload(); };\n	17	42	python
var reload = function() { document.location.reload(); };\n	17	45	javascript
def maximum_by(measure, xs):\n    maxx = xs[0]\n    maxm = measure(maxx)\n    for x in xs[1:]:\n        xm = measure(x)\n        if xm > maxm:\n            maxx = x\n            maxm = xm\n    return maxx\n	19	47	python
import re\n	21	52	python
def initial_whitespace(line):\n    return re.search(r'^\\s*', line).group(0)\n	23	57	python
def initial_whitespace(line):\n    return re.search(r'^\\s*', line).group(0)\n	23	61	python
def strip_indent(text):\n    indent = re.compile(r'^\\s*')\n    lines = text.splitlines()\n    initial = min(*map(lambda l: len(initial_whitespace(l)), lines))\n    return '\\n'.join(map(lambda l: l[initial:], lines))\n	25	63	python
def strip_indent(text):\n    indent = re.compile(r'^\\s*')\n    lines = text.splitlines()\n    initial = min(*map(lambda l: len(initial_whitespace(l)), lines))\n    return ('\\n'.join(map(lambda l: l[initial:], lines)), " " * initial)\n	25	67	python
def strip_indent(text):\n    indent = re.compile(r'^\\s*')\n    lines = text.splitlines()\n    initial = min(*map(lambda l: len(initial_whitespace(l)), lines))\n    return ('\\n'.join(map(lambda l: l[initial:], lines)), " " * initial)\n	25	69	python
def indent_by(indent, text):\n    return '\\n'.join(map(lambda s: indent + s, text.splitlines())) + '\\n'\n	27	71	python
var linecomment = {\n    python: '#',\n    javascript: '//',\n};\n	29	76	python
var linecomment = {\n    python: '#',\n    javascript: '//',\n};\n	29	79	javascript
var max = function() {\n    var r = arguments[0];\n    for (var i = 1; i < arguments.length; ++i) {\n        if (arguments[i] > r) r = arguments[i];\n    }\n    return r;\n};\n	31	82	python
var max = function() {\n    var r = arguments[0];\n    for (var i = 1; i < arguments.length; ++i) {\n        if (arguments[i] > r) r = arguments[i];\n    }\n    return r;\n};\n	31	85	javascript
fii\nbur\n	29	86	python
linecomment = {\n    'python': '#',\n    'javascript': '//',\n}\n	29	87	python
def strip_indent(text):\n    indent = re.compile(r'^\\s*')\n    lines = text.splitlines()\n    lengths = map(lambda l: len(initial_whitespace(l)), lines)\n    initial = min(lengths)\n    return ('\\n'.join(map(lambda l: l[initial:], lines)), " " * initial)\n	25	88	python
def strip_indent(text):\n    indent = re.compile(r'^\\s*')\n    lines = text.splitlines()\n    lengths = map(lambda l: len(initial_whitespace(l)), lines)\n    initial = min(lengths)\n    return ('\\n'.join(map(lambda l: l[initial:], lines)), " " * initial)\n	25	89	python
def strip_indent(text):\n    lines = text.splitlines()\n    lengths = map(lambda l: len(initial_whitespace(l)), lines)\n    initial = min(0, *lengths)\n    return ('\\n'.join(map(lambda l: l[initial:], lines)), " " * initial)\n	25	90	python
var min = function() {\n        var r = arguments[0];\n        for (var i = 1; i < arguments.length; ++i) {\n            if (arguments[i] < r) r = arguments[i];\n        }\n        return r;\n    };\n	34	92	javascript
var min = function() {\n    var r = arguments[0];\n    for (var i = 1; i < arguments.length; ++i) {\n        if (arguments[i] < r) r = arguments[i];\n    }\n    return r;\n};\n	34	93	python
var min = function() {\n    var r = arguments[0];\n    for (var i = 1; i < arguments.length; ++i) {\n        if (arguments[i] < r) r = arguments[i];\n    }\n    return r;\n};\n	34	96	javascript
var button = function(text, click) {\n    var r = elt('button');\n    r.text(text);\n    r.click(click);\n    return r;\n};\n	36	98	python
var button = function(text, click) {\n    var r = elt('button');\n    r.text(text);\n    r.click(click);\n    return r;\n};\n	36	99	javascript
var horizontal = function() {\n    var r = elt('table');\n    var row = elt('tr');\n    r.append(row);\n    for (var i in arguments) {\n        var cell = elt('td', {}, arguments[i]);\n        row.append(cell);\n    }\n    return r;\n};\n	38	103	python
var horizontal = function() {\n    var r = elt('table');\n    var row = elt('tr');\n    r.append(row);\n    for (var i in arguments) {\n        var cell = elt('td', {}, arguments[i]);\n        row.append(cell);\n    }\n    return r;\n};\n	38	104	javascript
var vertical = function() {\n    var r = elt('table');\n    for (var i in arguments) {\n        var row = elt('tr', {}, elt('td', {}, arguments[i]));\n        r.append(row);\n    }\n    return r;\n};\n	40	108	python
def hello():\n    print "Hello, World!"\n	121	330	python
def hello():\n    print "Hello, World!"\n	123	332	python
var vertical = function() {\n    var r = elt('table');\n    for (var i in arguments) {\n        var row = elt('tr', {}, elt('td', {}, arguments[i]));\n        r.append(row);\n    }\n    return r;\n};\n	40	109	javascript
var elt = function(name, attrs) {\n    var r = $(document.createElement(name));\n    if (attrs) {\n        for (var i in attrs) {\n            r.attr(i, attrs[i]);\n        }\n    }\n    for (var i = 2; i < arguments.length; ++i) {\n        r.append(arguments[i]);\n    }\n    return r;\n};\n	15	119	javascript
var horizontal = function() {\n    var row = elt('tr');\n    for (var i = 0; i < arguments.length; ++i) {\n        var cell = elt('td', {}, arguments[i]);\n        row.append(cell);\n    }\n    return elt('table', {}, row);\n};\n	38	120	javascript
var vertical = function() {\n    var r = elt('table');\n    for (var i = 0; i < arguments.length; ++i) {\n        var row = elt('tr', {}, elt('td', {}, arguments[i]));\n        r.append(row);\n    }\n    return r;\n};\n	40	121	javascript
def wrap_fields(wrapper, dictionary):\n    ret = {}\n    for (k,v) in dictionary.items:\n        if k in wrapper:\n            ret[k] = wrapper([k])(v)\n        else:\n            ret[k] = v\n    return ret\n	42	123	python
def wrap_fields(wrapper, dictionary):\n    ret = {}\n    for (k,v) in dictionary.items():\n        if k in wrapper:\n            ret[k] = wrapper[k](v)\n        else:\n            ret[k] = v\n    return ret\n	42	127	python
def dict_inverse(dictionary):\n    r = {}\n    for k,v in dictionary.items():\n        r[v] = k\n    return r\n	44	130	python
def dict_inverse(dictionary):\n    r = {}\n    for k,v in dictionary.items():\n        if v in r:\n            raise ValueError(\n                """Dictionary given to dict_inverse is not one-to-one.  \n                   Duplicate value: {value}\n                   Mapped to by: {key1} and {key2}""".format(value=v, key1=r[v], key2=k))\n        r[v] = k\n    return r\n	44	134	python
def dict_inverse_multi(dictionary):\n    r = {}\n    for k,v in dictionary.items():\n        if v in r:\n            r[v].add(k)\n        else:\n            r[v] = set((k,))\n    return r\n	46	137	python
var label_table = function(dict) {\n    var ret = elt('table');\n    for (var i in dict) {\n        ret.append(elt('tr', {}, \n                       elt('td', {}).text(i),\n                       elt('td', {}, dict[i])));\n    }\n    return ret;\n};\n	48	143	python
var label_table = function(dict) {\n    var ret = elt('table');\n    for (var i in dict) {\n        ret.append(elt('tr', {}, \n                       elt('td', {}).text(i),\n                       elt('td', {}, dict[i])));\n    }\n    return ret;\n};\n	48	144	javascript
var label_table = function(dict) {\n    var ret = elt('table');\n    for (var i in dict) {\n        ret.append(elt('tr', {}, \n                       elt('td', {}).text(i),\n                       elt('td', {}, dict[i])));\n    }\n    return ret;\n};\n	48	145	python
var label_table = function(dict) {\n    var ret = elt('table');\n    for (var i in dict) {\n        ret.append(elt('tr', {}, \n                       elt('td', {}).text(i),\n                       elt('td', {}, dict[i])));\n    }\n    return ret;\n};\n	48	149	javascript
def normalize_code(code):\n    (s,indent) = strip_indent(code)\n    return (s.strip() + "\\n", indent)\n	62	153	python
def normalize_code(code):\n    (s,indent) = strip_indent(code)\n    return (s.strip() + "\\n", indent)\n	62	155	python
def game_loop():\n    print("There will be a big game here soon.")\n	65	165	python
file_extension_map = {\n    "python": "py",\n    "javascript": "js"\n}\n	68	171	python
def game_loop():\n    print("There will be a big game here soon.")\n    return FROBNICATE!\n	65	175	python
\n	65	177	python
def monkeypatch():\n    print "MONKEYPATCH!"\n	65	178	python
def monkeypatch():\n    print "MONKEYPATCH!" if you are into the whole brevity thing else "MONKEYPATCHerino"\n	65	179	python
def monkeypatch():\n    print "MONKEYPATCH!" if you are into the whole brevity thing else "MONKEYPATCHerino"\n    print "Bogus brevity!"\n	65	180	python
def jsonwrap(f):\n    from django.http import HttpResponse\n    import json\n    \n    def cb(*args, **kwargs):\n        datastructure = f(*args, **kwargs)\n        return HttpResponse(content=json.dumps(datastructure), mimetype='application/json')\n    return cb\n	11	181	python
def strip_indent(text):\n    lines = text.splitlines()\n    lengths = map(lambda l: len(initial_whitespace(l)), lines)\n    if not lengths:\n        return ("", "")\n    initial = min(1000, *lengths) # indenting by 1000 characters?  yow!\n    ret = ('\\n'.join(map(lambda l: l[initial:], lines)), " " * initial)\n    return ret\n	25	182	python
LINE_COMMENT_MAP = {\n    "python": "#",\n    "javascript": "//",\n}\n	29	183	python
language_to_line_comment_map = {\n    "python": "#",\n    "javascript": "//",\n}\n	29	185	python
import heapq\n	11	186	python
def monkeypatch():\n    print "MONKEYPATCH!" if you are into the whole brevity thing else "MONKEYPATCHerino"\n    print "Bogus bugfix"\n	65	187	python
def monkeypatch():\n    print "MONKEYPATCH!" if you are into the whole brevity thing else "MONKEYPATCHerino"\n    print "Bogus bugfix"\n    print "oh snap!"\n	65	188	python
line_comment_map = {\n    'python': '#',\n    'javascript': '//',\n}\n	29	189	python
def monkeypatch():\n    print "MONKEYPATCH!" if you are into the whole brevity thing else "MONKEYPATCHerino"\n    print "Bogus bugfix"\n    print "oh snap!"\n    return awesome_shit\n	65	191	python
def monkeypatch():\n    print "MONKEYPATCH!" if you are into the whole brevity thing else "MONKEYPATCHerino"\n    print "Bogus bugfix"\n    print "oh snap!"\n    return awesome_shit on a stick\n	65	192	python
def monkeypatch():\n    print "MONKEYPATCH!" if you are into the whole brevity thing else "MONKEYPATCHerino"\n    print "Bogus bugfix"\n    print "oh snap!"\n    return awesome_shit\n	65	193	python
def monkeypatch():\n    print "MONKEYPATCH!" if you are into the whole brevity thing else "MONKEYPATCHerino"\n    print "Bogus bugfix"\n    print "oh snap!"\n    return awesome_shitsisss\n	65	194	python
def monkeypatch():\n    print "MONKEYPATCH!" if you are into the whole brevity thing else "MONKEYPATCHerino"\n    print "Bogus bugfix"\n    print "oh snap!"\n    return awesome_shitsisssTAAAASTIC\n	65	195	python
def monkeypatch():\n    print "MONKEYPATCH!" if you are into the whole brevity thing else "MONKEYPATCHerino"\n    print "Bogus bugfix"\n    print "oh snap!"FOOOOO\n    return awesome_shitsisssTAAAASTIC\n	65	196	python
def random_item(l):\n    """\n    Return a random element from the given sequence\n    (the sequence must provide __len__ and __get__).\n    """\n    return l[random.randint(0, len(l) - 1)]\n	75	270	python
def hello():\n    print "Hello, World!"\n	117	326	python
def hello():\n    print "Hello, World!"\n	119	328	python
split_lines = words\n	340	925	haskell
import socket, string, base64\n\n# aspen, v1, 6/19/2009\n# thanks for playing.\nclass socket_man:\n    def __init__(self,port):\n        self._socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)\n        self._socket.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)\n        self._socket.bind(("", port))\n        self._socket.listen(5)\n    def startserve(self):\n        while 1:\n            addr = self._socket.accept()\n            server = serveD(addr[0])\n            server.serve()\n\nclass serveD:\n    def __init__(self,socket):\n        self.socket = socket\n        \n    def serve(self):\n        self.socket.send("220 welcome $\\r\\n")\n        self.socket.recv(1024)\n        self.socket.send("250-u-suck.com \\r\\n")\n        self.socket.send("250 AUTH LOGIN PLAIN  \\r\\n")\n        array = self.socket.recv(1024)\n        array.replace('AUTH', '')\n        decoded = base64.decodestring(array[11:])\n        userpass = decoded.split("\\x00")\n        user = userpass[1]\n        password = userpass[2]\n#        return user, password #return the stuff if we are called elsewhere.\n        print "user: ", user, "password: ", password, "\\n"\n        self.socket.send("535 HAX \\r\\n") # yes, you actually do.\n        self.socket.close()\n\n\n\nif __name__ == '__main__':\n    port = 6664 #specify port.\n    print ("running on port", port) #echo what we're doing to be clear.\n    s = socket_man(port)\n    s.startserve()\n	73	201	python
def pop_random(l):\n    """\n    Remove and return a random element from the given sequence\n    (the sequence must provide __len__ and __get__).\n    """\n    import random\n    return l[random.range(0, len(l))]\n	75	203	python
import hashlib\n	78	209	python
def md5(str):\n    import hashlib\n    return hashlib.md5().update(str).hexdigest()\n	80	213	python
def md5(str):\n    return hashlib.md5().update(str).hexdigest()\n	80	217	python
import urllib\n	82	219	python
def gravatar_url(email, size=80, default=None):\n    params = { 'size': size }\n    if default is not None:\n        params['default'] = default\n    hash = md5(email.strip().lower())\n    qs = urllib.urlencode(params)\n    return "http://www.gravatar.com/%(hash)s?%(qs)s" % { 'hash': hash, 'qs': qs }\n	84	224	python
def md5(str):\n    h = hashlib.md5()\n    h.update(str)\n    return h.hexdigest()\n	80	228	python
def gravatar_url(email, size=80, default=None):\n    params = { 'size': size }\n    if default is not None:\n        params['default'] = default\n    hash = md5(email.strip().lower())\n    qs = urllib.urlencode(params)\n    return "http://www.gravatar.com/avatar/%(hash)s?%(qs)s" % { 'hash': hash, 'qs': qs }\n	84	229	python
var dropdown = function(clicker, make_elements) {\n    var div = elt('div', {}, clicker);\n    var onclick = function() {\n        var list = elt('table');\n        div.append(list);\n        clicker.unbind('click');\n        clicker.click(function() {\n            clicker.unbind('click');\n            list.remove();\n            clicker.click(onclick);\n            return false;\n        });\n\n        make_elements(function(e) {\n            list.append(elt('tr', {}, elt('td', {}, e)));\n        });\n    };\n    clicker.click(onclick);\n    return div;\n};\n	86	231	javascript
def random_item(l):\n    """\n    Return a random element from the given sequence\n    (the sequence must provide __len__ and __get__).\n    """\n    import random\n    return l[random.randrange(0, len(l))]\n	75	236	python
def random_item(l):\n    """\n    Return a random element from the given sequence\n    (the sequence must provide __len__ and __get__).\n    """\n    import random\n    return l[random.range(0, len(l))]\n	75	239	python
def random_item(l):\n    """\n    Return a random element from the given sequence\n    (the sequence must provide __len__ and __get__).\n    """\n    import ranom\n    return l[random.range(0, len(l))]\n	75	241	python
def random_item(l):\n    """\n    Return a random element from the given sequence\n    (the sequence must provide __len__ and __get__).\n    """\n    import random\n    return l[random.range(0, len(l))]\n	75	242	python
def monkeypatch():\n    print "MONKEYPATCH!" if you are into the whole brevity thing else "MONKEYPATCHerino"\n    print "Bogus bugfix"\n    print "oh snap!"FOOOOO\n    return awesome_shitsisssTAAAASTICfoo\n	65	243	python
def monkeypatch():\n    print "MONKEYPATCH!" if you are into the whole brevity thing else "MONKEYPATCHerino"\n    return False\n	65	244	python
def monkeypatch():\n    print "MONKEYPATCH!"\n    return False\n	65	245	python
def monkeypatch():\n    print "MONKEYPATCH"\n    return False\n	65	246	python
import inspect\n	88	248	python
import random\n	90	253	python
def random_item(l):\n    """\n    Return a random element from the given sequence\n    (the sequence must provide __len__ and __get__).\n    """\n    import random\n    return l[random.randint(0, len(l) - 1)]\n	75	255	python
def random_item(l):\n    """\n    Return a random element from the given sequence\n    (the sequence must provide __len__ and __get__).\n    """\n    import random\n    return l[random.randint(0, len(l) - 1)]\n	75	257	python
def call_to_arg_dict(func, *args, **opts):\n    argspec = inspect.getargspec(func)\n    optional = len(argspec.defaults)\n    mandatory = len(argspec.args) - optional\n\n    argmap = {}\n    if argspec.varargs:\n        argmap[argspec.varargs] = []\n    if argspec.keywords:\n        argmap[argspec.keywords] = {}\n    \n    for i in range(0,len(args)):\n        if i >= len(argspec.args):\n            if argspec.varargs:\n                argmap[argspec.varargs].append(args[i])\n            else:\n                raise TypeError(func.__name__ + "() takes at most " + str(mandatory + optional) + " arguments (" + str(len(args)) + " given)")\n        else:\n            argmap[argspec.args[i]] = args[i]\n\n    for k in opts.keys():\n        if k in argmap:\n            raise TypeError(func.__name__ + "() got multiple values for keyword argument '" + k + "'")\n        if k in argspec.args:\n            argmap[k] = opts[k]\n        elif argspec.keywords:\n            argmap[argspec.keywords][k] = opts[k]\n        else:\n            raise TypeError(func.__name__ + "() got an unexpected keyword argument '" + k + "'")\n    \n    defaults = {}\n    for i in range(0,optional):\n        defaults[argspec.args[mandatory+i]] = argspec.defaults[i]\n\n    for k in argspec.args:\n        if k not in argmap:\n            if k in defaults:\n                argmap[k] = defaults[k]\n            else:\n                raise TypeError(func.__name__ + "() takes at least " + str(mandatory) + " arguments (" + str(len(args)) + " given)")\n    \n    return argmap\n	92	259	python
def random_item(l):\n    """\n    Return a random element from the given sequence\n    (the sequence must provide __len__ and __get__).\n    """\n    import random\n    goob\n    return l[random.randint(0, len(l) - 1)]\n	75	262	python
def random_item(l):\n    """\n    Return a random element from the given sequence\n    (the sequence must provide __len__ and __get__).\n    """\n    import random\n    return l[random.randint(0, len(l) - 1)]\n	75	263	python
def instance_methods(obj):\n    return dict([ (m,getattr(obj,m)) for m in dir(obj) \n                                     if inspect.ismethod(getattr(obj,m)) ])\n	94	266	python
import sys\n	96	272	python
def command_interface(obj):\n    def help():\n        sys.stderr.write(name + ": " + obj.__doc__ + "\\n")\n        sys.stderr.write("Commands:\\n")\n        for k,v in instance_methods(obj).items():\n            if re.match(r'^_', k): continue\n            doc = ((v.__doc__ or "").splitlines() or [""])[0]\n            sys.stderr.write("    " + k + ":\\t" + doc + "\\n")\n    \n    def help_cmd(cmd):\n        func = getattr(obj, cmd)\n        sys.stderr.write(name + " " + cmd + ": " + func.__doc__ + "\\n")\n\n    name = sys.argv[0]\n    if len(sys.argv) < 2:\n        help()\n        return    \n    cmd = sys.argv[1]\n\n    if cmd == 'help':\n        if len(sys.argv) > 2 and hasattr(obj, sys.argv[2]):\n            help_cmd(sys.argv[2])\n        else:\n            help()\n        return\n\n    args = []\n    opts = {}\n    for arg in sys.argv[2:]:\n        m = re.match(r'^--(\\w+)$', arg)\n        if m:\n            opts[m.group(1)] = True\n            continue\n        m = re.match(r'^--(\\w+)=(.*)$', arg)\n        if m:\n            opts[m.group(1)] = m.group(2)\n            continue\n        args.append(arg)\n\n    if not hasattr(obj, cmd):\n        help()\n        return\n    \n    func = getattr(obj, cmd)\n    try:\n        func(*args, **opts)\n    except TypeError:\n        help_cmd(cmd)\n	98	279	python
def command_interface(obj):\n    def help():\n        sys.stderr.write(name + ": " + (obj.__doc__ or "") + "\\n")\n        sys.stderr.write("Commands:\\n")\n        for k,v in instance_methods(obj).items():\n            if re.match(r'^_', k): continue\n            doc = ((v.__doc__ or "").splitlines() or [""])[0]\n            sys.stderr.write("    " + k + ":\\t" + doc + "\\n")\n    \n    def help_cmd(cmd):\n        func = getattr(obj, cmd)\n        sys.stderr.write(name + " " + cmd + ": " + func.__doc__ + "\\n")\n\n    name = sys.argv[0]\n    if len(sys.argv) < 2:\n        help()\n        return    \n    cmd = sys.argv[1]\n\n    if cmd == 'help':\n        if len(sys.argv) > 2 and hasattr(obj, sys.argv[2]):\n            help_cmd(sys.argv[2])\n        else:\n            help()\n        return\n\n    args = []\n    opts = {}\n    for arg in sys.argv[2:]:\n        m = re.match(r'^--(\\w+)$', arg)\n        if m:\n            opts[m.group(1)] = True\n            continue\n        m = re.match(r'^--(\\w+)=(.*)$', arg)\n        if m:\n            opts[m.group(1)] = m.group(2)\n            continue\n        args.append(arg)\n\n    if not hasattr(obj, cmd):\n        help()\n        return\n    \n    func = getattr(obj, cmd)\n    try:\n        func(*args, **opts)\n    except TypeError:\n        help_cmd(cmd)\n	98	286	python
languages = ["python", "javascript"]\n	101	289	python
language_list = ["python", "javascript"]\n	101	291	python
language_list = ["python", "javascript"]\n	101	294	python
def filename_to_language(filename):\n    """\n    Given a filename, use the extension to determine\n    the code-language and return the string associated\n    with that language.\n    """\n    for language, extension in file_extension_map:\n        if filename.rsplit(".")[1] == extension:\n            return language\n    return None\n	103	296	python
def filename_to_language(filename):\n    """\n    Given a filename, use the extension to determine\n    the code-language and return the string associated\n    with that language.\n    """\n    for language, extension in language_to_file_extension_map:\n        if filename.rsplit(".")[1] == extension:\n            return language\n    return None\n	103	297	python
language_to_file_extension_map = {\n    "python": "py",\n    "javascript": "js"\n}\n	68	298	python
language_to_line_comment_map = {\n    'python': '#',\n    'javascript': '//',\n}\n	29	299	python
def command_interface(obj):\n    def help():\n        sys.stderr.write(name + ": " + (obj.__doc__ or "") + "\\n")\n        sys.stderr.write("Commands:\\n")\n        for k,v in instance_methods(obj).items():\n            if re.match(r'^_', k): continue\n            doc = ((v.__doc__ or "").splitlines() or [""])[0]\n            sys.stderr.write("    " + k + ":\\t" + doc + "\\n")\n    \n    def help_cmd(cmd):\n        func = getattr(obj, cmd)\n        sys.stderr.write(name + " " + cmd + ": " + func.__doc__ + "\\n")\n\n    name = sys.argv[0]\n    if len(sys.argv) < 2:\n        help()\n        return    \n    cmd = sys.argv[1]\n\n    if cmd == 'help':\n        if len(sys.argv) > 2 and hasattr(obj, sys.argv[2]):\n            help_cmd(sys.argv[2])\n        else:\n            help()\n        return\n\n    args = []\n    opts = {}\n    for arg in sys.argv[2:]:\n        m = re.match(r'^--(\\w+)$', arg)\n        if m:\n            opts[m.group(1)] = True\n            continue\n        m = re.match(r'^--(\\w+)=(.*)$', arg)\n        if m:\n            opts[m.group(1)] = m.group(2)\n            continue\n        args.append(arg)\n\n    if not hasattr(obj, cmd):\n        help()\n        return\n    \n    func = getattr(obj, cmd)\n    try:\n        func(*args, **opts)\n    except TypeError as e:\n        help_cmd(cmd)\n	98	300	python
class Version:\n    """\n    The version of a snippet in the form versionptr/version.\n    """\n    def __init__(self, versionptr, version):\n        self.versionptr = versionptr\n        self.version = version\n    \n    def __str__(self):\n        return "{0}/{1}/".format(self.versionptr, self.version)\n	105	302	python
import json\n	107	306	python
class JSONClient:\n    def __init__(self, host):\n        self._host = host\n\n    def post(self, url, params):\n        params_enc = urllib.urlencode(params)\n        conn = httplib.HTTPConnection(self._host)\n        headers = { "Content-type": "application/x-www-form-urlencoded",\n                    "Accept": "application/json" }\n        conn.request('POST', url, params_enc, headers)\n        response = conn.getresponse()\n        if response.status != 200:\n            raise IOError(str(response.status) + " " + response.reason + ":\\n" + response.read())\n        jsonstr = response.read()\n        response.close()\n        return json.loads(jsonstr)\n\n    def get(self, url, params={}):\n        params_enc = urllib.urlencode(params)\n        if params_enc: params_enc = '?' + params_enc\n        conn = httplib.HTTPConnection(self._host)\n        conn.request("GET", url + params_enc)\n        response = conn.getresponse()\n        if response.status != 200:\n            raise IOError(str(response.status) + " " + response.reason + ":\\n" + response.read())\n        jsonstr = response.read()\n        response.close()\n        return json.loads(jsonstr)\n	109	310	python
import urllib\n	111	312	python
import httplib\n	113	317	python
class JSONClient:\n    def __init__(self, host):\n        self._host = host\n\n    def post(self, url, params):\n        params_enc = urllib.urlencode(params)\n        conn = httplib.HTTPConnection(self._host)\n        headers = { "Content-type": "application/x-www-form-urlencoded",\n                    "Accept": "application/json" }\n        conn.request('POST', url, params_enc, headers)\n        response = conn.getresponse()\n        if response.status != 200:\n            raise IOError(str(response.status) + " " + response.reason + ":\\n" + response.read())\n        jsonstr = response.read()\n        response.close()\n        return json.loads(jsonstr)\n\n    def get(self, url, params={}):\n        params_enc = urllib.urlencode(params)\n        if params_enc: params_enc = '?' + params_enc\n        conn = httplib.HTTPConnection(self._host)\n        conn.request("GET", url + params_enc)\n        response = conn.getresponse()\n        if response.status != 200:\n            raise IOError(str(response.status) + " " + response.reason + ":\\n" + response.read())\n        jsonstr = response.read()\n        response.close()\n        return json.loads(jsonstr)\n	109	323	python
class DictObject:\n    def __init__(self, dic):\n        self.__dict__ = dic\n    \n    def __getattr__(self, name):\n        return dic[name]\n\n    def __setattr__(self, name, value):\n        dic[name] = value\n	125	335	python
class DictObject:\n    def __init__(self, dic):\n        self.__dict__ = dic\n	125	337	python
class Version:\n    """\n    The version of a snippet in the form versionptr/version.\n    """\n    def __init__(self, versionptr, version):\n        self.versionptr = versionptr\n        self.version = version\n    \n    def __str__(self):\n        return "{0}/{1}".format(self.versionptr, self.version)\n	105	341	python
def maximum_by(f, lst):\n    (bestx,xs) = (lst[0],lst[1:])\n    bestf = f(bestx)\n    for x in xs:\n        fx = f(x)\n        if fx > bestf:\n            (bestf,bestx)=(fx,x)\n    return bestx\n	127	343	python
def maximum_by(f, lst):\n    (bestx,xs) = (lst[0],lst[1:])\n    bestf = f(bestx)\n    for x in xs:\n        fx = f(x)\n        if fx > bestf:\n            (bestf,bestx)=(fx,x)\n    return bestx\n	129	345	python
def maximum_by(f, lst):\n    (bestx,xs) = (lst[0],lst[1:])\n    bestf = f(bestx)\n    for x in xs:\n        fx = f(x)\n        if fx > bestf:\n            (bestf,bestx)=(fx,x)\n    return bestx\n	131	349	None
def maximum_by(f, lst):\n    (bestx,xs) = (lst[0],lst[1:])\n    bestf = f(bestx)\n    for x in xs:\n        fx = f(x)\n        if fx > bestf:\n            (bestf,bestx)=(fx,x)\n    return bestx\n	133	351	python
def detect_by_pattern(text, patterns):\n    scores = {}\n    for k,pats in patterns.items():\n        scores[k] = 0\n        for p in pats:\n            scores[k] += len(p.findall(text))\n    \n    return maximum_by(lambda (k,v): v, scores.items())[0]\n	135	356	python
def random_item(l):\n    """\n    Return a random element from the given sequence\n    (the sequence must provide __len__ and __get__).\n    """\n    print "test"\n    return l[random.randint(0, len(l) - 1)]\n	75	359	python
def random_item(l):\n    """\n    Return a random element from the given sequence\n    (the sequence must provide __len__ and __get__).\n    """\n    return l[random.randint(0, len(l) - 1)]\n	75	361	python
def detect_by_pattern(text, patterns):\n    scores = {}\n    for k,pats in patterns.items():\n        scores[k] = 0\n        for p in pats:\n            scores[k] += len(p.findall(text))\n    \n    return maximum_by(lambda (k,v): v, scores.items())[0]\n	135	362	python
language_patterns = {\n    'python': [\n        re.compile(r'def\\s+\\w+\\s*\\(.*:\\s*$', re.MULTILINE),\n        re.compile(r'for\\s+\\w+\\s+in\\s+\\w+\\s*:\\s*$', re.MULTILINE),\n        re.compile(r'if\\s+.*:\\s*$', re.MULTILINE),\n    ],\n    'javascript': [\n        re.compile(r'var\\s+\\w+\\s*=', re.MULTILINE),\n        re.compile(r'function\\s+(?:\\w+)?\\s*\\([\\w\\s,]*\\)\\s*{'),  #not multiline\n        re.compile(r'for\\s*\\((?:\\s*var\\s)?\\s*\\w+\\s+in\\s+.*\\)', re.MULTILINE),\n    ],\n}\n	137	364	python
language_patterns = {\n    'python': [\n        re.compile(r'def\\s+\\w+\\s*\\(.*:\\s*$', re.MULTILINE),\n        re.compile(r'for\\s+\\w+\\s+in\\s+\\w+\\s*:\\s*$', re.MULTILINE),\n        re.compile(r'if\\s+.*:\\s*$', re.MULTILINE),\n    ],\n    'javascript': [\n        re.compile(r'var\\s+\\w+\\s*=', re.MULTILINE),\n        re.compile(r'function\\s+(?:\\w+)?\\s*\\([\\w\\s,]*\\)\\s*{'),  #not multiline\n        re.compile(r'for\\s*\\((?:\\s*var\\s)?\\s*\\w+\\s+in\\s+.*\\)', re.MULTILINE),\n    ],\n}\n	137	368	python
def detect_language(text):\n    return detect_by_pattern(text, language_patterns)\n	139	370	python
def detect_language(text):\n    return detect_by_pattern(text, language_patterns)\n	139	373	python
def partition(pattern, text):\n    m = pattern.search(text)\n    if m:\n        return (text[0:m.start()], m.groups(), text[m.end():])\n    else:\n        return None\n	141	376	python
def case(proj, value, cases):\n    return cases[proj(value)](value)\n	143	381	python
def uncons_set(s):\n    clone = set(s)\n    x = clone.pop()\n    return (x, frozenset(clone))\n	145	390	python
def dependency_search(alternatives, versionptr):\n    def children(elem):\n        (vptr, rest) = uncons_set(elem)\n        snips = alternatvies(vptr)\n        return (( snip.weight, snip.deps | rest, snip.code ) for snip in snips)\n    def success(elem):\n        return len(elem) == 0\n    return shortest_path(children, success, frozenset(versionptr,))\n	147	395	python
def dependency_search(alternatives, versionptr):\n    def children(elem):\n        (vptr, rest) = uncons_set(elem)\n        snips = alternatvies(vptr)\n        return (( snip.weight, snip.deps | rest, snip.code ) for snip in snips)\n    def success(elem):\n        return len(elem) == 0\n    return shortest_path(children, success, frozenset(versionptr,))\n	147	398	python
def dependency_search(members, type):\n    def children(elem):\n        (typ, rest) = uncons_set(elem)\n        mems = members(typ)\n        return (( mem.weight, mem.deps | rest, mem.code ) for mem in mems)\n    def success(satset):\n        return len(satset) == 0\n    return shortest_path(children, success, frozenset(type,))\n	147	399	python
import pprint\n	149	407	python
def prettify_json(str):\n    return pprint.pformat(json.loads(str))\n	151	410	python
def prettify_json(str):\n    return pprint.pformat(json.loads(str))\n	151	411	python
def dependency_search(members, type):\n    def children(elem):\n        (typ, rest) = uncons_set(elem)\n        mems = list(members(typ))\n        return (( mem.weight, mem.deps | rest, mem.object ) for mem in mems)\n    def success(satset):\n        return len(satset) == 0\n    return shortest_path(children, success, frozenset((type,)))\n	147	413	python
def dependency_search(members, type):\n    def children(elem):\n        (typ, rest) = uncons_set(elem)\n        mems = list(members(typ))\n        return (( mem.weight, mem.deps | rest, mem.object ) for mem in mems)\n    def success(satset):\n        return len(satset) == 0\n    return shortest_path(children, success, frozenset((type,)))\n	147	414	python
var horizontal = function() {\n    var row = elt('tr');\n    for (var i = 0; i < arguments.length; ++i) {\n        var cell = elt('td', {}, arguments[i]);\n        row.append(cell);\n    }\n    return elt('table', {'style':'width:100%'}, row);\n};\n	38	415	javascript
var horizontal = function() {\n    var row = elt('tr');\n    for (var i = 0; i < arguments.length; ++i) {\n        var cell = elt('td', {}, arguments[i]);\n        row.append(cell);\n    }\n    return elt('table', {}, row);\n};\n	38	416	javascript
def strip_indent(text):\n    lines = text.splitlines()\n    all_ws = re.compile('^\\s*$')\n    lengths = map(lambda l: len(initial_whitespace(l)), filter(lambda s: not all_ws.match(s), lines))\n    if not lengths:\n        return ("", "")\n    initial = min(1000, *lengths) # indenting by 1000 characters?  yow!\n    ret = ('\\n'.join(map(lambda l: l[initial:], lines)), " " * initial)\n    return ret\n	25	417	python
def partition(pattern, text):\n    m = re.search(pattern, text)\n    if m:\n        return (text[0:m.start()], m.groups(), text[m.end():])\n    else:\n        return None\n	141	418	python
def merge(dict1, dict2):\n    return dict(dict1, **dict2)\n	153	423	python
var dynamic_link = function(text, click) {\n        var r = elt('a', {'href': '#'}).text(click);\n        r.click(function() { click(); return false; });\n        return r;\n    };\n	158	432	javascript
def foobar():\n    return "FOOBAR"\n	160	434	python
def foobar():\n    return "FOOBAR"\n	162	436	python
var dynamic_link = function(text, click) {\n        var r = elt('a', {'href': '#'}).text(click);\n        r.click(function() { click(); return false; });\n        return r;\n    };\n	164	438	javascript
def strip_indent(text):\n    lines = text.splitlines()\n    all_ws = re.compile('^\\s*$')\n    lengths = [ len(initial_whitespace(l)) for l in lines if not all_ws.match(l) ]\n    if not lengths:\n        return ("", "")\n    initial = min(*lengths)\n    ret = ('\\n'.join(map(lambda l: l[initial:], lines)), " " * initial)\n    return ret\n	25	442	python
def strip_indent(text):\n    lines = text.splitlines()\n    all_ws = re.compile('^\\s*$')\n    lengths = [ len(initial_whitespace(l)) for l in lines if not all_ws.match(l) ]\n    if not lengths:\n        return ("", "")\n    initial = min(lengths)\n    ret = ('\\n'.join(map(lambda l: l[initial:], lines)), " " * initial)\n    return ret\n	25	443	python
var dynamic_link = function(text, click) {\n    var r = elt('a', {'href': '#'}).text(click);\n    r.click(function() { click(); return false; });\n    return r;\n};\n	166	445	javascript
var dynamic_link = function(text, click) {\n    var r = elt('a', {'href': '#'}).text(click);\n    r.click(function() { click(); return false; });\n    return r;\n};\n	166	448	javascript
var dynamic_link = function(text, click) {\n    var r = elt('a', {'href': '#'}).text(text);\n    r.click(function() { click(); return false; });\n    return r;\n};\n	166	449	javascript
var dynamic_link = function(text, click) {\n    var r = elt('a', {'href': '#'}).text(text);\n    r.click(function() { click(); return false; });\n    return r;\n};\n	166	450	python
var dynamic_link = function(text, click) {\n    var r = elt('a', {'href': '#'}).text(text);\n    r.click(function() { click(); return false; });\n    return r;\n};\n	166	451	javascript
class PriorityQueue:\n    def __init__(self, *args):\n        self._q = []\n        self._q.extend(args)\n    \n    def peek(self):\n        if self._q:\n            return self._q[0]\n        return None\n    \n    def pop(self):\n        return heapq.heappop(self._q)\n    \n    def append(self, *elements):\n        for element in elements:\n            heapq.heappush(self._q, element)\n	168	453	python
class Scheduler:\n    def __init__(self):\n        import heapq\n        self._registry = PriorityQueue()\n        \n    def add(self, time, lam):\n        self._registry.append((time, lam))\n    \n    def process(self, time, *args, **kwargs):\n        while True:\n            next = self._registry.peek()\n            if next is not None and next[0] <= time:\n                self._registry.pop()\n                next[1](*args, **kwargs)\n            else:\n                break\n	170	455	python
class Scheduler:\n    def __init__(self):\n        import heapq\n        self._registry = PriorityQueue()\n        \n    def add(self, time, lam):\n        self._registry.append((time, lam))\n    \n    def process(self, time, *args, **kwargs):\n        while True:\n            next = self._registry.peek()\n            if next is not None and next[0] <= time:\n                self._registry.pop()\n                next[1](*args, **kwargs)\n            else:\n                break\n	170	456	python
def frob_ni_cate(o):\n    print o\n	172	458	python
var rate_limited_callback = function(rate, cb) {\n    var timeout = null;\n\n    return function() {\n        if (timeout) { clearTimeout(timeout); timeout = null; }\n        timeout = setTimeout(cb, rate);\n    };\n};\n	174	460	javascript
var realtime_input = function(rate, cb) {\n    var input = elt('input', {'type':'text'});\n    var pvalue = null;\n    var rlcb = rate_limited_callback(rate, function() { \n        var value = input.val();\n        if (value == pvalue) return;\n        pvalue = value;\n        cb(value);\n    });\n    return input.keydown(rlcb).change(rlcb).blur(rlcb);\n};\n	176	466	javascript
var realtime_input = function(rate, cb) {\n    var input = elt('input', {'type':'text'});\n    var pvalue = null;\n    var rlcb = rate_limited_callback(rate, function() { \n        var value = input.val();\n        if (value == pvalue) return;\n        pvalue = value;\n        cb(value);\n    });\n    return input.keydown(rlcb).change(rlcb).blur(rlcb);\n};\n	176	469	javascript
def random_hex_string(length):\n    return ''.join("0123456789abcdef"[random.randint(0,15)] for i in range(length))\n	178	472	python
var tabs = function(ts) {\n    var tablabels = elt('tr');\n    var tabtable = elt('table', { 'class': 'tabstrip' }, tablabels);\n    var content = elt('div', { 'class': 'content' });\n    var container = elt('div', { 'class': 'tabs' }, tabtable, content); \n    var cur;\n\n    for (var i in ts) {\n        (function() {\n            var t = ts[i];\n            var cb = function() {\n                if (!t.contentCache) {\n                    if (typeof t.content == "function") {\n                        t.contentCache = t.content();\n                    }\n                    else {\n                        t.contentCache = t.content;\n                    }\n                    content.append(t.contentCache);\n                }\n                if (cur) { \n                    cur.contentCache.addClass('hidden'); \n                    cur.tab.removeClass('selected');\n                }\n                cur = t;\n                t.contentCache.removeClass('hidden');\n                t.tab.addClass('selected');\n            };\n            t.tab = elt('td', { 'class': 'tab' }).text(t.label);\n            t.tab.click(cb);\n            tablabels.append(t.tab);\n            if (i == 0) cb();\n        })();\n    }\n    \n    return container;\n};\n	180	474	javascript
var tabs = function(ts) {\n    var tablabels = elt('tr');\n    var tabtable = elt('table', { 'class': 'tabstrip' }, tablabels);\n    var content = elt('div', { 'class': 'content' });\n    var container = elt('div', { 'class': 'tabs' }, tabtable, content); \n    var cur;\n\n    for (var i in ts) {\n        (function() {\n            var t = ts[i];\n            var cb = function() {\n                if (!t.contentCache) {\n                    if (typeof t.content == "function") {\n                        t.contentCache = t.content();\n                    }\n                    else {\n                        t.contentCache = t.content;\n                    }\n                    content.append(t.contentCache);\n                }\n                if (cur) { \n                    cur.contentCache.addClass('hidden'); \n                    cur.tab.removeClass('selected');\n                }\n                cur = t;\n                t.contentCache.removeClass('hidden');\n                t.tab.addClass('selected');\n            };\n            t.tab = elt('td', { 'class': 'tab' }).text(t.label);\n            t.tab.click(cb);\n            tablabels.append(t.tab);\n            if (i == 0) cb();\n        })();\n    }\n    \n    return container;\n};\n	180	475	javascript
var language_to_line_comment_map = {\n    python: '#',\n    javascript: '//',\n    haskell: '--',\n    c: '//',\n    csharp: '//',\n    java: '//', \n    ruby: '#',\n};\n	29	567	javascript
once :: Eq a => a -> [a] -> Bool\nonce x = (== [x]) . filter (== x)\n	237	640	haskell
language_patterns = {\n    'python': [\n        re.compile(r'def\\s+\\w+\\s*\\(.*:\\s*$', re.MULTILINE),\n        re.compile(r'for\\s+\\w+\\s+in\\s+\\w+\\s*:\\s*$', re.MULTILINE),\n        re.compile(r'if\\s+.*:\\s*$', re.MULTILINE),\n    ],\n    'javascript': [\n        re.compile(r'var\\s+\\w+\\s*=', re.MULTILINE),\n        re.compile(r'function\\s+(?:\\w+)?\\s*\\([\\w\\s,]*\\)\\s*{'),  #not multiline\n        re.compile(r'for\\s*\\((?:\\s*var\\s)?\\s*\\w+\\s+in\\s+.*\\)', re.MULTILINE),\n    ],\n    'haskell': [\n        re.compile(r'^\\w+\\s*(?:,\\s*\\w+\\s*)*::.*->.*', re.MULTILINE),\n        re.compile(r'^\\w+\\s*=', re.MULTILINE),\n        re.compile(r'^\\s*where', re.MULTILINE),\n        re.compile(r'where\\s*$', re.MULTILINE),\n    ],\n}\n	137	481	python
language_to_line_comment_map = {\n    'python': '#',\n    'javascript': '//',\n    'haskell': '--',\n}\n	29	483	python
var linecomment = {\n    python: '#',\n    javascript: '//',\n    haskell: '--',\n};\n	29	484	javascript
language_to_file_extension_map = {\n    "python": "py",\n    "javascript": "js",\n    "haskell": "hs",\n}\n	68	485	python
var language_to_line_comment_map = {\n    python: '#',\n    javascript: '//',\n    haskell: '--',\n};\n	29	488	javascript
var keys = function(obj) {\n    var r = [];\n    for (var key in obj) {\n        r.push(key);\n    }\n    return r;\n};\n	182	491	javascript
language_list = [ k for k in language_to_line_comment_map.keys() if k in language_to_file_extension_map ]\n	101	496	python
language_list = [ k for k in language_to_line_comment_map.keys() if k in language_to_file_extension_map ]\n	101	497	python
var label_table = function(dict) {\n    var ret = elt('table');\n    for (var i in dict) {\n        ret.append(elt('tr', {}, \n                       elt('td', {'width': '1', 'class': 'label'}).text(i),\n                       elt('td', {}, dict[i])));\n    }\n    return ret;\n};\n	48	498	javascript
class Scheduler:\n    def __init__(self):\n        import heapq\n        self._registry = PriorityQueue()\n        \n    def add(self, time, lam):\n        self._registry.append((time, lam))\n    \n    def process(self, current_time, *args, **kwargs):\n        while True:\n            next = self._registry.peek()\n            if next is not None and next[0] <= current_time:\n                self._registry.pop()\n                next[1](*args, **kwargs)\n            else:\n                break\n	170	502	python
class PriorityQueue:\n    def __init__(self, *args):\n        self._q = []\n        self.append(*args)\n    \n    def peek(self):\n        if self._q:\n            return self._q[0]\n        return None\n    \n    def pop(self):\n        return heapq.heappop(self._q)\n    \n    def append(self, *elements):\n        for element in elements:\n            heapq.heappush(self._q, element)\n	168	505	python
var language_to_line_comment_map = {\n    python: '#',\n    javascript: '//',\n    haskell: '--',\n    c: '//',\n};\n	29	510	javascript
language_to_line_comment_map = {\n    'python': '#',\n    'javascript': '//',\n    'haskell': '--',\n    'c': '//',\n}\n	29	511	python
def maximum_by(measure, xs):\n    return max(xs, key=measure)\n	19	514	python
var maximum_by = function(measure, xs) {\n    var max_x = xs[0];\n    var max_measure = measure(max_x);\n    for (var i = 1; i < xs.length; i++) {\n        var m = measure(xs[i]);\n        if (m > max_measure) {\n            max_x = xs[i];\n            max_measure = m;\n        }\n    }\n    return max_x;\n};\n	19	515	javascript
def simple_prime_checker(n):\n    if n < 2: return False\n    d = 2\n    while d < n:\n        if n % d == 0: return False\n        else: d += 1\n    return True\n	187	518	python
maximum_by = Data.List.maximumBy\n	19	519	haskell
import qualified Data.Set as Set\n\nunique = Set.fromList . Set.toList\n	190	521	haskell
import qualified Data.Set\n	192	523	haskell
unique = Data.Set.fromList . Data.Set.toList\n	190	526	haskell
var language_to_line_comment_map = {\n    python: '#',\n    javascript: '//',\n    haskell: '--',\n    c: '//',\n    csharp: '//',\n};\n	29	527	javascript
language_to_line_comment_map = {\n    'python': '#',\n    'javascript': '//',\n    'haskell': '--',\n    'c': '//',\n    'csharp': '//',\n}\n	29	528	python
language_to_file_extension_map = {\n    "python": "py",\n    "javascript": "js",\n    "haskell": "hs",\n    "csharp": "cs",\n}\n	68	529	python
// Handling mouse-drags:\nfloat startx, starty;\n\n\nvoid mouse (int button, int state, int x, int y) {\n    if (state == GLUT_DOWN) {\n        startx = x; starty = y;\n        glutMotionFunc(motion_rotation);\n    } else if (state == GLUT_UP) {\n        glutMotionFunc(NULL);\n    }\n    glutPostRedisplay();\n}\n\nvoid motion_rotation (int x, int y) {\n    float dx = (x - startx);\n    float dy = (y - starty);\n    startx = x; starty = y;\n\n    glMatrixMode(GL_MODELVIEW);\t\n    GLdouble axis_x, axis_y, axis_z;\n\t\t\n    eye2object(0., 1., 0.,\n\t       &axis_x, &axis_y, &axis_z);\n    glRotatef(dx, axis_x, axis_y, axis_z);\n    eye2object(1., 0., 0.,\n\t       &axis_x, &axis_y, &axis_z);\n    glRotatef(dy, axis_x, axis_y, axis_z);\n\t\n    glutPostRedisplay();\n}\n	194	531	c
def simple_prime_checker(n):\n    import math\n    if n < 2: return False\n    d = 2\n    while d < math.sqrt(n):\n        if n % d == 0: return False\n        else: d += 1\n    return True\n	187	532	python
unique = []\n# [ unique.append(x) for x in DataSet if x not in unique ]\nfor x in DataSet:\n    if x not in unique:\n        unique.append(x)\n	190	533	python
def simple_prime_checker(n):\n    if n < 2: return False          # all integers below two are not prime\n    if n == 2: return True          # if you check two, you can check only odds after\n    from math import sqrt           # not importing unless necessary, only what we need\n    r = int(sqrt(n)) + 1            # only check up to the square root\n    d = 3\n    while d < r:\n        if n % d == 0: return False\n        else: d += 2\n    return True\n	187	534	python
def simple_prime_checker(n):\n    if n < 2: return False          # all integers below two are not prime\n    if n < 4: return True           # if you check this, you can check far less\n    from math import sqrt           # not importing unless necessary, only what we need\n    r = int(sqrt(n)) + 1            # only check up to the square root\n    d = 6\n    while d < r:\n        if n % (d-1) == 0: return False\n        if n % (d+1) == 0: return False\n        d += 6\n    return True\n	187	535	python
def simple_prime_checker(n):\n    if n < 2: return False              # all integers below two are not prime\n    if n < 4: return True               # if you check this, you can check far less\n    from math import sqrt               # not importing unless necessary, only what we need\n    r = int(sqrt(n)) + 1                # only check up to the square root\n    d = 6\n    while d < r:\n        if n % (d-1) == 0: return False # 6n-1\n        if n % (d+1) == 0: return False # 6n+1\n        d += 6\n    return True\n	187	537	python
language_to_line_comment_map = {\n    'python': '#',\n    'javascript': '//',\n    'haskell': '--',\n    'c': '//',\n    'csharp': '//',\n    'ruby': '#',\n}\n	29	568	python
maximum_by f = Data.List.maximumBy (compare `Data.Function.on` f)\n	19	663	haskell
// If you have a selector chain, like:\n//\n//    $('#articles').find('a.active').parent().somethingSomething()\n//\n// And one of the calls in it is returning an empty collection, you could stick\n// the "log()" call in between:\n//\n//    $('#articles').find('a.active').log().parent().somethingSomething()\n//\n// This will not modify the original chain, but will log the intermediate\n// result to the console, and it's simple to add and remove.\n//\n$.fn.log = function() {\n  console.log(this);\n  return this;\n}\n	198	541	javascript
$.fn.log = function() {\n  console.log(this);\n  return this;\n}\n	198	544	javascript
def simple_prime_checker(n):\n    if n < 2: return False              # all integers below two are not prime\n    if n < 4: return True               # if you check this, you can check far less\n    if n % 2 == 0 or n % 3 == 0:        # another time-saving step\n        return False\n    from math import sqrt               # not importing unless necessary, only what we need\n    r = int(sqrt(n)) + 1                # only check up to the square root\n    d = 6\n    while d < r:\n        if n % (d-1) == 0: return False # 6n-1\n        if n % (d+1) == 0: return False # 6n+1\n        d += 6\n    return True\n	187	545	python
def simple_prime_factorizer(n):\n    if n == 1: return [1]\n    f = []\n    while n % 2 == 0:\n        f += [2]\n        n /= 2\n    while n % 3 == 0:\n        f += [3]\n        n /= 3\n    if n == 1: return f\n    from math import sqrt\n    d,r = 6,int(sqrt(n))+1\n    while d > r:\n        while n % (d-1) == 0:\n            f += [(d-1)]\n            n /= d-1\n        while n % (d+1) == 0:\n            f += [(d+1)]\n            n /= d+1\n        d += 6\n        r = int(sqrt(n))+1\n    return f\n	200	547	python
def simple_prime_factorizer(n):\n    if n < 0: n *= -1           # allows the factorization of negatives\n    f = []                      # f is the list of prime factors\n    while n % 2 == 0:           # finding all twos\n        f += [2]\n        n /= 2\n    while n % 3 == 0:           # finding all threes\n        f += [3]\n        n /= 3\n    if n == 1: return f         # finishing here if possible\n    from math import sqrt       # importing sqrt\n    d,r = 6,int(sqrt(n))+1      # this part uses properties of divisibility\n    while d > r:\n        while n % (d-1) == 0:\n            f += [(d-1)]\n            n /= d-1\n        while n % (d+1) == 0:\n            f += [(d+1)]\n            n /= d+1\n        d += 6\n        r = int(sqrt(n))+1\n    return f\n	200	548	python
def simple_prime_factorizer(n):\n    if n < 0: n *= -1           # allows the factorization of negatives\n    f = []                      # f is the list of prime factors\n    while n % 2 == 0:           # finding all twos\n        f += [2]\n        n /= 2\n    while n % 3 == 0:           # finding all threes\n        f += [3]\n        n /= 3\n    if n == 1: return f         # finishing here if possible\n    from math import sqrt       # importing sqrt\n    d,r = 6,int(sqrt(n))+1      # this part uses properties of divisibility\n    while n > r:\n        while n % (d-1) == 0:\n            f += [(d-1)]\n            n /= d-1\n        while n % (d+1) == 0:\n            f += [(d+1)]\n            n /= d+1\n        d += 6\n        r = int(sqrt(n))+1\n    return f\n	200	549	python
def simple_lowest_factor(n):\n    if n == 1: return 1               # 1\n    if n % 2 == 0: return 2           # 2\n    if n % 3 == 0: return 3           # 3\n    if n < 0: n *= -1                 # allows for factoring negative integers\n    from math import sqrt             # import sqrt\n    r,d = int(sqrt(n))+1,6            # using properties of divisibility\n    while d < r:\n        if n % (d-1) == 0: return d-1 # d-1\n        if n % (d+1) == 0: return d+1 # d+1\n        d += 6\n    return n                          # n is prime\n	202	551	python
def simple_lowest_factor(n):\n    if n == 0: return 0               # 0\n    if n == 1: return 1               # 1\n    if n % 2 == 0: return 2           # 2\n    if n % 3 == 0: return 3           # 3\n    if n < 0: n *= -1                 # allows for factoring negative integers\n    from math import sqrt             # import sqrt\n    r,d = int(sqrt(n))+1,6            # using properties of divisibility\n    while d < r:\n        if n % (d-1) == 0: return d-1 # d-1\n        if n % (d+1) == 0: return d+1 # d+1\n        d += 6\n    return n                          # n is prime\n	202	552	python
def simple_prime_factorizer(n):\n    if n < 0: n *= -1           # allows the factorization of negatives\n    f = []                      # f is the list of prime factors\n    if n < 2: return f          # handles zero or one\n    while n % 2 == 0:           # finding all twos\n        f += [2]\n        n /= 2\n    while n % 3 == 0:           # finding all threes\n        f += [3]\n        n /= 3\n    if n == 1: return f         # finishing here if possible\n    from math import sqrt       # importing sqrt\n    d,r = 6,int(sqrt(n))+1      # this part uses properties of divisibility\n    while n > r:\n        while n % (d-1) == 0:\n            f += [(d-1)]\n            n /= d-1\n        while n % (d+1) == 0:\n            f += [(d+1)]\n            n /= d+1\n        d += 6\n        r = int(sqrt(n))+1\n    return f\n	200	555	python
var language_to_line_comment_map = {\n    python: '#',\n    javascript: '//',\n    haskell: '--',\n    c: '//',\n    csharp: '//',\n    java: '//', \n};\n	29	556	javascript
private static void bogosort(int[] a) {\n\t\twhile(!inOrder(a)) {\n\t\t\tfor(int i = 0; i < a.length; i++) {\n\t\t\t\tint indexToSwap1 = (int) (Math.random() * a.length); \n\t\t\t\tint indexToSwap2 = (int) (Math.random() * a.length); \n\t\t\t\t\n\t\t\t\tint temp1 = a[indexToSwap1]; \n\t\t\t\tint temp2 = a[indexToSwap2]; \n\t\t\t\t\n\t\t\t\ta[indexToSwap2] = temp1;\n\t\t\t\ta[indexToSwap1] = temp2; \n\t\t\t}\n\t\t\t\n\t\t}\n\t}\n\t\n\tprivate static boolean inOrder(int[] a) {\n\t\tboolean ordered = true;\n\t\tint minimum; \n\t\t\n\t\tif(a.length > 0) {\n\t\t\tminimum = a[0]; \n\t\t}\n\t\telse\n\t\t\treturn ordered; \n\t\t\n\t\tfor(int i = 1; i < a.length; i++ ) {\n\t\t\tif(a[i] < minimum) { \n\t\t\t\tordered = false;\n\t\t\t\tbreak; \n\t\t\t}\n\t\t\telse {\n\t\t\t\tminimum = a[i]; \n\t\t\t}\n\t\t}\n\t\treturn ordered; \n\t}\n	204	558	python
private static void bogosort(int[] a) {\n\t\twhile(!inOrder(a)) {\n\t\t\tfor(int i = 0; i < a.length; i++) {\n\t\t\t\tint indexToSwap1 = (int) (Math.random() * a.length); \n\t\t\t\tint indexToSwap2 = (int) (Math.random() * a.length); \n\t\t\t\t\n\t\t\t\tint temp1 = a[indexToSwap1]; \n\t\t\t\tint temp2 = a[indexToSwap2]; \n\t\t\t\t\n\t\t\t\ta[indexToSwap2] = temp1;\n\t\t\t\ta[indexToSwap1] = temp2; \n\t\t\t}\n\t\t\t\n\t\t}\n\t}\n\t\n\tprivate static boolean inOrder(int[] a) {\n\t\tboolean ordered = true;\n\t\tint minimum; \n\t\t\n\t\tif(a.length > 0) {\n\t\t\tminimum = a[0]; \n\t\t}\n\t\telse\n\t\t\treturn ordered; \n\t\t\n\t\tfor(int i = 1; i < a.length; i++ ) {\n\t\t\tif(a[i] < minimum) { \n\t\t\t\tordered = false;\n\t\t\t\tbreak; \n\t\t\t}\n\t\t\telse {\n\t\t\t\tminimum = a[i]; \n\t\t\t}\n\t\t}\n\t\treturn ordered; \n\t}\n	204	561	java
def collatz_step(n,c):\n    if n < 1: return -1                    # returns -1 for invalid numbers\n    if n == 1: return c                    # 1 reached, return step count\n    if n&1: return collatz_step(3*n+1,c+1) # odd step\n    return collatz_step(n>>1,c+1)          # even step\n\ndef collatz(n):\n    return collatz_step(n,0)               # start processing\n	206	563	python
def unique(l):          # only works in python3, order not guaranteed to be preserved\n    return list(set(l)) # sets do not contain duplicates\n	190	564	python
def unique(DataSet):\n    uniq = []\n# [ uniq.append(x) for x in DataSet if x not in uniq ]\n    for x in DataSet:\n        if x not in uniq:\n            uniq.append(x)\n    return uniq\n	190	565	python
\n	133	679	python
def collatz(n):\n    c=0\n    while n != 1:\n        c += 1\n        if n&1: n = 3*n+1    # odd step\n        else:   n = n>>1     # even step\n    return c\n	206	572	python
def collatz(n):\n    if n < 1 or int(n) != n: return -1      # invalid input\n    c = 0\n    while n != 1:\n        c += 1\n        if n&1: n = 3*n+1                   # odd step\n        else:   n = n>>1                    # even step\n    return c\n	206	577	python
private static void bogosort(int[] a) {\n\twhile(!inOrder(a)) {\n\t\tfor(int i = 0; i < a.length; i++) {\n\t\t\tint indexToSwap1 = (int) (Math.random() * a.length); \n\t\t\tint indexToSwap2 = (int) (Math.random() * a.length); \n\t\t\t\n\t\t\tint temp1 = a[indexToSwap1]; \n\t\t\tint temp2 = a[indexToSwap2]; \n\t\t\t\n\t\t\ta[indexToSwap2] = temp1;\n\t\t\ta[indexToSwap1] = temp2; \n\t\t}\n\t\t\n\t}\n}\n\t\nprivate static boolean inOrder(int[] a) {\n\tboolean ordered = true;\n\tint minimum; \n\t\n\tif(a.length > 0) {\n\t\tminimum = a[0]; \n\t}\n\telse\n\t\treturn ordered; \n\t\n\tfor(int i = 1; i < a.length; i++ ) {\n\t\tif(a[i] < minimum) { \n\t\t\tordered = false;\n\t\t\tbreak; \n\t\t}\n\t\telse {\n\t\t\tminimum = a[i]; \n\t\t}\n\t}\n\treturn ordered; \n}\n	204	580	python
import qualified Data.List\n	213	588	haskell
maximum_by f = Data.List.maximumBy (\\x y -> f x `compare` f y)\n	19	590	haskell
def unique(l):          # order not guaranteed to be preserved\n    return list(set(l)) # sets do not contain duplicates\n	190	591	python
private static void bogosort(int[] a) {\n\twhile(!inOrder(a)) {\n\t\tfor(int i = 0; i < a.length; i++) {\n\t\t\tint indexToSwap1 = (int) (Math.random() * a.length); \n\t\t\tint indexToSwap2 = (int) (Math.random() * a.length); \n\t\t\t\n\t\t\tint temp1 = a[indexToSwap1]; \n\t\t\tint temp2 = a[indexToSwap2]; \n\t\t\t\n\t\t\ta[indexToSwap2] = temp1;\n\t\t\ta[indexToSwap1] = temp2; \n\t\t}\n\t\t\n\t}\n}\n\t\nprivate static boolean inOrder(int[] a) {\n\tboolean ordered = true;\n\tint minimum; \n\t\n\tif(a.length > 0) {\n\t\tminimum = a[0]; \n\t}\n\telse\n\t\treturn ordered; \n\t\n\tfor(int i = 1; i < a.length; i++ ) {\n\t\tif(a[i] < minimum) { \n\t\t\tordered = false;\n\t\t\tbreak; \n\t\t}\n\t\telse {\n\t\t\tminimum = a[i]; \n\t\t}\n\t}\n\treturn ordered; \n}\n	204	594	csharp
private static void bogosort(int[] a) {\n\twhile(!inOrder(a)) {\n\t\tfor(int i = 0; i < a.length; i++) {\n\t\t\tint indexToSwap1 = (int) (Math.random() * a.length); \n\t\t\tint indexToSwap2 = (int) (Math.random() * a.length); \n\t\t\t\n\t\t\tint temp1 = a[indexToSwap1]; \n\t\t\tint temp2 = a[indexToSwap2]; \n\t\t\t\n\t\t\ta[indexToSwap2] = temp1;\n\t\t\ta[indexToSwap1] = temp2; \n\t\t}\n\t\t\n\t}\n}\n\t\nprivate static boolean inOrder(int[] a) {\n\tboolean ordered = true;\n\tint minimum; \n\t\n\tif(a.length > 0) {\n\t\tminimum = a[0]; \n\t}\n\telse\n\t\treturn ordered; \n\t\n\tfor(int i = 1; i < a.length; i++ ) {\n\t\tif(a[i] < minimum) { \n\t\t\tordered = false;\n\t\t\tbreak; \n\t\t}\n\t\telse {\n\t\t\tminimum = a[i]; \n\t\t}\n\t}\n\treturn ordered; \n}\n	204	595	java
private static <T extends Comparable<T>> boolean inOrder(T[] a) {\n    for (int i = 0; i < a.length-1; ++i) {\n        if (a[i].compareTo(a[i+1]) > 0)\n            return false;\n    }\n    return true;\n}\n	215	598	java
private static <T extends Comparable<T>> void bogosort(T[] a) {\n    while(!inOrder(a)) {\n        for(int i = 0; i < a.length; i++) {\n            int indexToSwap1 = (int) (Math.random() * a.length); \n            int indexToSwap2 = (int) (Math.random() * a.length); \n            \n            int temp1 = a[indexToSwap1]; \n            int temp2 = a[indexToSwap2]; \n            \n            a[indexToSwap2] = temp1;\n            a[indexToSwap1] = temp2; \n        }\t\n    }\n}\n	204	600	java
private static <T> void knuthShuffle(T[] a) {\n    for (int i = a.length-1; i >= 1; i--) {\n        int j = (int)(Math.random() * i);\n        T temp = a[j];\n        a[j] = a[i];\n        a[i] = temp;\n    }\n}\n	217	603	java
private static <T extends Comparable<T>> void bogosort(T[] a) {\n    while(!inOrder(a)) knuthShuffle(a);\n}\n	204	605	java
inOrder :: (Ord a) => [a] -> Bool\ninOrder xs = and $ zipWith (<) xs (tail xs)\n	215	606	haskell
import Data.Function\n	221	608	haskell
distinctBy :: (Eq a) => (b -> a) -> [b] -> [b]\ndistinctBy f = map head . groupBy ((==) `on` f)\n	7	609	haskell
collatz :: Integer -> Integer\ncollatz n | n < 1 = -1\ncollatz n = genericLength . takeWhile (/= 1) $ iterate step n\n  where step n = case n `divMod` 2 of\n                   (half, 0) -> half\n                   _ -> 3 * n + 1\n	206	610	haskell
collatz :: Integer -> Integer\ncollatz n | n < 1 = -1\ncollatz n = Data.List.genericLength . takeWhile (/= 1) $ iterate step n\n  where step n = case n `divMod` 2 of\n                   (half, 0) -> half\n                   _ -> 3 * n + 1\n	206	611	haskell
inOrder :: (Ord a) => [a] -> Bool\ninOrder xs = and $ zipWith (<=) xs (tail xs)\n	215	612	haskell
import qualified Data.Bits\n	225	614	haskell
bits :: (Data.Bits.Bits a) => a -> [Bool]\nbits 0 = []\nbits n = Data.Bits.testBit n 0 : bits (Data.Bits.shiftR n 1)\n	227	617	haskell
import qualified Data.Map\n	229	623	haskell
charSubst :: Map.Map Char Char -> String -> String\ncharSubst m = map (\\c -> maybe c id (Data.Map.lookup c m))\n	231	626	haskell
charSubst :: Data.Map.Map Char Char -> String -> String\ncharSubst m = map (\\c -> maybe c id (Data.Map.lookup c m))\n	231	628	haskell
def char_subst(m, s):\n    r = ""\n    for c in s:\n        if c in m:\n            r += m[c]\n        else:\n            r += c\n    return r\n	231	629	python
function selectText(element) {\n    var text = document.getElementById(element);\n    if ($.browser.msie) {\n        var range = document.body.createTextRange();\n        range.moveToElementText(text);\n        range.select();\n    } else if ($.browser.mozilla || $.browser.opera) {\n        var selection = window.getSelection();\n        var range = document.createRange();\n        range.selectNodeContents(text);\n        selection.removeAllRanges();\n        selection.addRange(range);\n    } else if ($.browser.safari) {\n        var selection = window.getSelection();\n        selection.setBaseAndExtent(text, 0, text, 1);\n    }\n}\n	234	632	javascript
function selectText(element) {\n    var text = element[0];\n    if ($.browser.msie) {\n        var range = document.body.createTextRange();\n        range.moveToElementText(text);\n        range.select();\n    } else if ($.browser.mozilla || $.browser.opera) {\n        var selection = window.getSelection();\n        var range = document.createRange();\n        range.selectNodeContents(text);\n        selection.removeAllRanges();\n        selection.addRange(range);\n    } else if ($.browser.safari) {\n        var selection = window.getSelection();\n        selection.setBaseAndExtent(text, 0, text, 1);\n    }\n}\n	234	634	javascript
function selectText(element) {\n    var text = element[0];\n    if ($.browser.msie) {\n        var range = document.body.createTextRange();\n        range.moveToElementText(text);\n        range.select();\n    } else if ($.browser.mozilla || $.browser.opera || $.browser.chrome) {\n        var selection = window.getSelection();\n        var range = document.createRange();\n        range.selectNodeContents(text);\n        selection.removeAllRanges();\n        selection.addRange(range);\n    } else if ($.browser.safari) {\n        var selection = window.getSelection();\n        selection.setBaseAndExtent(text, 0, text, 1);\n    }\n}\n	234	635	javascript
powerSet = foldr (\\x xss -> xss ++ map (x:) xss ) [[]]\n	306	832	haskell
function selectText(element) {\n    var text = element[0];\n    if ($.browser.msie) {\n        var range = document.body.createTextRange();\n        range.moveToElementText(text);\n        range.select();\n    } \n    else if ($.browser.safari) {\n        var selection = window.getSelection();\n        selection.setBaseAndExtent(text, 0, text, 1);\n    } \n    else { // mozilla, opera, chrome\n        var selection = window.getSelection();\n        var range = document.createRange();\n        range.selectNodeContents(text);\n        selection.removeAllRanges();\n        selection.addRange(range);\n    }\n}\n	234	637	javascript
def in_order(xs):\n    for i in range(1,len(xs)):\n        if xs[i] > xs[i+1]:\n            return False\n    return True\n	215	638	python
def lowest_factor(n):\n    if n == 0: return 0               # 0\n    if n == 1: return 1               # 1\n    if n % 2 == 0: return 2           # 2\n    if n % 3 == 0: return 3           # 3\n    if n < 0: n *= -1                 # allows for factoring negative integers\n    from math import sqrt             # import sqrt\n    r,d = int(sqrt(n))+1,6            # using properties of divisibility\n    while d < r:\n        if n % (d-1) == 0: return d-1 # d-1\n        if n % (d+1) == 0: return d+1 # d+1\n        d += 6\n    return n                          # n is prime\n	202	645	python
def is_prime(n):\n    if n < 2: return False              # all integers below two are not prime\n    if n < 4: return True               # if you check this, you can check far less\n    if n % 2 == 0 or n % 3 == 0:        # another time-saving step\n        return False\n    from math import sqrt               # not importing unless necessary, only what we need\n    r = int(sqrt(n)) + 1                # only check up to the square root\n    d = 6\n    while d < r:\n        if n % (d-1) == 0: return False # 6n-1\n        if n % (d+1) == 0: return False # 6n+1\n        d += 6\n    return True\n	187	648	python
def prime_factorization(n):\n    if n < 0: n *= -1           # allows the factorization of negatives\n    if n < 2: return []         # handles zero or one\n    while n % 2 == 0:           # finding all twos\n        yield 2\n        n /= 2\n    while n % 3 == 0:           # finding all threes\n        yield 3\n        n /= 3\n    if n == 1: return           # finishing here if possible\n    from math import sqrt       # importing sqrt\n    d,r = 6,int(sqrt(n))+1      # this part uses properties of divisibility\n    while n > r:\n        while n % (d-1) == 0:\n            yield (d-1)\n            n /= d-1\n        while n % (d+1) == 0:\n            yield (d+1)\n            n /= d+1\n        d += 6\n        r = int(sqrt(n))+1\n	200	651	python
def prime_factorization(n):\n    if n < 0: n *= -1           # allows the factorization of negatives\n    if n < 2: return            # handles zero or one\n    while n % 2 == 0:           # finding all twos\n        yield 2\n        n /= 2\n    while n % 3 == 0:           # finding all threes\n        yield 3\n        n /= 3\n    if n == 1: return           # finishing here if possible\n    from math import sqrt       # importing sqrt\n    d,r = 6,int(sqrt(n))+1      # this part uses properties of divisibility\n    while n > r:\n        while n % (d-1) == 0:\n            yield (d-1)\n            n /= d-1\n        while n % (d+1) == 0:\n            yield (d+1)\n            n /= d+1\n        d += 6\n        r = int(sqrt(n))+1\n	200	652	python
indices :: (Eq a) => a -> [a] -> [Int]\nindices x = go 0\n    where\n    go n (y:ys) | x == y    = n `seq` (n : go (n+1) ys)\n                | otherwise = n `seq` go (n+1) ys\n    go n [] = []\n	239	654	haskell
checkLangford :: [Int] -> Bool\ncheckLangford xs = even len && all checkix [1..len `div` 2]\n    where\n    checkix ix = case indices ix xs of\n                     [m,n] -> n-m == ix+1\n                     _     -> False\n    len = length xs\n	241	656	haskell
checkLangford :: [Int] -> Bool\ncheckLangford xs = even len && all checkix [1..len `div` 2]\n    where\n    checkix ix = case indices ix xs of\n                     [m,n] -> n-m == ix+1\n                     _     -> False\n    len = length xs\n	241	657	haskell
indices :: (Eq a) => a -> [a] -> [Int]\nindices x = map fst . filter ((x ==) . snd) . zip [0..]\n	239	662	haskell
maximum_by :: (Ord b) => (a -> b) -> [a] -> a\nmaximum_by f = Data.List.maximumBy (compare `Data.Function.on` f)\n	19	665	haskell
distinctBy :: (Eq a) => (b -> a) -> [b] -> [b]\ndistinctBy f = map head . Data.List.groupBy ((==) `Data.Function.on` f)\n	7	666	haskell
var horizontal = function() {\n    var row = elt('tr');\n    for (var i = 0; i < arguments.length; ++i) {\n        var cell = elt('td', {}, arguments[i]);\n        row.append(cell);\n    }\n    return elt('table', {}, row);\n};\n	38	669	javascript
var edit_description_field = function()\n{\n\tvar edit_comment_input = elt('input', { 'type': 'text', 'class': 'edit_description'});\n\tvar edit_description = horizontal(elt('span').text("Edit summary"), edit_comment_input);\n\tedit_description.val = edit_comment_input.val;\n\treturn edit_description;\n};\n	243	671	python
var edit_description_field = function()\n{\n\tvar edit_comment_input = elt('input', { 'type': 'text', 'class': 'edit_description'});\n\tvar edit_description = horizontal(elt('span').text("Edit summary"), edit_comment_input);\n\tedit_description.val = edit_comment_input.val;\n\treturn edit_description;\n};\n	243	672	python
var edit_description_field = function()\n{\n\tvar edit_comment_input = elt('input', { 'type': 'text', 'class': 'edit_description'});\n\tvar edit_description = horizontal(elt('span').text("Edit summary"), edit_comment_input);\n\tedit_description.val = edit_comment_input.val;\n\treturn edit_description;\n};\n	243	673	javascript
var edit_description_field = function()\n{\n\tvar edit_comment_input = elt('input', { 'type': 'text', 'class': 'edit_description'});\n\tvar edit_description = horizontal(elt('span').text("Edit summary"), edit_comment_input);\n\tedit_description.val = function(foo) {\n\t\treturn edit_comment_input.val.apply(edit_comment_input, arguments);\n\t};\n\treturn edit_description;\n};\n	243	675	javascript
var edit_description_field = function()\n{\n    var edit_comment_input = elt('input', { 'type': 'text', 'class': 'edit_description'});\n    var edit_description = horizontal(elt('span').text("Edit summary"), edit_comment_input);\n    edit_description.val = function(foo) {\n        return edit_comment_input.val.apply(edit_comment_input, arguments);\n    };\n    return edit_description;\n};\n	243	678	javascript
var delegate_method = function(obj, method) {\n    if (typeof method == 'string') {\n        method = obj[method];\n    }\n    return function() { method.apply(obj, arguments) }\n};\n	245	681	javascript
var delegate_method = function(obj, method) {\n    if (typeof method == 'string') {\n        method = obj[method];\n    }\n    return function() { return method.apply(obj, arguments) }\n};\n	245	683	javascript
var edit_description_field = function()\n{\n    var edit_comment_input = elt('input', { 'type': 'text', 'class': 'edit_description'});\n    var edit_description = horizontal(elt('span').text("Edit summary"), edit_comment_input);\n    edit_description.val = delegate_method(edit_comment_input, 'val');\n    return edit_description;\n};\n	243	684	javascript
var language_to_line_comment_map = {\n    python: '#',\n    javascript: '//',\n    haskell: '--',\n    c: '//',\n    csharp: '//',\n    java: '//', \n    ruby: '#'\n};\n	29	686	javascript
var tabs = function(ts) {\n    var tabtable = elt('div', { 'class': 'tabstrip' });\n    var content = elt('div', { 'class': 'content' });\n    var container = elt('div', { 'class': 'tabs' }, tabtable, content); \n    var cur;\n\n    for (var i in ts) {\n        (function() {\n            var t = ts[i];\n            var cb = function() {\n                if (!t.contentCache) {\n                    if (typeof t.content == "function") {\n                        t.contentCache = t.content();\n                    }\n                    else {\n                        t.contentCache = t.content;\n                    }\n                    content.append(t.contentCache);\n                }\n                if (cur) { \n                    cur.contentCache.addClass('hidden'); \n                    cur.tab.removeClass('selected');\n                }\n                cur = t;\n                t.contentCache.removeClass('hidden');\n                t.tab.addClass('selected');\n            };\n            t.tab = elt('span', { 'class': 'tab' }).text(t.label);\n            t.tab.click(cb);\n            tabtable.append(t.tab);\n            if (i == 0) cb();\n        })();\n    }\n    \n    return container;\n};\n	180	687	javascript
var simple_select = function(options) {\n    var ret = elt('select', {});\n    for (var i in options) {\n        ret.append(elt('option', {}).text(options[i]).val(options[i]));\n    }\n    return ret;\n};\n	247	691	javascript
var simple_select = function(options) {\n    var ret = elt('select', {});\n    for (var i in options) {\n        ret.append(elt('option', {}).text(options[i]).val(options[i]));\n    }\n    return ret;\n};\n	247	692	javascript
var lazy_highlight_element = function(prefix, suffix, element, language) {\n    if (language in sh_languages) {\n        if (sh_languages[language]) {\n            sh_highlightElement(element, sh_languages[language]);\n        }\n    }\n    else {\n        $.get(prefix + 'sh_' + language + suffix, function(reply) {\n            eval(reply);\n            sh_highlightElement(element, sh_languages[language]);\n        }).error(function() {\n            sh_languages[language] = null;\n        });\n    }\n};\n	249	697	javascript
var escape_html = function(html) {\n    return html.split('&').join('&amp;')\n               .split('<').join('&lt;')\n               .split('>').join('&gt;');\n};\n	251	704	javascript
var table_row = function() {\n    var tr = elt('tr');\n    for (var i in arguments) {\n        tr.append(elt('td', {}, arguments[i]));\n    }\n    return tr;\n};\n	253	709	javascript
var table_row = function() {\n    var tr = elt('tr');\n    for (var i in arguments) {\n        tr.append(elt('td', {}, arguments[i]));\n    }\n    return tr;\n};\n	253	713	javascript
var text_node = function(text) { return document.createTextNode(text) };\n	255	715	javascript
var tabs = function(ts) {\n    var tabtable = elt('div', { 'class': 'tabstrip' });\n    var content = elt('div', { 'class': 'content' });\n    var container = elt('div', { 'class': 'tabs' }, tabtable, content); \n    var cur;\n\n    for (var i in ts) {\n        (function() {\n            var t = ts[i];\n            var cb = function() {\n                if (!t.contentCache) {\n                    if (typeof t.content == "function") {\n                        t.contentCache = t.content();\n                    }\n                    else {\n                        t.contentCache = t.content;\n                    }\n                    content.append(t.contentCache);\n                }\n                if (cur) { \n                    cur.contentCache.hide();\n                    cur.tab.show();\n                    cur.tab.removeClass('selected');\n                }\n                cur = t;\n                t.contentCache.show();\n                t.tab.addClass('selected');\n            };\n            t.tab = elt('span', { 'class': 'tab' }).text(t.label);\n            t.tab.click(cb);\n            tabtable.append(t.tab);\n            if (i == 0) cb();\n        })();\n    }\n    \n    return container;\n};\n	180	718	javascript
var please_copy_me_on_click = function(element, text) {\n    var textarea = elt('textarea', {\n        'rows': linecount(text),\n        'readonly': 'readonly',\n        'wrap': 'off'\n    }).val(text);\n    textarea.hide();\n\n    element.click(function() {\n        element.hide();\n        textarea.show();\n        textarea.focus();\n        textarea.select();\n    });\n    textarea.blur(function() {\n        element.show();\n        textarea.hide();\n    });\n    return elt('div', {}, element, textarea);\n};\n	257	723	javascript
var please_copy_me_on_click = function(element, text) {\n    var textarea = elt('textarea', {\n        'rows': linecount(text),\n        'readonly': 'readonly',\n        'wrap': 'off'\n    }).val(text);\n    \n    var div = elt('div', {}, element, textarea);    \n    textarea.hide();\n\n    div.click(function() {\n        element.hide();\n        textarea.show();\n        textarea.focus();\n        textarea.select();\n    });\n    textarea.blur(function() {\n        element.show();\n        textarea.hide();\n    });\n    return div;\n};\n	257	727	javascript
var count_lines = function(text) {\n    return text.split(/\\n/).length;\n};\n	259	729	javascript
countLines :: String -> Int\ncountLines = length . lines\n	259	732	haskell
var please_copy_me_on_click = function(element, text) {\n    var textarea = elt('textarea', {\n        'rows': count_lines(text),\n        'readonly': 'readonly',\n        'wrap': 'off'\n    }).val(text);\n    \n    var div = elt('div', {}, element, textarea);    \n    textarea.hide();\n\n    div.click(function() {\n        element.hide();\n        textarea.show();\n        textarea.focus();\n        textarea.select();\n    });\n    textarea.blur(function() {\n        element.show();\n        textarea.hide();\n    });\n    return div;\n};\n	257	733	javascript
var make_pre = function(text) {\n    if ($.browser.msie) {\n        return $('<pre>' + escape_html(text) + '</pre>');\n    }\n    else {\n        return $('<pre></pre>').text(text);\n    }\n};\n	262	735	javascript
var make_pre = function(text) {\n    if ($.browser.msie) {\n        return $('<pre>' + escape_html(text) + '</pre>');\n    }\n    else {\n        return $('<pre></pre>').text(text);\n    }\n};\n	262	740	javascript
var toggle_button = function(text, text_alt, element, element_alt) {\n    var div = elt('div', {}, element);\n    if (typeof(element_alt) !== 'function') {\n        div.append(element_alt);\n    }\n    \n    var state = 'normal';\n    var btn = button(text, function() {\n        if (state == 'normal') {\n            if (typeof(element_alt) === 'function') {\n                element_alt = element_alt();\n                div.append(element_alt);\n            }\n            element.hide();\n            element_alt.show();\n            btn.text(text_alt);\n            state = 'alternate';\n        }\n        else {\n            element_alt.hide();\n            element.show();\n            btn.text(text);\n            state = 'normal';\n        }\n    });\n    return [div, btn];\n};\n	264	742	javascript
var toggle_button = function(text, text_alt, element, element_alt) {\n    var div = elt('div', {}, element);\n    if (typeof(element_alt) !== 'function') {\n        div.append(element_alt);\n    }\n    \n    var state = 'normal';\n    var btn = button(text, function() {\n        if (state == 'normal') {\n            if (typeof(element_alt) === 'function') {\n                element_alt = element_alt();\n                div.append(element_alt);\n            }\n            element.hide();\n            element_alt.show();\n            btn.text(text_alt);\n            state = 'alternate';\n        }\n        else {\n            element_alt.hide();\n            element.show();\n            btn.text(text);\n            state = 'normal';\n        }\n    });\n    return [div, btn];\n};\n	264	746	javascript
var iterate_adjacent = function(array, deflt, func) {\n    for (var i = 0; i < array.length; ++i) {\n\tvar current = array[i];\n    \tvar next = i + 1 < array.length ? array[i+1] : deflt;\n    \tfunc(current, next);\n    }\n};\n	266	751	python
var iterate_adjacent = function(array, deflt, func) {\n    for (var i = 0; i < array.length; ++i) {\n\tvar current = array[i];\n    \tvar next = i + 1 < array.length ? array[i+1] : deflt;\n    \tfunc(current, next);\n    }\n};\n	266	753	javascript
iterateAdjacent :: (Monad m) => [a] -> a -> (a -> a -> m ()) -> m ()\niterateAdjacent xs default f = sequence_ $ zipWith f xs (tail xs ++ [default])\n	266	756	haskell
var dynamic_link_element = function() {\n    return elt('a', { href: '#'});\n}\n	269	759	javascript
var dynamic_link = function(text, click) {\n    var link_element = dynamic_link_element();\n    var d_link = link_element.text(text);\n    d_link.click(function() { click(); return false; });\n    return d_link;\n};\n	166	761	javascript
var toggle_element = function(click_widget, text, text_alt, element, element_alt) {\n        var div = elt('div', {}, element);\n        if (typeof(element_alt) !== 'function') {\n            div.append(element_alt);\n        }\n        \n        var state = 'normal';\n        click_widget.text(text);\n        click_widget.click(function() {\n            if (state == 'normal') {\n                if (typeof(element_alt) === 'function') {\n                    element_alt = element_alt();\n                    div.append(element_alt);\n                }\n                element.hide();\n                element_alt.show();\n                click_widget.text(text_alt);\n                state = 'alternate';\n            }\n            else {\n                element_alt.hide();\n                element.show();\n                click_widget.text(text);\n                state = 'normal';\n            }\n        });\n        return [div, click_widget];\n    };\n	271	763	python
var timestamp_to_string = function(timestamp) {\n   var date_time = timestamp.split('T');\n   var date = date_time[0];\n   var time = date_time[1].split('.')[0];\n   return time + ", " + date;\n};\n	299	808	javascript
var table_row = function() {\n    var tr = elt('tr');\n    foreach(arguments, function(arg) {\n    \ttr.append(elt('td', {}, arg));\n    });\n    return tr;\n};\n	253	815	javascript
import Data.List (inits)\n	314	858	haskell
var toggle_element = function(click_widget, text, text_alt, element, element_alt) {\n        var div = elt('div', {}, element);\n        if (typeof(element_alt) !== 'function') {\n            div.append(element_alt);\n        }\n        \n        var state = 'normal';\n        click_widget.text(text);\n        click_widget.click(function() {\n            if (state == 'normal') {\n                if (typeof(element_alt) === 'function') {\n                    element_alt = element_alt();\n                    div.append(element_alt);\n                }\n                element.hide();\n                element_alt.show();\n                click_widget.text(text_alt);\n                state = 'alternate';\n            }\n            else {\n                element_alt.hide();\n                element.show();\n                click_widget.text(text);\n                state = 'normal';\n            }\n        });\n        return [div, click_widget];\n    };\n	271	764	javascript
var toggle_button = function(text, text_alt, element, element_alt) {\n        return toggle_element(elt('button'), text, text_alt, element, element_alt);\n    };\n	264	765	javascript
var toggle_button = function(text, text_alt, element, element_alt) {\n        return toggle_element(elt('button'), text, text_alt, element, element_alt);\n    };\n	264	766	javascript
var screen_offset = function(element) {\n    var element_offset = element.offset();\n    var offset_x = element_offset.left - window.pageXOffset;\n    var offset_y = element_offset.top - window.pageYOffset; \n    return { "left": offset_x, "top": offset_y };\n}\n	273	768	javascript
var screen_offset = function(element) {\n    var element_offset = element.offset();\n    var offset_x = element_offset.left - window.pageXOffset;\n    var offset_y = element_offset.top - window.pageYOffset; \n    return { "left": offset_x, "top": offset_y };\n};\n	275	770	javascript
var screen_offset = function(element) {\n    var element_offset = element.offset();\n    var offset_x = element_offset.left - window.pageXOffset;\n    var offset_y = element_offset.top - window.pageYOffset; \n    return { "left": offset_x, "top": offset_y };\n};\n	273	771	javascript
var preserving_screen_position = function(element, mods) {\n        var old_offset = screen_offset(element);\n        mods();\n        var new_offset = screen_offset(element);\n        \n        window.scrollBy(new_offset.left - old_offset.left, new_offset.top - old_offset.top);\n    };\n	275	772	javascript
var preserving_screen_position = function(element, mods) {\n    var old_offset = screen_offset(element);\n    mods();\n    var new_offset = screen_offset(element);\n        \n    window.scrollBy(new_offset.left - old_offset.left, new_offset.top - old_offset.top);\n};\n	275	773	javascript
var toggle_element = function(click_widget, text, text_alt, element, element_alt) {\n    var div = elt('div', {}, element);\n    if (typeof(element_alt) !== 'function') {\n        div.append(element_alt);\n        element_alt.hide();\n    }\n    \n    var state = 'normal';\n    click_widget.text(text);\n    click_widget.click(function() {\n        if (state == 'normal') {\n        \tif (typeof(element_alt) === 'function') {\n                element_alt = element_alt();\n                div.append(element_alt);\n                element_alt.hide();\n            }\n            \n        \tpreserving_screen_position(click_widget, function() {\n                element_alt.show();\n                element.hide();\n                click_widget.text(text_alt);\n        \t});\n\n            state = 'alternate';\n        }\n        else {\n        \tpreserving_screen_position(click_widget, function() {\n            \telement.show();\n                element_alt.hide();\n                click_widget.text(text);\n        \t});\n        \t\n            state = 'normal';\n        }\n        return false;\n    });\n    return [div, click_widget];\n};\n	271	774	javascript
var toggle_element = function(click_widget, text, text_alt, element, element_alt) {\n    var div = elt('div', {}, element);\n    if (typeof(element_alt) !== 'function') {\n        div.append(element_alt);\n        element_alt.hide();\n    }\n    \n    var state = 'normal';\n    click_widget.text(text);\n    click_widget.click(function() {\n        if (state == 'normal') {\n            if (typeof(element_alt) === 'function') {\n                element_alt = element_alt();\n                div.append(element_alt);\n                element_alt.hide();\n            }\n            \n            preserving_screen_position(click_widget, function() {\n                element_alt.show();\n                element.hide();\n                click_widget.text(text_alt);\n            });\n            \n            state = 'alternate';\n        }\n        else {\n            preserving_screen_position(click_widget, function() {\n                element.show();\n                element_alt.hide();\n                click_widget.text(text);\n            });\n            \n            state = 'normal';\n        }\n        return false;\n    });\n    return [div, click_widget];\n};\n	271	775	javascript
var toggle_button = function(text, text_alt, element, element_alt) {\n    return toggle_element(elt('button'), text, text_alt, element, element_alt);\n};\n	264	776	javascript
var foreach = function(array, body) {\n    for (var i = 0; i < array.length; ++i) {\n        body(array[i]);\n    }\n};\n	278	782	javascript
countEqual :: (Eq a) => [a] -> Int\ncountEqual xs = length $ filter (\\x -> count x > 1) xs\n    where\n    count x = length $ filter (x ==) xs\n	280	785	haskell
countEqual :: (Eq a) => [a] -> Int\ncountEqual xs = length $ filter (\\x -> count x > 1) xs\n    where\n    count x = length $ filter (x ==) xs\n	281	786	haskell
replaceNth :: Int -> a -> [a] -> [a]\nreplaceNth _ _ [] = []\nreplaceNth 0 x' (x:xs) = x':xs\nreplaceNth n x' (x:xs) = x : replaceNth (n-1) x' xs\n	284	791	haskell
def replace_nth(n,x,xs):\n    if n >= len(xs):\n        return []\n    else:\n        return xs[0:n] + [x] + xs[n:]\n	284	792	python
replaceNth :: Int -> a -> [a] -> [a]\nreplaceNth n x' = zipWith repl [0..]\n    where\n    repl n' x | n == n'   = x'\n              | otherwise = x\n	284	793	haskell
var timestamp_to_string = function(timestamp) {\n   var date_time = timestamp.split('T');\n   var date = date_time[0];\n   var time = date_time[1].split('.')[0];\n   return time + ", " + date;\n};\n	287	796	javascript
var timestamp_to_string = function(timestamp) {\n   var date_time = timestamp.split('T');\n   var date = date_time[0];\n   var time = date_time[1].split('.')[0];\n   return time + ", " + date;\n};\n	289	798	javascript
var timestamp_to_string = function(timestamp) {\n   var date_time = timestamp.split('T');\n   var date = date_time[0];\n   var time = date_time[1].split('.')[0];\n   return time + ", " + date;\n};\n	291	800	javascript
var timestamp_to_string = function(timestamp) {\n   var date_time = timestamp.split('T');\n   var date = date_time[0];\n   var time = date_time[1].split('.')[0];\n   return time + ", " + date;\n};\n	293	802	javascript
var timestamp_to_string = function(timestamp) {\n   var date_time = timestamp.split('T');\n   var date = date_time[0];\n   var time = date_time[1].split('.')[0];\n   return time + ", " + date;\n};\n	295	804	javascript
var timestamp_to_string = function(timestamp) {\n   var date_time = timestamp.split('T');\n   var date = date_time[0];\n   var time = date_time[1].split('.')[0];\n   return time + ", " + date;\n};\n	297	806	javascript
var table_row = function() {\n    var tr = elt('tr');\n    foreach(arguments, function(arg) {\n    \ttr.append(elt('td', {}, arg));\n    });\n    return tr;\n};\n	253	816	javascript
var table_row = function() {\n    var tr = elt('tr');\n    foreach(arguments, function(arg) {\n    \ttr.append(elt('td', {}, arg));\n    });\n    return tr;\n};\n	253	817	javascript
var table_row = function() {\n    var tr = elt('tr');\n    foreach(arguments, function(arg) {\n    \ttr.append(elt('td', {}, arg));\n    });\n    return tr;\n};\n	253	818	javascript
var toggle_element = function(click_widget, text, text_alt, element, element_alt) {\n    var div = elt('div', {}, element);\n    if (typeof(element_alt) !== 'function') {\n        div.append(element_alt);\n        element_alt.hide();\n    }\n    \n    var state = 'normal';\n    click_widget.text(text);\n    click_widget.click(function() {\n        if (state == 'normal') {\n        \tif (typeof(element_alt) === 'function') {\n                element_alt = element_alt();\n                div.append(element_alt);\n                element_alt.hide();\n            }\n            \n        \tpreserving_screen_position(click_widget, function() {\n             element_alt.show();\n             element.hide();\n             click_widget.text(text_alt);\n        \t});\n\n            state = 'alternate';\n        }\n        else {\n        \tpreserving_screen_position(click_widget, function() {\n         \telement.show();\n             element_alt.hide();\n             click_widget.text(text);\n        \t});\n        \n            state = 'normal';\n        }\n        return false;\n    });\n    return [div, click_widget];\n};\n	271	819	javascript
var table_row = function() {\n    var tr = elt('tr');\n    foreach(arguments, function(arg) {\n        tr.append(elt('td', {}, arg));\n    });\n    return tr;\n};\n	253	820	javascript
var toggle_element = function(click_widget, text, text_alt, element, element_alt) {\n    var div = elt('div', {}, element);\n    if (typeof(element_alt) !== 'function') {\n        div.append(element_alt);\n        element_alt.hide();\n    }\n    \n    var state = 'normal';\n    click_widget.text(text);\n    click_widget.click(function() {\n        if (state == 'normal') {\n            if (typeof(element_alt) === 'function') {\n                element_alt = element_alt();\n                div.append(element_alt);\n                element_alt.hide();\n            }\n            \n            preserving_screen_position(click_widget, function() {\n                element_alt.show();\n                element.hide();\n                click_widget.text(text_alt);\n            });\n\n            state = 'alternate';\n        }\n        else {\n            preserving_screen_position(click_widget, function() {\n                element.show();\n                element_alt.hide();\n                click_widget.text(text);\n            });\n        \n            state = 'normal';\n        }\n        return false;\n    });\n    return [div, click_widget];\n};\n	271	821	javascript
var iterate_adjacent = function(array, deflt, func) {\n    for (var i = 0; i < array.length; ++i) {\n    var current = array[i];\n        var next = i + 1 < array.length ? array[i+1] : deflt;\n        func(current, next);\n    }\n};\n	266	822	python
var make_auto_complete_kv = function(element, generate_options, key_to_val, select) {\n    var choice_to_val = {};\n    element.autocomplete({\n    \t'source': function(request, response_func) {\n            if (request) {\n            \tgenerate_options(request.term, function(results) {\n                    var results_formatted = [];\n                    foreach(results, function(result) {\n                        var choice = key_to_val(result);\n                        results_formatted.push(choice);\n                        choice_to_val[choice] = result;\n                    });\n                    response_func(results_formatted);\n                });\n            }\n        },\n        'select': function(event, ui) {\n            var choice = ui.item.value;\n            if (choice in choice_to_val) {\n                select(choice_to_val[choice]);\n            }\n        },\n        'autoFocus': true});\n    return element;\n};\n	302	825	javascript
var iterate_adjacent = function(array, deflt, func) {\n    for (var i = 0; i < array.length; ++i) {\n    var current = array[i];\n        var next = i + 1 < array.length ? array[i+1] : deflt;\n        func(current, next);\n    }\n};\n	266	826	javascript
-- Code adapted from http://yubinkim.com/?p=87\n\npowerSet = foldr (\\x xss -> xss ++ map (x:) xss ) [[]]\n	306	834	haskell
powerSet :: [a] -> [[a]]\npowerSet = foldr (\\x xss -> xss ++ map (x:) xss) [[]]\n	306	839	haskell
var make_auto_complete = function(options) {\n    var generate_options = options['generate_options'];\n    var format = options['format'] || function(x) { return x };\n    var select = options['select'] || function() { };\n    var stylize = options['stylize'] || function(uimenu) { uimenu.width(element.width()); };\n\t\n    var choice_to_val = {};\n    var span = elt('span');\n    var element = elt('input').autocomplete({\n    \t'source': function(request, response_func) {\n            if (request) {\n            \tgenerate_options(request.term, function(results) {\n                    var results_formatted = [];\n                    foreach(results, function(result) {\n                        var choice = format(result);\n                        results_formatted.push(choice);\n                        choice_to_val[choice] = result;\n                    });\n                    response_func(results_formatted);\n                });\n            }\n        },\n        'select': function(event, ui) {\n            var choice = ui.item.value;\n            if (choice in choice_to_val) {\n                select(choice_to_val[choice]);\n            }\n        },\n        'appendTo': span,\n        'open': function() {\n        \tstylize(span.find('.ui-menu'));\n        }});\n    return element.add(span);\n};\n	302	843	javascript
var on_enter = function(element, callback) {\n    return element.keypress(function(e){\n        if(e.which == 13) {\n            callback();\n        }\n    });\n};\n	308	845	javascript
var make_auto_complete = function(options) {\n    var generate_options = options['generate_options'];\n    var format = options['format'] || function(x) { return x };\n    var select = options['select'] || function() { };\n    var stylize = options['stylize'] || function(uimenu) { uimenu.width(element.width()); };\n\t\n    var choice_to_val = {};\n    var span = elt('span');\n    var element = elt('input').autocomplete({\n    \t'source': function(request, response_func) {\n            if (request) {\n            \tgenerate_options(request.term, function(results) {\n                    var results_formatted = [];\n                    foreach(results, function(result) {\n                        var choice = format(result);\n                        results_formatted.push(choice);\n                        choice_to_val[choice] = result;\n                    });\n                    response_func(results_formatted);\n                });\n            }\n        },\n        'select': function(event, ui) {\n            var choice = ui.item.value;\n            if (choice in choice_to_val) {\n                select(choice_to_val[choice]);\n            }\n        },\n        'appendTo': span,\n        'open': function() {\n            stylize(span.find('.ui-menu'));\n        }\n    });\n    return element.add(span);\n};\n	302	846	javascript
import Data.List (tails)\n	316	862	haskell
import qualified Data.Function\n	221	957	haskell
shallowCopy = id  -- lol\n	362	999	haskell
var toggle_element = function(click_widget, text, text_alt, element, element_alt) {\n    var div = elt('div', {}, element);\n    if (typeof(element_alt) !== 'function') {\n        div.append(element_alt);\n        element_alt.hide();\n    }\n    \n    var state = 'normal';\n    click_widget.text(text);\n    click_widget.click(function() {\n        if (state == 'normal') {\n            if (typeof(element_alt) === 'function') {\n                element_alt = element_alt();\n                div.append(element_alt);\n                element_alt.hide();\n            }\n            \n            preserving_screen_position(click_widget, function() {\n                element_alt.show();\n                element.hide();\n                click_widget.text(text_alt);\n            });\n\n            state = 'alternate';\n        }\n        else {\n            preserving_screen_position(click_widget, function() {\n                element.show();\n                element_alt.hide();\n                click_widget.text(text);\n            });\n        \n            state = 'normal';\n        }\n        return false;\n    });\n    return [div, click_widget];\n};\n	271	847	javascript
pairs xs ys = [(xs !! k, ys !! (n-k)) | n <- [0..], k <- [0..n]]\n	310	849	haskell
diagonal :: [[a]] -> [a]\ndiagonal = concat . stripe\n    where\n    stripe [] = []\n    stripe ([]:xss) = stripe xss\n    stripe ((x:xs):xss) = [x] : zipCons xs (stripe xss)\n\n    zipCons [] ys = ys\n    zipCons xs [] = map (:[]) xs\n    zipCons (x:xs) (y:ys) = (x:y) : zipCons xs ys\n	312	851	haskell
pairs :: [a] -> [b] -> [(a,b)]\npairs xs ys = diagonal [ [ (x,y) | x <- xs ] | y <- ys ]\n	310	854	haskell
partitions :: [a] -> [([a],[a])]\npartitions xs = zip (inits xs) (tails xs)\n	318	865	haskell
var unique_id = function() {\n    var id = 0;\n    return function() { return id++ };\n}();\n	320	868	javascript
var for_kv = function(object, body) {\n    for (var i in object) {\n        if (object.hasOwnProperty(i)) {\n            body(i, object[i]);\n        }\n    }\n};\n	322	873	javascript
var for_kv = function(object, body) {\n    for (var k in object) {\n        if (object.hasOwnProperty(k)) {\n            body(k, object[k]);\n        }\n    }\n};\n	322	875	javascript
var repeat_string = function(string, times) {\n    var r = "";\n    for (var i = 0; i < times; i++) {\n        r += string;\n    }\n    return r;\n};\n	324	878	javascript
def repeat_string(string, times):\n    return string * times\n	324	882	python
var terminal_path = function(root, children) {\n    var traverse = function(x) {\n        var r = [];\n        while (x) {\n            r.push(x.node);\n            x = x.pred;\n        }\n        return r.reverse();\n    };\n    \n    var queue = [{node: root, pred: null}];\n    while (queue.length > 0) {\n        var e = queue.splice(0,1)[0];\n        var ch = children(e.node);\n        if (ch.length == 0) {\n            return traverse(e);\n        }\n        else {\n            foreach(ch, function(c) { queue.push({ node: c, pred: e }) });\n        }\n    }\n    throw "How ever did we get here?";\n};\n	327	884	javascript
var terminal_path = function(root, children) {\n    var traverse = function(x) {\n        var r = [];\n        while (x) {\n            r.push(x.node);\n            x = x.pred;\n        }\n        return r.reverse();\n    };\n    \n    var queue = [{node: root, pred: null}];\n    while (queue.length > 0) {\n        var e = queue.splice(0,1)[0];\n        var ch = children(e.node);\n        if (ch.length == 0) {\n            return traverse(e);\n        }\n        else {\n            foreach(ch, function(c) { queue.push({ node: c, pred: e }) });\n        }\n    }\n    throw "How ever did we get here?";\n};\n	327	887	javascript
def in_order(xs):\n    for i in range(1,len(xs)):\n        if xs[i-1] > xs[i]:\n            return False\n    return True\n	215	890	python
var object = function(methods) {\n    var constr = methods['init'] || function() {};\n    for_kv(methods, function(k,v) {\n        constr.prototype[k] = v;\n    });\n    return constr;\n};\n	330	893	javascript
var thunk = function(fn) {\n    var cache;\n    var cacheset = false;\n    return function() {\n        if (!cacheset) { cache = fn(); cacheset = true }\n        return cache;\n    };\n};\n	332	899	javascript
repeat_string string times = concat $ replicate times string\n	324	903	haskell
var formatCurrencyUSD = function(num) {\n\tnum = num.toString().replace(/\\$|\\,/g, "");\n\tif (isNaN(num)) num = "0";\n\tvar sign = (num == (num = Math.abs(num)));\n\tnum = Math.floor(num * 100 + 0.50000000001);\n\tvar cents = num % 100;\n\tnum = Math.floor(num / 100).toString();\n\tif (cents < 10) cents = "0" + cents;\n\tfor (var i = 0; i < Math.floor((num.length - (1 + i)) / 3); i++) {\n\t\tnum = num.substring(0, num.length - (4 * i + 3)) + ',' + num.substring(num.length - (4 * i + 3));\n\t}\n\treturn (((sign) ? '' : '-') + '$' + num + '.' + cents);\n};\n	335	906	javascript
language_to_line_comment_map = {\n    'python': '#',\n    'javascript': '//',\n    'haskell': '--',\n    'c': '//',\n    'csharp': '//',\n    'ruby': '#',\n    'php': '//',\n}\n	29	911	python
var language_to_line_comment_map = {\n    python: '#',\n    javascript: '//',\n    haskell: '--',\n    c: '//',\n    csharp: '//',\n    java: '//', \n    ruby: '#',\n    php: '//'\n};\n	29	912	javascript
var readCurrencyUSD = function(formattedNum) {\n\tvar num = formattedNum.toString().replace(/\\$|\\,/g, "");\n\tif (isNaN(num)) num = "0";\n\treturn num;\n};\n	337	914	javascript
maximumBy :: (Ord b) => (a -> b) -> [a] -> a\nmaximumBy f = Data.List.maximumBy (compare `Data.Function.on` f)\n	19	921	haskell
var split_lines = function(str) {\n    return str.split(/\\n/);\n};\n	340	924	javascript
var zip = function(xs, ys) {\n   var result = [];\n   var len = min(xs.length, ys.length);\n   for (var i = 0; i < len; i++) {\n       result.push([xs[i], ys[i]]);\n   }\n   return result;\n};\n	343	927	javascript
var zip = function(xs, ys) {\n   var result = [];\n   var len = min(xs.length, ys.length);\n   for (var i = 0; i < len; i++) {\n       result.push([xs[i], ys[i]]);\n   }\n   return result;\n};\n	343	928	javascript
var sub_dictionary = function(dicta, dictb) {\n    for (var i in dicta) {\n        if (dicta.hasOwnProperty(i)) {\n            if (!(i in dictb && dictb[i] === dicta[i])) { \n                return false;\n            }\n        }\n    }\n    return true;\n};\n	345	931	javascript
var sub_dictionary = function(dicta, dictb) {\n    for (var i in dicta) {\n        if (dicta.hasOwnProperty(i)) {\n            if (!(i in dictb && dictb[i] === dicta[i])) { \n                return false;\n            }\n        }\n    }\n    return true;\n};\n	345	933	javascript
var unzip_kv = function(kv) {\n    var r = [];\n    for (var i = 0; i < kv.length; i++) {\n        r[kv[i][0]] = kv[i][1];\n    }\n    return r;\n};\n	347	937	javascript
var unzip_kv = function(kv) {\n    var r = {};\n    for (var i = 0; i < kv.length; i++) {\n        r[kv[i][0]] = kv[i][1];\n    }\n    return r;\n};\n	347	938	javascript
var parallel_arrays_to_dictionary = function(keys, values) {\n    return unzip_kv(zip(keys, values));\n};\n	349	941	javascript
def instance_methods(obj):\n    return dict((m,getattr(obj,m)) for m in dir(obj) \n                                   if inspect.ismethod(getattr(obj,m)))\n	94	959	python
def dict_inverse_multi(dictionary):\n    return dict( (value, set( key for key in dictionary.keys()\n                                  if dictionary[key] == value ))\n                 for value in dictionary.values())\n	46	960	python
def dict_inverse_multi(dictionary):\n    return dict( (value, set( key for key in dictionary.keys()\n                                  if dictionary[key] == value ) )\n                 for value in dictionary.values() )\n	46	961	python
def wrap_fields(wrapper, dictionary):\n    return dict( (k, (wrapper[k](v) if k in wrapper else v))\n                 for k, v in dictionary.items() )\n	42	962	python
grayCode :: Int -> [[Bool]]\ngrayCode 0 = [[]]\ngrayCode n = map (False:) g ++ map (True:) (reverse g)\n    where\n    g = grayCode (n-1)\n	351	969	haskell
var unique = function(l) {\n    var r = [];\n    var seen = {};\n    for (var i = 0; i < l.length; i++) {\n        if (!(l[i] in seen)) {\n            r.push(l[i]);\n            seen[l[i]] = true;\n        }\n    }\n    return r; \n};\n	190	972	javascript
unique :: (Ord a) => [a] -> [a]\nunique = Data.Set.toList . Data.Set.fromList\n	190	973	haskell
var floating_point_regexp = /^[-+]?[0-9]*\\.?[0-9]+([eE][-+]?[0-9]+)?/;\n	354	975	javascript
var escape_for_regexp = function(text) {\n    return text.replace(/[^\\w]/g, function(x) { '\\\\' + x });\n};\n	356	978	javascript
def merge(dict1, dict2):\n    r = dict1.copy()\n    r.update(dict2)\n    return r\n	153	981	python
var escape_for_regexp = function(text) {\n    return text.replace(/[][\\\\^$*+?{}\\.()|]/g, function(x) { '\\\\' + x });\n};\n	356	983	javascript
var escape_for_regexp = function(text) {\n    return text.replace(/[\\]\\[\\\\^$*+?{}\\.()|]/g, function(x) { return '\\\\' + x });\n};\n	356	986	javascript
var trace = function() {\n    console.log.apply(console, arguments);\n    return arguments[arguments.length-1];\n};\n	358	988	javascript
var reduce_args_left = function(f) {\n    return function() {\n        var r = arguments[0];\n        for (var i = 1; i < arguments.length; i++) {\n            r = f(r, arguments[i]);\n        }\n        return r;\n    };\n};\n	360	993	javascript
var shallow_copy = function(obj) {\n    var copy = new Object();\n    for (var key in obj) {\n        copy[key] = obj[key];\n    }\n    return copy;\n};\n	362	998	javascript
var object = function(methods) {\n    var constr = methods['init'] || function() {};\n    for_kv(methods, function(k,v) {\n        constr.prototype[k] = v;\n    });\n    return constr;\n};\n	330	1000	javascript
var replace = function(e, replacement, xs) {\n    var r = [];\n    foreach(xs, function(x) {\n        if (e === x) {\n            r.push(replacement);\n        }\n        else {\n            r.push(x);\n        }\n    });\n    return r;\n};\n	365	1002	javascript
var replace = function(e, replacement, xs) {\n    var r = [];\n    foreach(xs, function(x) {\n        if (e === x) {\n            r.push(replacement);\n        }\n        else {\n            r.push(x);\n        }\n    });\n    return r;\n};\n	365	1006	javascript
var arguments_to_array = function(argobj) {\n    return Array.prototype.slice.call(argobj);\n};\n	367	1008	javascript
var flatten = function(AoA) {\n    return Array.prototype.concat.apply([], AoA);\n};\n	369	1013	javascript
import qualified Data.MeldableHeap\n	371	1020	haskell
data HeapItem prio item = HeapItem prio item\n\ninstance (Eq prio) => Eq (HeapItem prio item) where\n    HeapItem p _ == HeapItem p' _ = p == p'\n\ninstance (Ord prio) => Ord (HeapItem prio item) where\n    HeapItem p _ `compare` HeapItem p' _ = p `compare` p'\n\nenumIncreasing :: (Ord a, Ord b) => (a -> b) -> (a -> [a]) -> a -> [(a,b)]\nenumIncreasing measure successors x0 = go heap0 Data.Set.empty\n    where\n    heap0 = heapInsert x0 Data.MeldableHeap.empty\n    go heap seen\n        | Just (HeapItem y x, heap') <- Data.MeldableHeap.extractMin heap =\n            if x `Data.Set.member` seen\n                then go heap' seen\n                else (x,y) : go (foldr heapInsert heap' (successors x))\n                                (Data.Set.insert x seen)\n        | otherwise = []\n    heapInsert x = Data.MeldableHeap.insert (HeapItem (measure x) x)\n	373	1024	haskell
baseDigits :: (Integral a) => a -> a -> [a]\nbaseDigits base 0 = []\nbaseDigits base n = r : baseDigits base q\n    where (q,r) = n `divMod` base\n	375	1029	haskell
var regexp_tokenizer = function(tokens) { \n    return function(str) {\n        var bestMatch = null;\n        var bestFunc = null; \n        for_kv(tokens, function(k,v) {\n            var m = new RegExp('^' + k)(str);\n            if (m && (!bestMatch || m[0].length > bestMatch[0].length)) {\n                bestMatch = m;\n                bestFunc = v;\n            }\n        });\n\n        // don't match the whole string in case we are in the middle of typing a token\n        // we use \\0 to mean "eof" so this will pass.\n        if (bestFunc && bestMatch[0].length < str.length) {\n            return [bestFunc(bestMatch), str.slice(bestMatch[0].length)];\n        }\n        else {\n            return null;\n        }\n    }\n};\n	377	1032	javascript
var regexp_tokenizer = function(tokens) { \n    return function(str) {\n        var bestMatch = null;\n        var bestFunc = null; \n        for_kv(tokens, function(k,v) {\n            var m = new RegExp('^' + k)(str);\n            if (m && (!bestMatch || m[0].length > bestMatch[0].length)) {\n                bestMatch = m;\n                bestFunc = v;\n            }\n        });\n\n        // don't match the whole string in case we are in the middle of typing a token\n        // we use \\0 to mean "eof" so this will pass.\n        if (bestFunc && bestMatch[0].length < str.length) {\n            return [bestFunc(bestMatch), str.slice(bestMatch[0].length)];\n        }\n        else {\n            return null;\n        }\n    }\n};\n	377	1033	javascript
var multi_tokenizer = function(tokenizer) {\n    return function(str) {\n        var tokresult = tokenizer(str);\n        var ret = [];\n        while (tokresult) {\n            ret.push(tokresult[0]);\n            str = tokresult[1];\n            tokresult = tokenizer(str);\n        }\n        return [ret, str];\n    };\n};\n	380	1040	javascript
var map_tokenizer = function(f, tokenizer) {\n    return function(str) {\n        var tokresult = tokenizer(str);\n        if (tokresult) {\n            return [f(tokresult[0]), tokresult[1]];\n        }\n        else {\n            return null;\n        }\n    };\n};\n	382	1044	javascript
var extend = function(target, src) {\n    for (var k in src) {\n        target[k] = src[k];\n    }\n};\n	384	1051	javascript
var extend = function(target, src) {\n    for (var k in src) {\n        target[k] = src[k];\n    }\n    return target;\n};\n	384	1052	javascript
var range = function(left, right) {\n    var r = [];\n    for (var i = left; i < right; i++) {\n        r.push(i);\n    }\n    return r;\n};\n	386	1055	javascript
var splice_replace = function(e, replacements, xs) {\n    var r = [];\n    foreach(xs, function(x) {\n        if (x === e) {\n            r.push.apply(r, replacements);\n        }\n        else {\n            r.push(x);\n        }\n    });\n    return r;\n};\n	388	1060	javascript
var splice_replace = function(e, replacements, xs) {\n    var r = [];\n    foreach(xs, function(x) {\n        if (x === e) {\n            r.push.apply(r, replacements);\n        }\n        else {\n            r.push(x);\n        }\n    });\n    return r;\n};\n	388	1064	javascript
var choice_tokenizer = function(tokenizers) {\n    return function(str) {\n        for (var i = 0; i < tokenizers.length; ++i) {\n            var tokresult = tokenizers[i](str);\n            if (tokresult) {\n                return tokresult;\n            }\n        }\n        return null;\n    };\n};\n	390	1068	javascript
var wrap_fields = function(wrapper, dict) {\n    var ret = {};\n    for_kv(dict, function(k,v) {\n        ret[k] = k in wrapper ? wrapper[k](v) : v;\n    });\n    return ret;\n};\n	42	1073	javascript
var string_tokenizer = function(str, value) {\n    var d = {};\n    d[escape_for_regexp(str)] = function() { return value; }\n    return regexp_tokenizer(d);\n};\n	393	1075	javascript
var string_tokenizer = function(str, value) {\n    var d = {};\n    d[escape_for_regexp(str)] = function() { return value; }\n    return regexp_tokenizer(d);\n};\n	393	1078	javascript
var string_tokenizer = function(str, func) {\n    var d = {};\n    d[escape_for_regexp(str)] = func;\n    return regexp_tokenizer(d);\n};\n	393	1081	javascript
splice_replace :: Ord a => a -> [a] -> [a] -> [a] \nsplice_replace e rep = ((\\x -> if x == e then rep else [x]) =<<)\n	388	1083	haskell
splice_replace :: Eq a => a -> [a] -> [a] -> [a] \nsplice_replace e rep = ((\\x -> if x == e then rep else [x]) =<<)\n	388	1084	haskell
indent_by :: String -> String -> String\nindent_by indent = unlines . map (indent ++) . lines\n	27	1086	haskell
reduce_args_left :: (a -> a -> a) -> [a] -> a\nreduce_args_left = foldl1\n	360	1087	haskell
language_to_line_comment_map = {\n    'python': '#',\n    'javascript': '//',\n    'haskell': '--',\n    'c': '//',\n    'cpp': '//',\n    'csharp': '//',\n    'ruby': '#',\n    'php': '//',\n}\n	29	1088	python
var language_to_line_comment_map = {\n    python: '#',\n    javascript: '//',\n    haskell: '--',\n    c: '//',\n    cpp: '//',\n    csharp: '//',\n    java: '//', \n    ruby: '#',\n    php: '//'\n};\n	29	1089	javascript
var language_to_codemirror_mode = {\n    "python": { url: 'http://codemirror.net/mode/python/python.js', mime: 'text/x-python' },\n    "javascript": { url: 'http://codemirror.net/mode/javascript/javascript.js', mime: 'text/javascript' },\n    "haskell": { url: 'http://codemirror.net/mode/haskell/haskell.js', mime: 'text/x-haskell' },\n    "c": { url: 'http://codemirror.net/mode/clike/clike.js', mime: 'text/x-csrc' },\n    "cpp": { url: 'http://codemirror.net/mode/clike/clike.js', mime: 'text/x-c++src' }, \n    "csharp": { url: 'http://codecatalog.net/static/codemirror/mode/clike/clike.js', mime: 'text/x-csharp' },\n    "java": { url: 'http://codemirror.net/mode/clike/clike.js', mime: 'text/x-java' }\n};\n	398	1091	javascript
var download_script = function(script, callback) {\n    var head = document.getElementsByTagName('head')[0];\n    var script = document.createElement('script');\n    script.type = 'text/javascript';\n    script.onreadystatechange = function () {\n        if (this.readyState == 'complete') callback();\n    };\n    script.onload = callback;\n    script.src = script;\n    head.appendChild(script);\n};\n	400	1093	javascript
import datetime\n	418	1149	python
import time\n	422	1154	python
var download_script = function(url, callback) {\n    var head = document.getElementsByTagName('head')[0];\n    var script = document.createElement('script');\n    script.type = 'text/javascript';\n    script.onreadystatechange = function () {\n        if (this.readyState == 'complete') callback();\n    };\n    script.onload = callback;\n    script.src = script;\n    head.appendChild(script);\n};\n	400	1094	javascript
var download_script = function(url, callback) {\n    var head = document.getElementsByTagName('head')[0];\n    var script = document.createElement('script');\n    script.type = 'text/javascript';\n    script.onreadystatechange = function () {\n        if (this.readyState == 'complete') callback();\n    };\n    script.onload = callback;\n    script.src = url;\n    head.appendChild(script);\n};\n	400	1095	javascript
var download_stylesheet = function(url) {\n    $('head').append(elt('link', {rel: 'stylesheet', href: url}));\n};\n	402	1097	javascript
var download_stylesheet = function(url) {\n    $('head').append(elt('link', {rel: 'stylesheet', href: url}));\n};\n	402	1098	javascript
var download_script = function(url, callback) {\n    var head = document.getElementsByTagName('head')[0];\n    var script = document.createElement('script');\n    script.type = 'text/javascript';\n    \n    var called = false;\n    script.onreadystatechange = function () {\n        if ((this.readyState == 'loaded' || this.readyState == 'completed') && callback && !called) {\n            called = true;\n            callback();\n        }\n    };\n    $(script).load(callback);\n    script.src = url;\n    head.appendChild(script);\n};\n	400	1099	javascript
var download_script = function(url, callback) {\n    var head = document.getElementsByTagName('head')[0];\n    var script = document.createElement('script');\n    script.type = 'text/javascript';\n    \n    // IE support\n    var called = false;\n    script.onreadystatechange = function () {\n        if ((this.readyState == 'loaded' || this.readyState == 'completed') && callback && !called) {\n            called = true;\n            callback();\n        }\n    };\n\n    // Gecko/V8\n    $(script).load(callback);\n    \n    script.src = url;\n    head.appendChild(script);\n};\n	400	1100	javascript
var download_script = function(url, callback) {\n    var head = document.getElementsByTagName('head')[0];\n    var script = document.createElement('script');\n    script.type = 'text/javascript';\n    \n    // IE Support\n    var called = false;\n    var guarded_callback = function() {\n        if (!called) {\n            called = true;\n            if (callback) callback();\n        }\n    };\n\n    script.onreadystatechange = function () {\n        if (script.readyState == 'loaded' || script.readyState == 'complete') {\n            guarded_callback();\n        }\n    };\n    \n    // Gecko/V8 support\n    $(script).load(guarded_callback);\n\n    script.src = url;\n    \n    head.appendChild(script);\n};\n	400	1101	javascript
var download_stylesheet = function(url) {\n    $('head').append(elt('link', {rel: 'stylesheet', href: url, type: 'text/css'}));\n};\n	402	1103	javascript
merge :: (Ord a) => [[a]] -> [a]\nmerge [] = []\nmerge ([]:xss) = merge xss\nmerge ((x:xs):xss) = x : merge (insertBy compareHead xs xss)\n    where\n    compareHead [] [] = EQ\n    compareHead [] _  = LT\n    compareHead _  [] = GT\n    compareHead (x:xs) (y:ys) = compare x y\n	405	1106	haskell
merge :: (Ord a) => [[a]] -> [a]\nmerge [] = []\nmerge ([]:xss) = merge xss\nmerge ((x:xs):xss) = x : merge (Data.List.insertBy compareHead xs xss)\n    where\n    compareHead [] [] = EQ\n    compareHead [] _  = LT\n    compareHead _  [] = GT\n    compareHead (x:xs) (y:ys) = compare x y\n	405	1109	haskell
from django.db import models\n\nclass EnumField(models.Field):\n    def __init__(self, *args, **kwargs):\n        self.values = kwargs.pop('values')\n        kwargs['choices'] = [(v, v) for v in self.values]\n        kwargs['default'] = self.values[0]\n        super(EnumField, self).__init__(*args, **kwargs)\n\n    def db_type(self):\n        return "enum({0})".format( ','.join("'%s'" % v for v in self.values) )\n	407	1112	python
class EnumField(models.IntegerField):\n    description = "One of a finite set of non-integer values"\n    \n    __metaclass__ = models.SubfieldBase\n\n    def __init__(self, *args, **kwargs):\n        self.values = kwargs.pop('values')\n        choices = dict(zip(range(len(self.values)), self.values))\n        self.inverse = dict_inverse(choices)\n        kwargs['choices'] = choices\n        super(EnumField, self).__init__(*args, **kwargs)\n    \n    def to_python(self, value):\n        if isinstance(value, int):\n            return self.values[value]\n        else:\n            return value\n\n    def get_prep_value(self, value):\n        return self.inverse[value]\n	409	1117	python
from django.db import models\n	411	1124	python
class EnumField(models.IntegerField):\n    description = "One of a finite set of non-integer values"\n    \n    __metaclass__ = models.SubfieldBase\n\n    def __init__(self, *args, **kwargs):\n        self.values = kwargs.pop('values')\n        choices = dict(zip(range(len(self.values)), self.values))\n        self.inverse = dict_inverse(choices)\n        kwargs['choices'] = choices\n        super(EnumField, self).__init__(*args, **kwargs)\n    \n    def to_python(self, value):\n        if isinstance(value, int):\n            return self.values[value]\n        else:\n            return value\n\n    def get_prep_value(self, value):\n        return self.inverse[value]\n	409	1125	python
class EnumField(models.IntegerField):\n    description = "One of a finite set of non-integer values"\n    \n    __metaclass__ = models.SubfieldBase\n\n    def __init__(self, *args, **kwargs):\n        self.values = kwargs.pop('values')\n        choices = dict(zip(range(len(self.values)), self.values))\n        self.inverse = dict_inverse(choices)\n        kwargs['choices'] = choices\n        super(EnumField, self).__init__(*args, **kwargs)\n    \n    def to_python(self, value):\n        if isinstance(value, int):\n            return self.values[value]\n        else:\n            return value\n\n    def get_prep_value(self, value):\n        return self.inverse[value]\n	409	1128	python
dict_inverse m = if size m' == size m then m' else error "not invertible" where\n                     m' = fromList $ fmap swap $ toList m\n                     swap (a,b) = (b,a)\n	44	1129	haskell
dict_inverse m = if size m' == size m then m' else error "not invertible" where\n                     m' = fromList $ fmap swap $ toList m\n                     swap (a,b) = (b,a)\n	44	1130	haskell
var time_to_string = function(t) {\n        var currentTime = new Date();\n        var delta = currentTime.getTime() - t.getTime();\n        var mpy = 31536000000;\n        var mpm = 2628000000;\n        var years = Math.floor(delta / mpy);\n        var months = Math.floor((delta % mpy) / mpm);\n        if (years > 0)\n        {\n            var s = years + " years ";\n            if (months > 0)\n            {\n                s += months + " months ago";\n            }\n            return s;\n        }\n        \n        if (months > 0)\n        {\n            return months + " months ago";\n        }\n        \n        var days = Math.floor(delta / 86400000);\n        if (days > 0)\n        {\n            return days + " days ago";\n        }\n        \n        var hours = Math.floor(delta / 3600000);\n        if (hours > 0)\n        {\n            return hours + " hours ago";\n        }\n        \n        var minutes = Math.floor(delta / 60000);\n        return minutes + " minutes ago";\n    }\n	293	1136	javascript
var time_to_string = function(t) {\n    var currentTime = new Date();\n    var delta = currentTime.getTime() - t.getTime();\n    var mpy = 31536000000;\n    var mpm = 2628000000;\n    var years = Math.floor(delta / mpy);\n    var months = Math.floor((delta % mpy) / mpm);\n    var essify = function(num, desc) {\n        s = num + " " + desc;\n        if (num == 0 || num > 1) {\n            s += "s";\n        }\n        return s;\n    }\n        if (years > 0)\n        {\n            var s = essify(years, "year");\n            if (months > 0)\n            {\n                s += essify(months, "month");\n            }\n            \n            s += " ago";\n            return s;\n        }\n    \n    if (months > 0)\n    {\n        return essify(months, "month") + " ago";\n    }\n    \n    var days = Math.floor(delta / 86400000);\n    if (days > 0)\n    {\n        return essify(days, "day") + " ago";\n    }\n    \n    var hours = Math.floor(delta / 3600000);\n    if (hours > 0)\n    {\n        return essify(hours, "hour") + " ago";\n    }\n    \n    var minutes = Math.floor(delta / 60000);\n    return essify(minutes, "minute") + " ago";\n}\n	293	1138	javascript
var time_to_string = function(t) {\n    var currentTime = new Date();\n    var delta = currentTime.getTime() - t.getTime();\n    var mpy = 31536000000;\n    var mpm = 2628000000;\n    var years = Math.floor(delta / mpy);\n    var months = Math.floor((delta % mpy) / mpm);\n    var essify = function(num, desc) {\n        s = num + " " + desc;\n        if (num == 0 || num > 1) {\n            s += "s";\n        }\n        return s;\n    }\n    if (years > 0)\n    {\n        var s = essify(years, "year");\n        if (months > 0)\n        {\n            s += essify(months, "month");\n        }\n        \n        s += " ago";\n        return s;\n    }\n    \n    if (months > 0)\n    {\n        return essify(months, "month") + " ago";\n    }\n    \n    var days = Math.floor(delta / 86400000);\n    if (days > 0)\n    {\n        return essify(days, "day") + " ago";\n    }\n    \n    var hours = Math.floor(delta / 3600000);\n    if (hours > 0)\n    {\n        return essify(hours, "hour") + " ago";\n    }\n    \n    var minutes = Math.floor(delta / 60000);\n    return essify(minutes, "minute") + " ago";\n}\n	293	1139	javascript
/* Inverts the Modelview transformation using gluUnProject. */\nint eye2object (GLdouble eyex, GLdouble eyey, GLdouble eyez,\n  \t        GLdouble *objx, GLdouble *objy, GLdouble *objz) {\n\tGLint viewport[4] = {0, 0, 1, 1};\n\tGLdouble mvmatrix[16];\n\tGLdouble projmatrix[16] = {1, 0, 0, 0, \n\t\t\t\t   0, 1, 0, 0,\n\t\t\t\t   0, 0, 1, 0,\n\t\t\t\t   0, 0, 0, 1};\n\n\tGLdouble winx = 0.5*(eyex+1.0); // undo the device->window\n\tGLdouble winy = 0.5*(eyey+1.0); // transformation.\n\tGLdouble winz = 0.5*(eyez+1.0);\n\t\n\tglGetDoublev (GL_MODELVIEW_MATRIX, mvmatrix);\n\t\n\treturn gluUnProject(winx, winy, winz,\n                     \t    mvmatrix, projmatrix, viewport,\n\t\t     \t    objx, objy, objz); \n}\n	416	1143	c
// Handling mouse-drags:\nfloat startx, starty;\n\n\nvoid mouse (int button, int state, int x, int y) {\n    if (state == GLUT_DOWN) {\n        startx = x; starty = y;\n        glutMotionFunc(motion_rotation);\n    } else if (state == GLUT_UP) {\n        glutMotionFunc(NULL);\n    }\n    glutPostRedisplay();\n}\n\nvoid motion_rotation (int x, int y) {\n    float dx = (x - startx);\n    float dy = (y - starty);\n    startx = x; starty = y;\n\n    glMatrixMode(GL_MODELVIEW);\t\n    GLdouble axis_x, axis_y, axis_z;\n\t\t\n    eye2object(0., 1., 0.,\n\t       &axis_x, &axis_y, &axis_z);\n    glRotatef(dx, axis_x, axis_y, axis_z);\n    eye2object(1., 0., 0.,\n\t       &axis_x, &axis_y, &axis_z);\n    glRotatef(dy, axis_x, axis_y, axis_z);\n\t\n    glutPostRedisplay();\n}\n	194	1145	c
var time_to_string = function(currentTime, displayTime) {\n    var delta = currentTime.getTime() - displayTime.getTime();\n    var mpy = 31536000000;\n    var mpm = 2628000000;\n    var years = Math.floor(delta / mpy);\n    var months = Math.floor((delta % mpy) / mpm);\n    var essify = function(num, desc) {\n        s = num + " " + desc;\n        if (num == 0 || num > 1) {\n            s += "s";\n        }\n        return s;\n    }\n    if (years > 0)\n    {\n        var s = essify(years, "year");\n        if (months > 0)\n        {\n            s += essify(months, "month");\n        }\n        \n        s += " ago";\n        return s;\n    }\n    \n    if (months > 0)\n    {\n        return essify(months, "month") + " ago";\n    }\n    \n    var days = Math.floor(delta / 86400000);\n    if (days > 0)\n    {\n        return essify(days, "day") + " ago";\n    }\n    \n    var hours = Math.floor(delta / 3600000);\n    if (hours > 0)\n    {\n        return essify(hours, "hour") + " ago";\n    }\n    \n    var minutes = Math.max(0, Math.floor(delta / 60000));\n    return essify(minutes, "minute") + " ago";\n    \n}\n	293	1146	javascript
def datetime_to_ticks(dt):\n    """\n    Return the given datetime object as ms since the epoch.\n    """\n    return dt.time().time() * 1000\n	420	1151	python
def datetime_to_ticks(dt):\n    """\n    Return the given datetime object as ms since the epoch.\n    """\n    return dt.time().time() * 1000\n	420	1152	python
def datetime_to_ticks(dt):\n    """\n    Return the given datetime object as ms since the epoch.\n    """\n    return time.mktime(dt.timetuple()) * 1000\n	420	1155	python
from datetime import datetime\n	418	1157	python
def s () :\n    w = 2\n    class x :\n        def __repr__() :\n            pass\n	434	1167	python
\.


--
-- Data for Name: zoo_spec; Type: TABLE DATA; Schema: public; Owner: codecatalog
--

COPY zoo_spec (spec, version_id, name, summary, status) FROM stdin;
	1	unnamed		0
	3	unnamed		0
	5	unnamed		0
	10	hello		0
	11	hola		0
	12	bonjour		0
	13	bonjour	Says hello in French.	0
	14	unnamed		0
	16	distinct_by		0
	17	distinct_by	Removes adjacent duplicates from a list according to a projection function.	0
`distinct_by(f,xs)` gives every element `x` of `xs` which is not preceded by an element `y` such that `f(x) == f(y)`.\n\nFor example:\n\n    >>> distinct_by(lambda x: x*x, [1,3,-3,4,-6,6,-6])\n    [1,3,4,-6]\n\n	18	distinct_by	Removes adjacent duplicates from a list according to a projection function.	0
	19	unnamed		0
	21	traverse_cons_list		0
	22	traverse_cons_list	Returns a generator that traverses a cons list from front to back.	0
A *cons-list* is a "list" of the following form:\n\n    (3,(1,(4,(1,(5,())))))\nWhich represents the regular python list `[1,2,3,4,5]`. \n\nFormally: a *cons-list* is either `()` or `(x,xs)`, where `xs` is another cons-list.\n\n`traverse_cons_list` traverses a cons-list in order from front to back.\n\n    >>> for i in traverse_cons_list((1,(2,(3,(4,()))))): print i\n    1\n    2\n    3\n    4\n\n	23	traverse_cons_list	Returns a generator that traverses a cons list from front to back.	0
	24	unnamed		0
	26	heapq		0
	27	heapq	The python heapq library.	0
See the [Python documentation for heapq](http://docs.python.org/library/heapq.html).	28	heapq	The python heapq library.	0
	29	unnamed		0
	31	shortest_path		0
	33	shortest_path	Finds a shortest path through a computable graph.	0
`shortest_path(children, success, init)`\n\n  * `children`, a function taking an element and returning a list of tuples `(weight, child, edge)`.  `weight` adds to the weight of the current traversal.  `child` is the child element to traverse next. `edge` is the "edge marker", which will appear in the return value.\n  * `success`, a function taking an element and returning `True` or `False`\n  * `init`, the element to start at\n\nIf a path was found from `init` to a node that `success` returned true for, it will return a list of `edge` values (as returned by `children`).	34	shortest_path	Finds a shortest path through a computable graph.	0
	35	unnamed		0
	38	elt		0
	39	elt	A lightweight HTML element creator for jquery.	0
`elt` is an easy way to declaratively create HTML from javascript.  It requires `jquery`.  Here is an example.  To create this HTML:\n\n    <table border="1">\n      <tr>\n       <td>Javascript</td>\n       <td><i>Awesome</i></td>\n      </tr>\n      <tr>\n       <td>Java</td>\n       <td>Stinky</td>\n      </tr>\n     </table>\n\nYou can transliterate to `elt` calls:\n\n    var table = \n      elt('table', { border: 1 },\n        elt('tr', {}, \n          elt('td', {}, "Javascript"),\n          elt('td', {}, \n            elt('i', {}, "Awesome")))),\n        elt('tr', {},\n          elt('td', {}, "Java"),\n          elt('td', {}, "Stinky")));\n\nThis function is (externally) side-effect free; it simply returns a DOM node.	40	elt	A lightweight HTML element creator for jquery.	0
	41	unnamed		0
	43	reload		0
	44	reload	Reloads the page.	0
	46	unnamed		0
	48	maximum_by		0
	49	maximum_by	Finds the maximum of a list of elements using a measure function.	0
`maximum_by(measure, xs)` finds the element `x` of `xs` with the highest value of `measure(x)`.  In the case of ties, it takes the first one.  For example:\n\n    >>> maximum_by(len, ['my', 'spoon', 'is', 'too', 'big']\n    'spoon'	50	maximum_by	Finds the maximum of a list of elements using a measure function.	0
	51	unnamed		0
	53	re		0
	54	re	The python re library for regular expressions	0
See the [library documentation for re](http://docs.python.org/library/re.html).	55	re	The python re library for regular expressions	0
	56	unnamed		0
	58	initial_whitespace		0
	59	initial_whitespace	Returns any initial whitespace found in the given string.	0
    >>> initial_whitespace("   \\tfoo bar baz   ")\n    '   \\t'\n\n    >>> initial_whitespace("foo bar baz")\n    ''	60	initial_whitespace	Returns any initial whitespace found in the given string.	0
	62	unnamed		0
	64	strip_indent		0
	65	strip_indent	Removes as much indentation as possible from a multiline string.	0
`strip_indent(text)` takes some multiline text, identifies the least amount of whitespace leading each line, and removes it.	66	strip_indent	Removes as much indentation as possible from a multiline string.	0
`strip_indent(text)` takes some multiline text, identifies the least amount of whitespace leading each line, and removes it.  It returns a tuple `(stripped, whitespace)`, where `stripped` is the text with the indentation removed, and `whitespace` is the whitespace that was removed.\n\n**NOTE** This implementation has a bug; it assumes that the whitespace will be made of only space characters.  It does weird shit if it isn't.	68	strip_indent	Removes as much indentation as possible from a multiline string.	0
	70	unnamed		0
	72	indent_by		0
	73	indent_by	Prefixes every line ("indents") of a multiline string by a string.	0
    >>> indent_by("xxxx", "  foo\\nbar\\n")\n    "xxxx  foo\\nxxxxbar\\n"\n\nThe trailing `"\\n"` will be there even if the original string didn't have it.	74	indent_by	Prefixes every line ("indents") of a multiline string by a string.	0
	75	unnamed		0
	77	linecomment		0
	78	linecomment	A dictionary mapping language names to their line comment strings.	0
	80	linecomment	A dictionary mapping language names to their single line comment strings.	0
	81	unnamed		0
	83	max		0
	84	max	Finds the maximum value of all of its arguments.	0
	91	unnamed		0
	94	min		0
	95	min	Finds the minimum value of its arguments.	0
	97	unnamed		0
	100	button		0
	101	button	Creates a simple button with the given text and click action using jquery.	0
	102	unnamed		0
	105	horizontal		0
	106	horizontal	Groups a list of DOM elements horizontally using a table.	0
	107	unnamed		0
	110	vertical		0
	111	vertical	Groups a list of DOM elements vertically using a table.	0
	258	unnamed		0
The table borders should be completely invisible -- this is just a spatial layout combinator.	112	vertical	Groups a list of DOM elements vertically using a table.	0
The table borders should be completely invisible.  This is just a spatial layout combinator.	113	horizontal	Groups a list of DOM elements horizontally using a table.	0
`strip_indent(text)` takes some multiline text, identifies the least amount of whitespace leading each line, and removes it.  It returns a tuple `(stripped, whitespace)`, where `stripped` is the text with the indentation removed, and `whitespace` is the whitespace that was removed.\n\n**NOTE** This implementation has a bug; it assumes that the whitespace will be made of only space characters.  It does weird shit if it isn't.	114	strip_indent	Removes as much indentation as possible from a multiline string.	0
`strip_indent(text)` takes some multiline text, identifies the least amount of whitespace leading each line, and removes it.  It returns a tuple `(stripped, whitespace)`, where `stripped` is the text with the indentation removed, and `whitespace` is the whitespace that was removed.\n\n**NOTE** This implementation has a bug; it assumes that the whitespace will be made of only space characters.  It does weird shit if it isn't.	115	strip_indent	Renoves as such deninnation is possible from a multiline stink.	0
`strip_indent(text)` takes some multiline text, identifies the least amount of whitespace leading each line, and removes it.  It returns a tuple `(stripped, whitespace)`, where `stripped` is the text with the indentation removed, and `whitespace` is the whitespace that was removed.\n\n**NOTE** This implementation has a bug; it assumes that the whitespace will be made of only space characters.  It does weird shit if it isn't.	116	strip_indent	Removes as much indentation as possible from a multiline string.	0
`strip_indent(text)` takes some multiline text, identifies the least amount of whitespace leading each line, and removes it.  It returns a tuple `(stripped, whitespace)`, where `stripped` is the text with the indentation removed, and `whitespace` is the whitespace that was removed.\n\n**NOTE** This implementation has a bug; it assumes that the whitespace will be made of only space characters.  It does super-weird shit if it isn't.	117	strip_indent	Removes as much indentation as possible from a multiline string.	0
`strip_indent(text)` takes some multiline text, identifies the least amount of whitespace leading each line, and removes it.  It returns a tuple `(stripped, whitespace)`, where `stripped` is the text with the indentation removed, and `whitespace` is the whitespace that was removed.	118	strip_indent	Removes as much indentation as possible from a multiline string.	0
	122	unnamed		0
	124	wrap_fields		0
	125	wrap_fields	Takes a dictionary of wrapper functions and wraps matching keys of another dictionary.	0
`wrap_fields(wrapper, dictionary)`, when `wrapper` is a dictionary of unary functions, returns `dictionary` where any keys `k` that are also in `wrapper` are passed through `wrapper[k]`.  The function does not modify the original dictionary, but returns a copy.\n\nFor example:\n\n    >>> wrappers = { \n    ...     'user': lambda u: '<<' + u + '>>', \n    ...     'email': lambda e: e.lower(),\n    ... }\n    >>> user = { \n    ...     'user': 'luke', \n    ...     'email': 'YOURMOM@Example.com', \n    ...     'favorite color': 'red' \n    ... }\n    >>> wrap_fields(wrappers, user)\n    {'email': 'yourmom@example.com', 'user': '<<luke>>', 'favorite color': 'red'}	126	wrap_fields	Takes a dictionary of wrapper functions and wraps matching keys of another dictionary.	0
`wrap_fields(wrapper, dictionary)`, when `wrapper` is a dictionary of unary functions, returns `dictionary` where any keys `k` that are also in `wrapper` are passed through `wrapper[k]`.  The function does not modify the original dictionary, but returns a copy.\n\nFor example:\n\n    >>> wrappers = { \n    ...     'user': lambda u: '<<' + u + '>>', \n    ...     'email': lambda e: e.lower(),\n    ... }\n    >>> user = { \n    ...     'user': 'luke', \n    ...     'email': 'YOURMOM@Example.com', \n    ...     'favorite color': 'red' \n    ... }\n    >>> wrap_fields(wrappers, user)\n    {'email': 'yourmom@example.com', 'user': '<<luke>>', 'favorite color': 'red'}	128	wrap_fields	Takes a dictionary of wrapper functions and uses it to wrap the values of another dictionary.	0
	129	unnamed		0
	131	dict_inverse		0
	132	dict_inverse	Creates a dictionary that maps values back to keys from another dictionary.	0
For example:\n\n    >>> dict_inverse({0: 'Open', 1: 'Resolved', 2: 'Closed'})\n    {'Resolved': 1, 'Open': 0, 'Closed': 2}\n\nThis function throws an exception if the given dictionary is not one-to-one (invertible).	133	dict_inverse	Creates a dictionary that maps values back to keys from another dictionary.	0
For example:\n\n    >>> dict_inverse({0: 'Open', 1: 'Resolved', 2: 'Closed'})\n    {'Resolved': 1, 'Open': 0, 'Closed': 2}\n\nThis function throws an exception if the given dictionary is not one-to-one (invertible).\n\n\n    >>> dict_inverse({0: 'Open', 1: 'Closed', 2: 'Closed'})\n    ValueError: Dictionary given to dict_inverse is not one-to-one.  \n                       Duplicate value: Closed\n                       Mapped to by: 1 and 2\n	135	dict_inverse	Creates a dictionary that maps values back to keys from another dictionary.	0
	136	unnamed		0
	138	dict_inverse_multi		0
	139	dict_inverse_multi	Given a dictionary, returns a dictionary that maps the values back the sets of keys that mapped to them.	0
Given a dictionary `d`: if `d[k]=v`, then `k in dict_inverse_multi(d)[v]`.\n\n    >>> dict_inverse_multi({1: 'Open', 2: 'Resolved', 3: 'Closed'})\n    {'Resolved': set([2]), 'Open': set([1]), 'Closed': set([3])}\n    >>> dict_inverse_multi({1: 'Open', 2: 'Closed', 3: 'Closed'})\n    {'Open': set([1]), 'Closed': set([2, 3])}\n	140	dict_inverse_multi	Given a dictionary, returns a dictionary that maps the values back the sets of keys that mapped to them.	0
Given a dictionary `d`: if `d[k]=v`, then `k in dict_inverse_multi(d)[v]`.\n\n    >>> dict_inverse_multi({1: 'Open', 2: 'Resolved', 3: 'Closed'})\n    {'Resolved': set([2]), 'Open': set([1]), 'Closed': set([3])}\n\n    >>> dict_inverse_multi({1: 'Open', 2: 'Closed', 3: 'Closed'})\n    {'Open': set([1]), 'Closed': set([2, 3])}\n	141	dict_inverse_multi	Given a dictionary, returns a dictionary that maps the values back the sets of keys that mapped to them.	0
	142	unnamed		0
	146	label_table		0
	147	label_table	Creates a table that labels a dictionary of DOM nodes by their keys.	0
	477	tabs	Simple switchable tabs for HTML/jQuery	0
	562	simple_collatz	Collatz checker which counts steps	0
	690	unnamed		0
    label_table({ 'foo': $('<b>Hello</b>'), 'bar': $('<input type="text" value="World" />') })\n\nWould render something like:\n\n<table>\n <tr>\n  <td>foo</td>\n  <td><b>Hello</b></td>\n </tr>\n <tr>\n  <td>bar</td>\n  <td><input type="text" value="World" /></td>\n </tr>\n</table>	148	label_table	Creates a table that labels a dictionary of DOM nodes by their keys.	0
	152	unnamed		0
	154	normalize_code		0
	156	unnamed		0
	256	random	The standard python random module.	0
	260	call_to_arg_dict		0
	157	normalize_code	normalize_code(code_text) takes a block of code as a string and returns it in the form preferred by the CodeCatalog (stripped leading and trailing whitespace, left-justified with respect to tabs).	0
	158	normalize_code		0
`strip_indent(text)` takes some multiline text, identifies the least amount of whitespace leading each line, and removes it.  It returns a tuple `(stripped, whitespace)`, where `stripped` is the text with the indentation removed, and `whitespace` is the whitespace that was removed.	159	strip_indent	Removes as much indentation as possible from a multiline string.	0
`normalize_code(code_text)` takes a block of code as a string and returns it in the form preferred by the CodeCatalog (([strip leading and trailing whitespace](/spec/40)) and left-justify with respect to tabs)	160	normalize_code		0
`normalize_code(code_text)` takes a block of code as a string and returns it in the form preferred by the CodeCatalog (([strip leading and trailing whitespace](/spec/40)) and left-justify with respect to tabs)	161	normalize_code	Format a string to match CodeCatalog's conventions for code.	0
`normalize_code(code_text)` takes a block of code as a string and returns it in the form preferred by the CodeCatalog ([strip leading and trailing whitespace](/spec/40)) and left-justify with respect to tabs)	162	normalize_code	Format a string to match CodeCatalog's conventions for code.	0
`normalize_code(code_text)` takes a block of code as a string and returns it in the form preferred by the CodeCatalog ([strip leading and trailing whitespace](/spec/40) and left-justify with respect to tabs)	163	normalize_code	Format a string to match CodeCatalog's conventions for code.	0
	164	unnamed		0
	166	frobnicate		0
	167	frobnicate	Hoobar frojingo.	0
Monkeypatch!	168	frobnicate	Hoobar frojingo.	0
	170	unnamed		0
	172	file_extension_map		0
	173	language_to_file_extension_map		0
	174	language_to_file_extension_map	A map from common language strings into their file extensions.	0
	184	language_to_line_comment_map	A dictionary mapping language names to their single line comment strings.	0
    label_table({ \n       'foo': $('<b>Hello</b>'), \n       'bar': $('<input type="text" value="World" />'),\n    })\n\nWould render something like:\n\n<table>\n <tr>\n  <td>foo</td>\n  <td><b>Hello</b></td>\n </tr>\n <tr>\n  <td>bar</td>\n  <td><input type="text" value="World" /></td>\n </tr>\n</table>	198	label_table	Creates a table that labels a dictionary of DOM nodes by their keys.	0
	199	unnamed		0
	200	unnamed		0
	202	unnamed		0
	204	pop_random		0
	205	pop_random	Remove and return a random element from the given sequence.	0
	207	unnamed	Some sort of mock POP server.	0
	208	unnamed		0
	210	hashlib		0
	211	hashlib	The python hashlib module for cryptographic hashing.	0
	212	unnamed		0
	214	md5		0
	215	md5	Returns the md5 digest of a string in hex.	0
See the python standard library documentation for [hashlib](http://docs.python.org/library/hashlib.html).	216	md5	Returns the md5 digest of a string in hex.	0
	218	unnamed		0
	220	urllib		0
	221	urllib	The python urllib library for url handling.	0
See the python standard library documentation for [urllib](http://docs.python.org/library/urllib.html).	222	urllib	The python urllib library for url handling.	0
	223	unnamed		0
	225	gravatar_url		0
	226	gravatar_url	Constructs the gravatar url for a given email address.	0
`size` is the size in pixels of the resulting image, and defaults to the [gravatar](http://www.gravatar.com) default image size 80.  `default` is the image to use if the email has no associated gravatar.  Or `default` can be one of the following strings (taken from the [developer documentation](http://en.gravatar.com/site/implement/images/)).\n\n* `404`: do not load any image if none is associated with the email hash, instead return an HTTP 404 (File Not Found) response\n* `mm`: (mystery-man) a simple, cartoon-style silhouetted outline of a person (does not vary by email hash)\n* `identicon`: a geometric pattern based on an email hash\n* `monsterid`: a generated 'monster' with different colors, faces, etc\n* `wavatar`: generated faces with differing features and backgrounds\n* `retro`: awesome generated, 8-bit arcade-style pixelated faces	227	gravatar_url	Constructs the gravatar url for a given email address.	0
	230	unnamed		0
	232	dropdown		0
	233	dropdown	Creates an HTML element that drops down with a list of items when clicked.	0
`dropdown(element, drop)` creates a `div` around `element`, such that when `element` is clicked, the function argument `drop` is called and passed `adder`.  `adder` is itself a function that, when called, adds the element it is passed to the dropdown list.  If `element` is clicked while the dropdown is "down", it rolls back up.\n\nThe types are as follows:\n\n* `element` : `Element`\n* `drop` : `(Element -> Action) -> Action`\n* *returns* `Element`\n\nHere is an example of a simple dropdown:\n\n    dropdown($('<a href="#">Click me</a>'), function(adder) {\n        adder($('<p>Item One</p>'));\n        adder($('<p>Item Two</p>'));\n        adder($('<p>Item Three</p>'));\n    });\n\nThis will *return* a div, which must now be inserted into the document.	234	dropdown	Creates an HTML element that drops down with a list of items when clicked.	0
    >>> case(function s: s[0], "yes", {\n    ...     'y': lambda s: "Yes: " + s,\n    ...     'n': lambda s: "No: " + s,\n    ... })\n    Yes: yes\n\nThis function can be used for algebraic data type encoding.	384	case	Chooses between a dictionary of alternatives by a projection of its argument.	0
Example:\n\n    >>> obj = DictObject({ 'foo': '1', 'bar': lambda: "Hello" })\n    >>> obj.foo\n    1\n    >>> obj.bar()\n    'Hello'\n	386	DictObject	Creates an object out of a dictionary, where the keys of the dictionary map to fields on the object.	0
Example:\n\n    >>> obj = DictObject({ 'foo': '1', 'bar': lambda: "Hello" })\n    >>> obj.foo\n    1\n    >>> obj.bar()\n    'Hello'\n\n_Question from ST: Does the aliasing have significance? That is:_\n\n    >>> d = {'foo': '1', 'bar': lambda: 'Hello'}\n    >>> obj = DictObject(d)\n    >>> d['bif'] = 'baz'\n    >>> obj.baz	388	DictObject	Creates an object out of a dictionary, where the keys of the dictionary map to fields on the object.	0
	389	unnamed		0
	391	uncons_set		0
	392	uncons_set	Splits a set into a single arbitrary element and the rest of the set.	0
`dropdown(element, drop)` creates a `div` around `element`, such that when `element` is clicked, the function argument `drop` is called and passed `adder`.  `adder` is itself a function that, when called, adds the element it is passed to the dropdown list.  If `element` is clicked while the dropdown is "down", it rolls back up.\n\nThe types are as follows:\n\n* `element` : `Element`\n* `drop` : `(Element -> Action) -> Action`\n* **returns** `Element`\n\nHere is an example of a simple dropdown:\n\n    dropdown($('<a href="#">Click me</a>'), function(adder) {\n        adder($('<p>Item One</p>'));\n        adder($('<p>Item Two</p>'));\n        adder($('<p>Item Three</p>'));\n    });\n\nThis will *return* a div, which must now be inserted into the document.	235	dropdown	Creates an HTML element that drops down with a list of items when clicked.	0
	237	random_item	Remove and return a random element from the given sequence.	0
	238	random_item	Return a random element from the given sequence.	0
	247	unnamed		0
	249	inspect		0
	250	inspect	python inspect library for runtime code inspection	0
See the python standard library documentation for [inspect](http://docs.python.org/library/inspect.html).	251	inspect	python inspect library for runtime code inspection	0
	252	unnamed		0
	254	random		0
	261	call_to_arg_dict	Simulates a call to a python function, returning the keyword argument map that would have been passed to it.	0
For example, given the definition:\n\n    def foo(a,b, c=1,d=2, **kwargs):\n        print a,b,c,d,kwargs\n\n`call_to_arg_dict` will unroll its arguments, without calling the function:\n\n    >>> call_to_arg_dict(foo, 3,4, d=9, extra=42)\n    { 'a': 3, 'b': 4, 'c': 1, 'd': 9, 'kwargs': { 'extra': 42 } }\n\nIn the case where the given arguments are illegal to pass, `call_to_arg_dict` raises ` TypeError`, in particular it tries to generate the exact same error that python would have.	264	call_to_arg_dict	Simulates a call to a python function, returning the keyword argument map that would have been passed to it.	0
	265	unnamed		0
	267	instance_methods		0
For example, given the definition:\n\n    def foo(a,b, c=1,d=2, **kwargs):\n        print a,b,c,d,kwargs\n\n`call_to_arg_dict` will unroll its arguments, without calling the function:\n\n    >>> call_to_arg_dict(foo, 3,4, d=9, extra=42)\n    { 'a': 3, 'b': 4, 'c': 1, 'd': 9, 'kwargs': { 'extra': 42 } }\n\nIn the case where the given arguments are illegal to pass, `call_to_arg_dict` raises ` TypeError`, in particular it tries to generate the exact same error that python would have.\n\nFor any function `f`, the following are equivalent:\n\n    foo(...argument list...)\n\nand\n\n    kwargs = call_to_arg_dict(foo, ...argument list...)\n    foo(**kwargs)	268	call_to_arg_dict	Simulates a call to a python function, returning the keyword argument map that would have been passed to it.	0
	269	instance_methods	Returns a dictionary of methods that are callable on a given object.	0
	271	unnamed		0
	273	unnamed		0
	274	sys		0
	275	sys		0
	276	sys	The python sys module for operating system interaction	0
See the python standard library documentation for [sys](http://docs.python.org/library/sys.html).	277	sys	The python sys module for operating system interaction	0
	278	unnamed		0
	280	unnamed		0
	281	command_interface		0
	282	command_interface	Creates a command-line command interface out of an object of a class.	0
	283	command_interface	Creates a command-line command interface out of an object.	0
`command_interface` is an easy way to make a command-line subcommand interface out of a collection of methods.  First, create a class which has one method for each subcommand.  Docstrings on these methods will become the help text for the command:\n\n    class Frob:\n        """Frobnicates the widgeywhack"""\n        def forward(self):\n            """Frobnicates forward"""\n            print "MAHOOJALA!"\n\n        def backward(self, orig="nowhere"):\n            """Unfrobnicates\n                --orig=<name>   (optional) sets the original source of frobnication\n            """\n            print "!ALAJOOHAM (" + orig + ")"\n\nA `Frob` object can now act like a command-line interface:\n\n    def main():\n        command_interface(Frob())	284	command_interface	Creates a command-line command interface out of an object.	0
`command_interface` is an easy way to make a command-line subcommand interface out of a collection of methods.  First, create a class which has one method for each subcommand.  Docstrings on these methods will become the help text for the command:\n\n    class Frob:\n        """Frobnicates the widgeywhack"""\n        def forward(self):\n            """Frobnicates forward"""\n            print "MAHOOJALA!"\n\n        def backward(self, orig="nowhere"):\n            """Unfrobnicates\n                --orig=<name>   (optional) sets the original source of frobnication\n            """\n            print "!ALAJOOHAM (" + orig + ")"\n\nA `Frob` object can now act like a command-line interface:\n\n    def main():\n        command_interface(Frob())\n\nThe command line interface translates arguments to positional arguments to the functions, and long options to keyword arguments (`--name` translates to `True` and `--name=value` translates to a string argument of `value`).\n\nSo if this script is called `frob`, it would work like so:\n\n    % frob\n    frob: Frobnicates the widgeywhack\n    Commands:\n        forward:    Frobnicates forward\n        backward:   Unfrobnicates\n    % frob forward\n    MAHOOJALA!\n    % frob help backward\n    frob backward: Unfrobnicates\n             --orig=<name>  (optional) sets the original source of frobnication\n    % frob backward\n    !ALAJOOHAM (nowhere)\n    % frob backward somewhere\n    !ALAJOOHAM (somewhere)\n    % frob backward --orig=anywhere\n    !ALAJOOHAM (anywhere)	285	command_interface	Creates a command-line command interface out of an object.	0
    >>> case(function s: s[0], "yes", {\n    ...     'y': lambda s: "Yes: " + s,\n    ...     'n': lambda s: "No: " + s,\n    ... })\n    Yes: yes\n\nThis function can be used for algebraic data type encoding. (expand!)	385	case	Chooses between a dictionary of alternatives by a projection of its argument.	0
	631	select text	Selects the text in a DOM node (jQuery)	0
	639	once	Tests if a list contains a given element exactly once.	0
Example:\n\n    >>> obj = DictObject({ 'foo': '1', 'bar': lambda: "Hello" })\n    >>> obj.foo\n    1\n    >>> obj.bar()\n    'Hello'\n\n_Question from ST: Does the aliasing have significance?_	387	DictObject	Creates an object out of a dictionary, where the keys of the dictionary map to fields on the object.	0
	557	bogo sort	A sort which works by the principle of randomly swapping the numbers until they are correctly sorted. 	0
`command_interface` is an easy way to make a command-line subcommand interface out of a collection of methods.  First, create a class which has one method for each subcommand.  Docstrings on these methods will become the help text for the command:\n\n    class Frob:\n        """Frobnicates the widgeywhack"""\n        def forward(self):\n            """Frobnicates forward"""\n            print "MAHOOJALA!"\n\n        def backward(self, orig="nowhere"):\n            """Unfrobnicates\n                --orig=<name>   (optional) sets the original source of frobnication\n            """\n            print "!ALAJOOHAM (" + orig + ")"\n\nA `Frob` object can now act like a command-line interface:\n\n    def main():\n        command_interface(Frob())\n\nThe command line interface translates arguments to positional arguments to the functions, and long options to keyword arguments (`--name` translates to `True` and `--name=value` translates to a string argument of `value`).\n\nSo if this script is called `frob`, it would work like so:\n\n    % frob\n    frob: Frobnicates the widgeywhack\n    Commands:\n        forward:    Frobnicates forward\n        backward:   Unfrobnicates\n    % frob forward\n    MAHOOJALA!\n    % frob help backward\n    frob backward: Unfrobnicates\n             --orig=<name>  (optional) sets the original source of frobnication\n    % frob backward\n    !ALAJOOHAM (nowhere)\n    % frob backward somewhere\n    !ALAJOOHAM (somewhere)\n    % frob backward --orig=anywhere\n    !ALAJOOHAM (anywhere)	287	command_interface	Creates a command-line subcommand interface out of an object.	0
	288	unnamed		0
	290	languages_list		0
	292	language_list		0
	293	language_list	Return the list of languages (in string form) supported by the CodeCatalog.	0
	295	unnamed		0
	301	unnamed		0
	303	Version		0
	304	Version	An object representation of a CodeCatalog version for a snippet or spec.	0
	305	unnamed		0
	307	json		0
	308	json	The json library for Python.	0
	309	unnamed		0
	311	unnamed		0
	313	urllib		0
	314	urllib	The urllib library for Python.	0
	315	urllib	A library for manipulating urls in Python.	0
	316	unnamed		0
	318	httplib		0
	319	httplib	The httplib library for Python.	0
	320	JSONClient		0
	321	<__main__.Interface instance at 0x2610050>		0
	322	JSONClient	A simple wrapper for posting and get http requests using dictionary parameters.	0
	324	unnamed		0
	325	unnamed		0
	327	unnamed		0
	329	unnamed		0
	331	unnamed		0
	333	JSONClient	A simple wrapper for posting and get http requests using dictionary parameters (JSON)	0
	334	unnamed		0
	336	DictObject		0
	338	DictObject		0
	339	DictObject	Creates an object out of a dictionary, where the keys of the dictionary map to fields on the object.	0
Example:\n\n    >>> obj = DictObject({ 'foo': '1', 'bar': lambda: "Hello" })\n    >>> obj.foo\n    1\n    >>> obj.bar()\n    'Hello'\n	340	DictObject	Creates an object out of a dictionary, where the keys of the dictionary map to fields on the object.	0
	342	unnamed		0
	344	unnamed		0
	346	maximum_by		0
	347	unnamed		0
	348	unnamed		0
	350	unnamed		0
	352	maximum_by		0
	353	maximum_by	Finds the maximum of a list by a measure function	0
`maximum_by(f, xs)` finds the first element `x` in `xs` for which `f(x)` achieves its greatest value.  For example:\n\n    >>> maximum_by(lambda x: x*x, [-1,3,-5])\n    -5	354	maximum_by	Finds the maximum of a list by a measure function	0
	355	unnamed		0
	357	detect_by_pattern		0
	358	detect_by_pattern	Given some text and a set of patterns for each of several keys, finds the most likely key to generate that text.	0
A *pattern map* is what `detect_by_pattern` takes as its second argument.  It is a dictionary with lists of regular expressions as its values.  For example:\n\n    languages = { \n         'English': [\n              re.compile(r'\\bis\\b'),\n              re.compile(r'\\band\\b'),\n         ],\n         'Spanish': [\n              re.compile(r'\\bes\\b'),\n              re.compile(r'\\bte\\b'),\n         ],\n    }\n\nYou can have as many keys as you want, of course.  Given that these patterns are "characteristically" found in their associated languages (e.g. `\\bis\\b` is likely in English and unlikely in Spansh), `detect_by_pattern` makes a guess as to which key (language) the text came from.	360	detect_by_pattern	Given some text and a set of patterns for each of several keys, finds the most likely key to generate that text.	0
	363	unnamed		0
	365	language_patterns		0
	366	language_patterns	A list of "characteristic" patterns in a variety of languages.	0
This is a dictionary of characteristic patterns, a *language map* for various programming languages, suitable for passing to [`detect_by_pattern`](/136/) in order to detect what language a string comes from.	367	language_patterns	A list of "characteristic" patterns in a variety of languages.	0
	369	unnamed		0
	371	detect_language		0
	372	detect_language	Detects the programming language a string of source code comes from.	0
See [`language_patterns`](/138) for the supported languages and some insight into how they are chosen.	374	detect_language	Detects the programming language a string of source code comes from.	0
	375	unnamed		0
	377	partition		0
	378	partition	Partitions a string (before, match, after) the first occurrence of a regular expression.	0
This code is a quick way to put up a 3d-object on the screen using OpenGL/GLUT and letting the user rotate it. Dragging the mouse adds a rotation to the modelview matrix.	559	rotate view	Rotate the view using OpenGL/GLUT	0
	693	simple select		0
If there was no match of the regular expression, then `partition` returns `None`.  The middle return value is a tuple of all captured groups by the regular expressions (so `()` if there were no capturing groups).\n\nFor example:\n\n    >>> partition(r"([ab]*)c", "silver abacus abacus")\n    ("silver ", ("aba",), "us abacus")	379	partition	Partitions a string (before, match, after) the first occurrence of a regular expression.	0
	380	unnamed		0
	382	case		0
	383	case	Chooses between a dictionary of alternatives by a projection of its argument.	0
`uncons_set(set)` will return a tuple `(x,xs)`, where `x in set` and `x not in xs`.  For example:\n\n    >>> s = set(["Arthur","Galaxy",42])\n    >>> uncons_set(s)\n    (42, frozenset(['Arthur','Galaxy']))\n    >>> s\n    set([42,"Arthur","Galaxy"])\n\nThe function has no side effect on the argument.	393	uncons_set	Splits a set into a single arbitrary element and the rest of the set.	0
	394	unnamed		0
	396	dependency_search		0
	397	dependency_search	Searches for a member of a type, where members may have dependencies on other types.	0
*Type* and *member* are used very generally in the above definition.  Types are essentially mutually disjoint sets (a member must belong to exactly one type).  A *member* may depend on the existence of other 	400	dependency_search	Searches for a proof of a proposition in a simple propositional logic.	0
*Type* and *member* are used very generally in the above definition.  Types are essentially mutually disjoint sets (a member must belong to exactly one type).  A *member* may depend on the existence of other 	401	dependency_search	Searches for a set of objects that satisfies simple dependency constraints.	0
We need to take a little time to set up the problem.  We have a set of *types* and *objects*.  An *object* is a member of exactly one *type*, its "existence" may depend on the existence of several other types, and it has a *weight*.  Here is an example problem set up:\n\n    Object  |    Type     |   Weight   |  Dependencies\n    --------+-------------+------------+--------------\n    Car     |  Transport  |   10       | Wheels,Engine\n    Truck   |  Transport  |   15       | Wheels,Engine\n    Tires   |  Wheels     |   2        | \n    Cubes   |  Wheels     |   500      |\n    v6      |  Engine     |   4        |\n    v8      |  Engine     |   6        |\n\n`dependency_search` tries to find a set of *objects* which satisfy a *type* with the least *weight*.   So it would find this solution if asked to search for `Transport`:\n\n    (Car, Wheels, v6)\n\nAlthough this example has a trivial dependency structure, this function works for arbitrary dependencies.  That is, if object `x` depends on types `B` and `C`, then if `x` appears in the solution, so must objects that satisfy `B` and `C`.\n\n**Parameters:**\n\n* `members`: a function taking a *type* and returning a collection of *objects* of that type.\n* `type`: the type the algorithm is trying to satisfy; e.g. `Transport` in the example above.	402	dependency_search	Searches for a set of objects that satisfies simple dependency constraints.	0
We need to take a little time to set up the problem.  We have a set of *types* and *objects*.  An *object* is a member of exactly one *type*, its "existence" may depend on the existence of several other types, and it has a *weight*.  Here is an example problem set up:\n\n    Object  |    Type     |   Weight   |  Dependencies\n    --------+-------------+------------+--------------\n    Car     |  Transport  |   10       | Wheels,Engine\n    Truck   |  Transport  |   15       | Wheels,Engine\n    Tires   |  Wheels     |   2        | \n    Cubes   |  Wheels     |   500      |\n    v6      |  Engine     |   4        |\n    v8      |  Engine     |   6        |\n\n`dependency_search` tries to find a set of *objects* which satisfy a *type* with the least *weight*.   So it would find this solution if asked to search for `Transport`:\n\n    (Car, Wheels, v6)\n\nAlthough this example has a trivial dependency structure, this function works for arbitrary dependencies.  That is, if object `x` depends on types `B` and `C`, then if `x` appears in the solution, so must objects that satisfy `B` and `C`.\n\n**Parameters:**\n\n* `members`: a function taking a *type* and returning a collection of *objects* of that type.\n* `type`: the type the algorithm is trying to satisfy; e.g. `Transport` in the example above.\n\nThe concrete representation of types may be any hashable type, and the concrete representation of objects may be any type whatsoever.	403	dependency_search	Searches for a set of objects that satisfies simple dependency constraints.	0
We need to take a little time to set up the problem.  We have a set of *types* and *objects*.  An *object* is a member of exactly one *type*, its "existence" may depend on the existence of several other types, and it has a *weight*.  Here is an example problem set up:\n\n    Object  |    Type     |   Weight   |  Dependencies\n    --------+-------------+------------+--------------\n    Car     |  Transport  |   10       | Wheels,Engine\n    Truck   |  Transport  |   15       | Wheels,Engine\n    Tires   |  Wheels     |   2        | \n    Cubes   |  Wheels     |   500      |\n    v6      |  Engine     |   4        |\n    v8      |  Engine     |   6        |\n\n`dependency_search` tries to find a set of *objects* which satisfy a *type* with the least *weight*.   So it would find this solution if asked to search for `Transport`:\n\n    (Car, Wheels, v6)\n\nAlthough this example has a trivial dependency structure, this function works for arbitrary dependencies.  That is, if object `x` depends on types `B` and `C`, then if `x` appears in the solution, so must objects that satisfy `B` and `C`.\n\n**Parameters:**\n\n* `members`: a function taking a *type* and returning a collection of *objects* of that type.\n* `type`: the type the algorithm is trying to satisfy; e.g. `Transport` in the example above.\n\nThe concrete representation of types may be any hashable type, and the concrete representation of objects may be any type whatsoever.\n\nIf no solution could be found, returns `None`.	404	dependency_search	Searches for a set of objects that satisfies simple dependency constraints.	0
`tabs` takes a list of tabs and their content (generators), and returns something like what you see below.  For example:\n\n    tabs([\n        { label: 'Foo', content: $('<b>FOO!</b>') },\n        { label: 'Bar', content: function() { \n              alert("Generating bar");\n              return $('<b>BAR!</b>');\n        } },\n    ])\n\nAs you can see, `content` can be a jQuery element or a function, which will be called *once* the first time the tab is accessed.	478	tabs	Simple switchable tabs for HTML/jQuery	0
`tabs` takes a list of tabs and their content (generators), and returns something like what you see below.  For example:\n\n    tabs([\n        { label: 'Foo', content: $('<b>FOO!</b>') },\n        { label: 'Bar', content: function() { \n              alert("Generating bar");\n              return $('<b>BAR!</b>');\n        } },\n    ])\n\nAs you can see, `content` can be a jQuery element or a function, which will be called *once* the first time the tab is accessed.\n\nThe CSS classes used by `tabs` follow:\n\n* `tabstrip`: the class of a table holding each tab (but not the content)\n* `content`: the class of the `div` holding each tab's content\n* `tabs`: the class of a `div` containing the entire suite: tabs and content together	479	tabs	Simple switchable tabs for HTML/jQuery	0
	473	unnamed		0
	476	tabs		0
This code is a quick way to put up a 3d-object on the screen using OpenGL/GLUT and letting the user rotate it. Dragging the mouse adds a rotation to the modelview matrix. To use it, add\n\n  glutMouseFunc(mouse);\n\nto your initialization code.\n	560	rotate view	Rotate the view using OpenGL/GLUT	0
We need to take a little time to set up the problem.  We have a set of *types* and *objects*.  An *object* is a member of exactly one *type*, its "existence" may depend on the existence of several other types, and it has a *weight*.  Here is an example problem set up:\n\n    Object  |    Type     |   Weight   |  Dependencies\n    --------+-------------+------------+--------------\n    Car     |  Transport  |   10       | Wheels,Engine\n    Truck   |  Transport  |   15       | Wheels,Engine\n    Tires   |  Wheels     |   2        | \n    Cubes   |  Wheels     |   500      |\n    v6      |  Engine     |   4        |\n    v8      |  Engine     |   6        |\n\n`dependency_search` tries to find a set of *objects* which satisfy a *type* with the least *weight*.   So it would find this solution if asked to search for `Transport`:\n\n    (Car, Wheels, v6)\n\nAlthough this example has a trivial dependency structure, this function works for arbitrary dependencies.  That is, if object `x` depends on types `B` and `C`, then if `x` appears in the solution, so must objects that satisfy `B` and `C`.\n\n**Parameters:**\n\n* `members`: a function taking a *type* and returning a collection of annotated objects of that type.  The each result of `members` should have the following fields:\n  * `weight`: the weight of choosing this object\n  * `deps`: a `frozenset` of types that this object depends on.\n  * `object`: the type you are using to represent objects -- can be whatever you want, it inhabits the returned list of objects.\n* `type`: the type the algorithm is trying to satisfy; e.g. `Transport` in the example above.\n\nThe concrete representation of types may be any hashable type, and the concrete representation of objects may be any type whatsoever.\n\nIf no solution could be found, returns `None`.	405	dependency_search	Searches for a set of objects that satisfies simple dependency constraints.	0
	406	pprint	The python pprint module for pretty printing	0
See the python standard library documentation for [`pprint`](http://docs.python.org/library/pprint.html).	408	pprint	The python pprint module for pretty printing	0
	409	prettify_json	A pretty reformatter for JSON strings	0
Takes a JSON string, returns a JSON string with whitespace inserted to make it more readable.	412	prettify_json	A pretty reformatter for JSON strings	0
	419	md5	Returns the md5 digest of a string in hex.	0
See the python standard library documentation for [hashlib](http://docs.python.org/library/hashlib.html).	420	hashlib	The python hashlib module for cryptographic hashing.	0
See the python standard library documentation for [hashlib](http://docs.python.org/library/hashlib.html).	421	hashlib	The python hashlib module of cryptographic hash functions.	0
	422	unnamed		0
	424	merge		0
	425	merge	Merge two dictionaries.	0
Perform a *right-biased* merge of two dictionaries.  That is, if `dict1[x]==y` and `dict2[x]==z`, then `merge(dict1,dict2)[x]==z`.	426	merge	Merge two dictionaries.	0
Perform a *right-biased* merge of two dictionaries.  That is, if `dict1[x]==y` and `dict2[x]==z`, then `merge(dict1,dict2)[x]==z`.\n\nThere is a [discussion](http://stackoverflow.com/questions/38987/how-can-i-merge-two-python-dictionaries-as-a-single-expression) of various alternatives for this operation on [StackOverflow](http://stackoverflow.com).	427	merge	Merge two dictionaries.	0
	428	unnamed		0
	429	unnamed		0
	430	unnamed		0
	431	unnamed		0
	433	unnamed		0
	435	unnamed		0
	437	unnamed		0
	439	dynamic_link		0
	440	dynamic_link	Creates an HTML link which calls a callback when clicked.	0
	441	dynamic_link (deprecated)	Creates an HTML link which calls a callback when clicked.	0
	444	unnamed		0
	446	dynamic_link		0
	447	dynamic_link	Creates an HTML link that executes a javascript action when clicked.	0
	452	priority_queue	A queue that maintains a collection of elements such that the head element is always the smallest.	0
	454	scheduler	Schedule jobs based on time.	0
	457	frobnicate2	Twice the frobnication!	0
	459	unnamed		0
	461	rate_limited_callback		0
	462	rate_limited_callback	Calls a function after a specified delay, compressing frequent calls into one.	0
`rate_limited_callback(rate,cb)` calls `cb()` after `rate` milliseconds, compressing nearby calls and only firing on the *last* one.  So for example:\n\n    var rlcb = rate_limited_callback(1000, function() { alert("Boo!" });\n    // 500 milliseconds pass\n    rlcb();\n    // 750 milliseconds pass\n    rlcb();\n    // 250 milliseconds pass\n    rlcb();\n    // 1 second passes\n    // alert box: BOO!\n    // state is now reset to what it was right after rlcb was defined\n\nThis is useful for defining a real time search box like Google's instant search, if you want it to be responsive but not spam your server with ridiculous numbers of requests.	463	rate_limited_callback	Calls a function after a specified delay, compressing frequent calls into one.	0
`rate_limited_callback(rate,cb)` returns a function which, when called, calls `cb()` after `rate` milliseconds, compressing nearby calls and only firing on the *last* one.  So for example:\n\n    var rlcb = rate_limited_callback(1000, function() { alert("Boo!" });\n    // 500 milliseconds pass\n    rlcb();\n    // 750 milliseconds pass\n    rlcb();\n    // 250 milliseconds pass\n    rlcb();\n    // 1 second passes\n    // alert box: BOO!\n    // state is now reset to what it was right after rlcb was defined\n\nThis is useful for defining a real time search box like Google's instant search, if you want it to be responsive but not spam your server with ridiculous numbers of requests.	464	rate_limited_callback	Calls a function after a specified delay, compressing frequent calls into one.	0
	465	unnamed		0
	467	realtime_input		0
	468	realtime_input	A jQuery input box which is suitable for "instant search" and related functionality.	0
`realtime_input(rate, cb)` returns a jQuery-ified DOM node which calls `cb` whenever the input box changes.  However, it waits `rate` milliseconds before calling `cb`, and if the input box changes again before `rate` milliseconds have passed, the timer will be reset.  So if someone is typing really fast into the input box, `cb` will not be called until they pause for at least `rate` milliseconds.	470	realtime_input	A jQuery input box which is suitable for "instant search" and related functionality.	0
	471	random_hex_string	Returns a randomly chosen hex string of a given length	0
`tabs` takes a list of tabs and their content (generators), and returns something like what you see below.  For example:\n\n    tabs([\n        { label: 'Foo', content: $('<b>FOO!</b>') },\n        { label: 'Bar', content: function() { \n              alert("Generating bar");\n              return $('<b>BAR!</b>');\n        } },\n    ])\n\nAs you can see, `content` can be a jQuery element or a function, which will be called *once* the first time the tab is accessed.\n\nThe CSS classes used by `tabs` follow:\n\n* `tabstrip`: the class of a table holding each tab (but not the content)\n* `content`: the class of the `div` holding each tab's content\n* `tabs`: the class of a `div` containing the entire suite: tabs and content together\n* `tab`: the class of each individual tab (a `td`)	480	tabs	Simple switchable tabs for HTML/jQuery	0
See [`language_patterns`](/137) for the supported languages and some insight into how they are chosen.	482	detect_language	Detects the programming language a string of source code comes from.	0
	486	language_list	Return the list of languages (in string form) supported by the CodeCatalog scanner	0
	487	language_list	The list of languages (in string form) supported by the CodeCatalog scanner	0
	490	unnamed		0
	492	keys		0
	493	keys	Returns the list of keys/properties in a javascript object.	0
    keys({ 'foo': 1, 'bar': 2 })\n    // returns [ 'foo', 'bar' ]	494	keys	Returns the list of keys/properties in a javascript object.	0
Example:\n\n    keys({ 'foo': 1, 'bar': 2 })\n    // returns [ 'foo', 'bar' ]	495	keys	Returns the list of keys/properties in a javascript object.	0
`tabs` takes a list of tabs and their content (generators), and returns something like what you see below (**Active** and **History**).  For example:\n\n    tabs([\n        { label: 'Foo', content: $('<b>FOO!</b>') },\n        { label: 'Bar', content: function() { \n              alert("Generating bar");\n              return $('<b>BAR!</b>');\n        } },\n    ])\n\nAs you can see, `content` can be a jQuery element or a function, which will be called *once* the first time the tab is accessed.\n\nThe CSS classes used by `tabs` follow:\n\n* `tabstrip`: the class of a table holding each tab (but not the content)\n* `content`: the class of the `div` holding each tab's content\n* `tabs`: the class of a `div` containing the entire suite: tabs and content together\n* `tab`: the class of each individual tab (a `td`)	499	tabs	Simple switchable tabs for HTML/jQuery	0
	500	PriorityQueue	A queue that maintains a collection of elements such that the head element is always the smallest.	0
	501	Scheduler	Schedule jobs based on time.	0
	503	Scheduler	Sorts timestamped jobs and executes them in order, when they should be fired.	0
	507	frobnicate2	Twice the frobnication!	1
Monkeypatch!	508	frobnicate	Hoobar frojingo.	1
`tabs` takes a list of tabs and their content (generators), and returns something like what you see below (**Active** and **History**).  For example:\n\n    tabs([\n        { label: 'Foo', content: $('<b>FOO!</b>') },\n        { label: 'Bar', content: function() { \n              alert("Generating bar");\n              return $('<b>BAR!</b>');\n        } },\n    ])\n\nAs you can see, `content` can be a *jQuery* element or a function, which will be called *once* the first time the tab is accessed.\n\nThe CSS classes used by `tabs` follow:\n\n* `tabstrip`: the class of a table holding each tab (but not the content)\n* `content`: the class of the `div` holding each tab's content\n* `tabs`: the class of a `div` containing the entire suite: tabs and content together\n* `tab`: the class of each individual tab (a `td`)	509	tabs	Simple switchable tabs for HTML/jQuery	0
`maximum_by(measure, xs)` finds the element `x` of `xs` with the highest value of `measure(x)`.  In the case of ties, it takes the first one.  For example:\n\n    >>> maximum_by(len, ['my', 'spoon', 'is', 'too', 'big'])\n    'spoon'	513	maximum_by	Finds the maximum of a list of elements using a measure function.	0
	517	simple_prime_checker	Primitive prime checker	0
	520	unique	Remove duplicates in a list	0
	522	Data.Set	The standard Haskell Data.Set	0
	524	Data.Set	The standard Haskell Data.Set module	0
See the [standard library documentation for Data.Set](http://www.haskell.org/ghc/docs/latest/html/libraries/containers-0.4.0.0/Data-Set.html>).	525	Data.Set	The standard Haskell Data.Set module	0
	530	rotate view	Rotate the view using OpenGL/GLUT	0
This is now about all you can do with a simplistic prime checker. It takes in an integer, returns False if it's below two, returns True if it's below four. Then, for any integers above four, it uses the concepts of factorization of integers to most quickly determine if the number has any non-trivial positive factors, returning False if so.	536	simple_prime_checker	Primitive prime checker	0
This is now about all you can do with a simplistic prime checker. It takes in an integer, returns False if it's below two, returns True if it's below four. Then, for any integers above four, it uses the concepts of factorization of integers and divisibility of possible primes to most quickly determine if the number has any non-trivial positive factors, returning False if so.	538	simple_prime_checker	Primitive prime checker	0
	540	$.log	simpler jquery debugging	0
CodeCatalog Snippet http://codecatalog.net/199/541/\nIf you have a selector chain, like:\n\n   $('#articles').find('a.active').parent().somethingSomething()\n\nAnd one of the calls in it is returning an empty collection, you could stick\nthe "log()" call in between:\n\n   $('#articles').find('a.active').log().parent().somethingSomething()\n\nThis will not modify the original chain, but will log the intermediate\nresult to the console, and it's simple to add and remove.\n	542	$.log	simpler jquery debugging	0
If you have a selector chain, like this one:\n\n    $('#articles').find('a.active').parent().somethingSomething()\n\nAnd one of the calls in it is returning an empty collection, you could stick\nthe "log()" call in between:\n\n    $('#articles').find('a.active').log().parent().somethingSomething()\n\nThis will not modify the original chain, but will log the intermediate\nresult to the console, and it's simple to add and remove.\n	543	$.log	simpler jquery debugging	0
	546	simple_prime_factorizer	Primitive factorizer	0
	550	simple_lowest_factor	Returns lowest prime factor, one if number is one	0
Returns the lowest prime factor of an integer. If n is prime, zero, or one, it returns n.\n\nNB: Instead of simple\\_prime\\_checker, this could be used with a condtional, such as: </br>\nif simple\\_lowest\\_factor(n) == n: do_stuff()	553	simple_lowest_factor	Returns lowest prime factor, one if number is one	0
Returns the lowest prime factor of an integer. If n is prime, zero, or one, it returns n.\n\nNB: Instead of simple\\_prime\\_checker, this could be used with a condtional, such as: </br>\nif simple\\_lowest\\_factor(n) == n: do_stuff()	554	simple_lowest_factor	Returns lowest prime factor	0
`collatz(n)` iterates the [Collatz sequence][1] starting at *n*, and returns the number of steps required in order for the sequence to converge to 1 (defined such that `collatz(1)=0`).  \n\n  [1]: http://en.wikipedia.org/wiki/Collatz_sequence	570	simple_collatz	Collatz checker which counts steps	0
`collatz(n)` iterates the [Collatz sequence][1] starting at *n*, and returns the number of steps required in order for the sequence to converge to 1 (defined such that `collatz(1)=0`).  *n* must be positive.  It is conjectured but not proven that this function always terminates. \n\n  [1]: http://en.wikipedia.org/wiki/Collatz_sequence	571	simple_collatz	Collatz checker which counts steps	0
`collatz(n)` iterates the [Collatz sequence][1] starting at *n*, and returns the number of steps required in order for the sequence to converge to 1 (defined such that `collatz(1)=0`).  *n* must be positive.  It is conjectured but not proven that this function always terminates. \n\n  [1]: http://en.wikipedia.org/wiki/Collatz_sequence	573	collatz	Collatz checker which counts steps	0
`collatz(n)` iterates the [Collatz sequence][1] starting at *n*, and returns the number of steps required in order for the sequence to converge to 1.  *n* must be positive.  It is conjectured but not proven that this function always reaches 1. \n\n  [1]: http://en.wikipedia.org/wiki/Collatz_sequence	578	collatz	Collatz checker which counts steps	0
`collatz(n)` iterates the [Collatz sequence][1] starting at *n*, and returns the number of steps required in order for the sequence to converge to 1. *n* must be a positive integer. It is conjectured but not proven that this function always reaches 1. \n\n  [1]: http://en.wikipedia.org/wiki/Collatz_sequence	579	collatz	Collatz checker which counts steps	0
`unique` takes a list and returns a list with all duplicate elements removed. There is no stability guarantee: the elements in the returned list could be in any order.	582	unique	Remove duplicates in a list	0
`unique` takes a list and returns a list with all duplicate elements removed. There is no stability guarantee: the elements in the returned list could be in any order.\n\n    >>> unique([3,1,4,1,5,9,2,6,5,3,5])\n    [1, 2, 3, 4, 5, 6, 9]    # not necessarily in sorted order either	584	unique	Remove duplicates in a list	0
This code is a quick way to put up a 3d-object on the screen using OpenGL/GLUT and letting the user rotate it. Dragging the mouse adds a rotation to the modelview matrix. To use it, add\n\n    glutMouseFunc(mouse);\n\nto your initialization code.\n	585	rotate view	Rotate the view using OpenGL/GLUT	0
	587	Data.List	The Haskell standard list library	0
See the [standard library documentation for Data.List](http://www.haskell.org/ghc/docs/latest/html/libraries/base-4.3.1.0/Data-List.html).	589	Data.List	The Haskell standard list library	0
	593	bogo sort	A sort which works by the principle of randomly swapping the numbers until they are correctly sorted. 	0
[Bogosort][1] is a sorting routine with *O(n)* space complexity and *&Omega;(n)* best case performace.  Also it has *O(n n!)* average case performance and no worst case performance, although it will [almost surely][2] finish eventually.\n\n  [1]: http://en.wikipedia.org/wiki/Bogosort\n  [2]: http://en.wikipedia.org/wiki/Almost_surely	596	bogo sort	A sort which works by the principle of randomly swapping the numbers until they are correctly sorted. 	0
	597	in order	Checks whether a list of elements is in sorted order	0
	599	in order	Checks whether a list of elements is in ascending sorted order	0
[Bogosort][1] is a sorting routine with *O(n)* space complexity and *O(n)* best case performace.  Also it has *O(n n!)* average case performance and no worst case performance, although it will [almost surely][2] finish eventually.\n\n  [1]: http://en.wikipedia.org/wiki/Bogosort\n  [2]: http://en.wikipedia.org/wiki/Almost_surely	601	bogo sort	A sort which works by the principle of randomly swapping the numbers until they are correctly sorted. 	0
	602	in place knuth shuffle	Randomly shuffles a list of elements in place, so that all shuffles are equally likely	0
	607	Data.Function	Standard Haskell function combinators	0
	613	Data.Bits	Standard Haskell bit operations	0
See the [standard library documentation for Data.Bits](http://www.haskell.org/ghc/docs/latest/html/libraries/base-4.3.1.0/Data-Bits.html).	615	Data.Bits	Standard Haskell bit operations	0
	616	bits	Get the (little endian) list of bits encoding an integer	0
`bits` takes a nonnegative integer and returns the list of bits in its binary encoding, **from least to most significant**.  Note that this is backwards from the usual way that binary numbers are *written*, but it is often more convenient for working with them programmatically.\n\n    ghci> bits 6   -- 6 = 110 in binary\n    [False, True, True]	618	bits	Get the (little endian) list of bits encoding an integer	0
`bits` takes a nonnegative integer and returns the list of bits in its binary encoding, **from least to most significant**.  Note that this is backwards from the usual way that binary numbers are *written*, but it is often more convenient for working with them programmatically.\n\n    ghci> bits 6   -- 6 = 110 in binary\n    [False, True, True]	619	bits	Get the (little endian) list of bits encoding a nonnegative integer	0
`bits` takes a nonnegative integer and returns the list of bits in its binary encoding, **from least to most significant**.  Note that this is backwards from the usual way that binary numbers are *written*, but it is often more convenient for working with them programmatically.\n\n    ghci> bits 6   -- 6 = 110 in binary\n    [False, True, True]\n\nThe reason this spec does not handle negative integers is that we need to have a bit width to encode twos complement.  Eg. for *8-bit* integers, -2 = 11111110, but for *16-bit* integers, -2 = 1111111111111110.  However, because the least significant bits are returned first, we can do this in languages which can return infinite lists.  Eg. in Haskell:\n\n    bits> bits (-6)   -- 1...1010 in binary\n    [False, True, False, True, True, True, True, ...\n	620	bits	Get the (little endian) list of bits encoding a nonnegative integer	0
`bits` takes a nonnegative integer and returns the list of bits in its binary encoding, **from least to most significant**.  Note that this is backwards from the usual way that binary numbers are *written*, but it is often more convenient for working with them programmatically.\n\n    ghci> bits 6   -- 6 = 110 in binary\n    [False,True,True]\n\nThe reason this spec does not handle negative integers is that we need to have a bit width to encode twos complement.  Eg. for *8-bit* integers, -2 = 11111110, but for *16-bit* integers, -2 = 1111111111111110.  However, because the least significant bits are returned first, we can do this in languages which can return infinite lists.  Eg. in Haskell:\n\n    bits> bits (-6)   -- 1...1010 in binary\n    [False,True,False,True,True,True,True,...\n	621	bits	Get the (little endian) list of bits encoding a nonnegative integer	0
	622	Data.Map	Standard Haskell finite mapping (aka. hash, associative array)	0
	696	unnamed		0
See the [standard library documentation for Data.Map](http://www.haskell.org/ghc/docs/latest/html/libraries/containers-0.4.0.0/Data-Map.html).	624	Data.Map	Standard Haskell finite mapping (aka. hash, associative array)	0
	625	character substitute	Substitute a string by a character-to-character map	0
`charSubst m s` substitutes each character in `s` according to the map `m`.  If a character in `s` does not occur in `m`, it passes through unmodified.\n\n    ghci> charSubst (Data.Map.fromList [('x', 'y'), ('y', 'z')] "xyzzyfoo"\n    "yzzzzfoo"\n	627	character substitute	Substitute a string by a character-to-character map	0
`bits` takes a nonnegative integer and returns a sequence of bits in its binary encoding, **from least to most significant**.  Note that this is backwards from the usual way that binary numbers are *written*, but it is often more convenient for working with them programmatically.\n\n    ghci> bits 6   -- 6 = 110 in binary\n    [False,True,True]\n\nThe reason this spec does not handle negative integers is that we need to have a bit width to encode twos complement.  Eg. for *8-bit* integers, -2 = 11111110, but for *16-bit* integers, -2 = 1111111111111110.  However, because the least significant bits are returned first, we can do this in languages which can return infinite lists.  Eg. in Haskell:\n\n    bits> bits (-6)   -- 1...1010 in binary\n    [False,True,False,True,True,True,True,...\n	630	bits	Get the (little endian) list of bits encoding a nonnegative integer	0
Taken from [this StackOverflow answer](http://stackoverflow.com/questions/985272/jquery-selecting-text-in-an-element-akin-to-highlighting-with-your-mouse).	633	select text	Selects the text in a DOM node (jQuery)	0
If you have a selector chain, like this one:\n\n    $('#articles').find('a.active').parent().somethingSomething()\n\nAnd one of the calls in it is returning an empty collection, you could stick\nthe "log()" call in between:\n\n    $('#articles').find('a.active').log().parent().somethingSomething()\n\nThis will not modify the original chain, but will log the intermediate\nresult to the console, and it's simple to add and remove.\n	636	$.log	Simple jQuery debugging	0
Returns the lowest prime factor of an integer. If n is prime, zero, or one, it returns n.\n\nNB: Instead of simple\\_prime\\_checker, this could be used with a condtional, such as: </br>\nif simple\\_lowest\\_factor(n) == n: do_stuff()	641	lowest_factor	Returns lowest prime factor	0
	642	prime_factorizer	Primitive factorizer	0
This is now about all you can do with a simplistic prime checker. It takes in an integer, returns False if it's below two, returns True if it's below four. Then, for any integers above four, it uses the concepts of factorization of integers and divisibility of possible primes to most quickly determine if the number has any non-trivial positive factors, returning False if so.	643	prime_checker	Primitive prime checker	0
Returns the lowest prime factor of an integer. If n is prime, zero, or one, it returns n.\n\nNB: Instead of simple\\_prime\\_checker, this could be used with a condtional, such as: </br>\nif simple\\_lowest\\_factor(n) == n: do_stuff()	644	lowest factor	Returns lowest prime factor	0
This is now about all you can do with a simplistic prime checker. It takes in an integer, returns False if it's below two, returns True if it's below four. Then, for any integers above four, it uses the concepts of factorization of integers and divisibility of possible primes to most quickly determine if the number has any non-trivial positive factors, returning False if so.	646	is prime	Primitive prime checker	0
This is now about all you can do with a simplistic prime checker. It takes in an integer, returns False if it's below two, returns True if it's below four. Then, for any integers above four, it uses the concepts of factorization of integers and divisibility of possible primes to most quickly determine if the number has any non-trivial positive factors, returning False if so.	647	is prime	Checks whether a number is prime	0
	649	prime factorization	Primitive factorizer	0
	650	prime factorization	Returns the sequence of primes that divides an integer	0
	653	indices	Finds the sequence of indices at which an element occurs in a list	0
	655	check langford	Checks whether a sequence is a valid langford pairing	0
A [Langford pairing] is a permutation of the sequence of 2n numbers 1, 1, 2, 2, ..., n, n in which the two ones are one unit apart, the two twos are two units apart, and more generally the two copies of each number *k* are *k* units apart.\n\n`checkLangford` checks whether a list of integers with even length is a valid langford pairing.\n\n  [Langford pairing]: http://en.wikipedia.org/wiki/Langford_pairing	658	check langford	Checks whether a sequence is a valid langford pairing	0
`indices x xs` returns the ascending, zero-based sequence of indices at which `x` occurs in `xs`.  For example:\n\n    ghci> indices 3 [3,1,4,1,5,9,2,6,5,3,5]\n    [0,9]	659	indices	Finds the sequence of indices at which an element occurs in a list	0
A [Langford pairing] is a permutation of the sequence of 2n numbers 1, 1, 2, 2, ..., n, n in which the two ones are one unit apart, the two twos are two units apart, and more generally the two copies of each number *k* are *k* units apart.\n\nFor example, the langford pairing for *n=3* is given by:\n\n    [2,3,1,2,1,3]\n         ^.1.^\n     ^..2..^\n       ^...3...^\n\n`checkLangford` checks whether a list of integers with even length is a valid langford pairing.\n\n  [Langford pairing]: http://en.wikipedia.org/wiki/Langford_pairing	660	check langford	Checks whether a sequence is a valid langford pairing	0
A [Langford pairing] is a permutation of the sequence of 2n numbers 1, 1, 2, 2, ..., n, n in which the two ones are one unit apart, the two twos are two units apart, and more generally the two copies of each number *k* are *k* units apart.\n\nFor example, the langford pairing for *n=3* is given by:\n\n    2 3 1 2 1 3 \n        ^.1.^\n    ^..2..^\n      ^...3...^\n\n`checkLangford` checks whether a list of integers with even length is a valid langford pairing.\n\n  [Langford pairing]: http://en.wikipedia.org/wiki/Langford_pairing	661	check langford	Checks whether a sequence is a valid langford pairing	0
`maximum_by(f, xs)` finds the first element `x` in `xs` for which `f(x)` achieves its greatest value.  For example:\n\n    >>> maximum_by(lambda x: x*x, [-1,3,-5])\n    -5	664	maximum_by	Finds the maximum of a list by a measure function	0
Duplicate of [maximum_by](/19/).	667	maximum_by	Finds the maximum of a list by a measure function	0
Duplicate of [maximum_by](/19/).	668	maximum_by	Finds the maximum of a list by a measure function	1
	670	edit description field	A wiki-widget for a user to describe an edit.	0
Insert Summary Here.	674	edit description field	A wiki-widget for a user to describe an edit.	0
A text field similar (read: identical) to the one below if you click "edit".	676	edit description field	A wiki-widget for a user to describe an edit.	0
	680	delegate method	constructs a function that will call a method on an object	0
A text field similar (read: identical) to the one that says "Edit summary" below if you click "edit".	677	edit description field	A wiki-widget for a user to describe an edit.	0
This function is useful when you want to say, for example:\n\n    container.val = input.val;\n\nBut because of subtleties of javascript this doesn't work.  If someone calls `container.val()`, then it won't be the same as calling `input.val()`.  Rather, `input`'s `val` will be called, but with its `this` set to `container`.  The likely result is some kind of bizarre error.  Use this function to get the desired behavior:\n\n    container.val = delegate_method(input, 'val');\n\nor\n\n    container.val = delegate_method(input, input.val);\n\nNow when `container.val()` is called, it will be *exactly* the same as if they had called `input.val()`.	682	delegate method	constructs a function that will call a method on an object	0
A text field similar (read: identical) to the one that says "Edit summary" below if you click "edit".	685	edit description field	A widget for a user to describe an edit on a wiki	0
	688	language to line comment map	A dictionary mapping language names to their single line comment strings.	0
We need to take a little time to set up the problem.  We have a set of *types* and *objects*.  An *object* is a member of exactly one *type*, its "existence" may depend on the existence of several other types, and it has a *weight*.  Here is an example problem set up:\n\n    Object  |    Type     |   Weight   |  Dependencies\n    --------+-------------+------------+--------------\n    Car     |  Transport  |   10       | Wheels,Engine\n    Truck   |  Transport  |   15       | Wheels,Engine\n    Tires   |  Wheels     |   2        | \n    Cubes   |  Wheels     |   500      |\n    v6      |  Engine     |   4        |\n    v8      |  Engine     |   6        |\n\n`dependency_search` tries to find a set of *objects* which satisfy a *type* with the least *weight*.   So it would find this solution if asked to search for `Transport`:\n\n    (Car, Wheels, v6)\n\nAlthough this example has a trivial dependency structure, this function works for arbitrary dependencies.  That is, if object `x` depends on types `B` and `C`, then if `x` appears in the solution, so must objects that satisfy `B` and `C`.\n\n**Parameters:**\n\n* `members`: a function taking a *type* and returning a collection of annotated objects of that type.  The each result of `members` should have the following fields:\n  * `weight`: the weight of choosing this object\n  * `deps`: a `frozenset` of types that this object depends on.\n  * `object`: the type you are using to represent objects -- can be whatever you want, it inhabits the returned list of objects.\n* `type`: the type the algorithm is trying to satisfy; e.g. `Transport` in the example above.\n\nThe concrete representation of types may be any hashable type, and the concrete representation of objects may be any type whatsoever.\n\nIf no solution could be found, returns `None`.	689	dependency search	Searches for a set of objects that satisfies simple dependency constraints.	0
	694	simple select	Creates a simple HTML dropdown selector given a list of options.	0
This:\n\n    simple_select(["foo", "bar", "baz"])\n\nWill create a jQuery object that, when placed in the page, will behave like this HTML:\n\n    <select>\n     <option value="foo">foo</option>\n     <option value="bar">bar</option>\n     <option value="baz">baz</option>\n    </select>\n\nCalling `val()` on the result will give you the currently selected option's value.	695	simple select	Creates a simple HTML dropdown selector given a list of options.	0
	698	lazy highlight element		0
`lazy_highlight_element` takes a 	699	lazy highlight element	Highlights an element using SHJS using a dynamically loaded syntax file.	0
`lazy_highlight_element(prefix, suffix, element, language)` syntax-highlights a `<pre>` element using [SHJS] using a lazily loaded syntax file.  `prefix` and `suffix` define the location that you keep your syntax files.  For example, on CodeCatalog, the javascript syntax file is located at `/static/shjs/lang/sh_javascript.min.js`, so we set `prefix` to `"/static/shjs/lang/"` and `suffix` to `".min.js"`.  `element` is the DOM `<pre>` element to highlight, and `language` is the name of the language in all lowercase (see the SHJS syntax files for standard language names).\n\n  [SHJS]: http://shjs.sourceforge.net/	700	lazy highlight element	Highlights an element using SHJS using a dynamically loaded syntax file.	0
`lazy_highlight_element(prefix, suffix, element, language)` syntax-highlights a `<pre>` element using [SHJS] using a lazily loaded syntax file.  `prefix` and `suffix` define the location that you keep your syntax files.  For example, on CodeCatalog, the javascript syntax file is located at `/static/shjs/lang/sh_javascript.min.js`, so we set `prefix` to `"/static/shjs/lang/"` and `suffix` to `".min.js"`.  `element` is the DOM `<pre>` element to highlight, and `language` is the name of the language in all lowercase (see the SHJS syntax files for standard language names).\n\nThis code depends on `sh_main.js` having been loaded.  In particular it relies on the global `sh_languages` dictionary and the `sh_highlightElement` function.\n\n  [SHJS]: http://shjs.sourceforge.net/	701	lazy highlight element	Highlights an element using SHJS using a dynamically loaded syntax file.	0
`lazy_highlight_element(prefix, suffix, element, language)` syntax-highlights a `<pre>` element using [SHJS] using a lazily loaded syntax file.  `prefix` and `suffix` define the location that you keep your syntax files.  For example, on CodeCatalog, the javascript syntax file is located at `/static/shjs/lang/sh_javascript.min.js`, so we set `prefix` to `"/static/shjs/lang/"` and `suffix` to `".min.js"`.  `element` is the DOM `<pre>` element to highlight, and `language` is the name of the language in all lowercase (see the SHJS syntax files for standard language names).\n\nThis code depends jQuery and `sh_main.js` having been loaded.  In particular it relies on the global `sh_languages` dictionary and the `sh_highlightElement` function.\n\n  [SHJS]: http://shjs.sourceforge.net/	702	lazy highlight element	Highlights an element using SHJS using a dynamically loaded syntax file.	0
	703	unnamed		0
	705	escape html		0
`escape_html` takes a s	706	escape html	Escapes an HTML string so it can be rendered literally inside a <pre>.	0
`escape_html` takes an HTML string like\n\n    <script>alert("ANNOYING & STUPID")</script>\n\nAnd escapes all the HTML characters so it can be rendered literally inside a `<pre>`:\n\n    &lt;script&gt;alert("ANNOYING &amp; STUPID")&lt;/script&gt;	707	escape html	Escapes an HTML string so it can be rendered literally inside a <pre>.	0
	708	unnamed		0
	710	table row		0
	711	table row	Creates a <tr> element with a <td> for each argument	0
	712	table row	Creates an HTML <tr> element with a <td> for each argument	0
	714	unnamed		0
	716	text node		0
	717	text node	Creates an HTML text node with the text given by its argument	0
`tabs` takes a list of tabs and their content (generators), and returns something like what you see below (**Active** and **History**).  For example:\n\n    tabs([\n        { label: 'Foo', content: $('<b>FOO!</b>') },\n        { label: 'Bar', content: function() { \n              alert("Generating bar");\n              return $('<b>BAR!</b>');\n        } },\n    ])\n\nAs you can see, `content` can be a *jQuery* element or a function, which will be called *once* the first time the tab is accessed.\n\nThe CSS classes used by `tabs` follow:\n\n* `tabstrip`: the class of a table holding each tab (but not the content)\n* `content`: the class of the `div` holding each tab's content\n* `tabs`: the class of a `div` containing the entire suite: tabs and content together\n* `tab`: the class of each individual tab (a `span`)	719	tabs	Simple switchable tabs for HTML/jQuery	0
`tabs` takes a list of tabs and their content (generators), and returns something like what you see below (**Active** and **History**).  For example:\n\n    tabs([\n        { label: 'Foo', content: $('<b>FOO!</b>') },\n        { label: 'Bar', content: function() { \n              alert("Generating bar");\n              return $('<b>BAR!</b>');\n        } },\n    ])\n\nAs you can see, `content` can be a *jQuery* element or a function, which will be called *once* the first time the tab is accessed, and cached for when the tab is accessed again.\n\nThe CSS classes used by `tabs` follow:\n\n* `tabstrip`: the class of a table holding each tab (but not the content)\n* `content`: the class of the `div` holding each tab's content\n* `tabs`: the class of a `div` containing the entire suite: tabs and content together\n* `tab`: the class of each individual tab (a `span`)	720	tabs	Simple switchable tabs for HTML/jQuery	0
`tabs` takes a list of tabs and their content (generators), and returns something like what you see below (**Active** and **History**).  For example:\n\n    tabs([\n        { label: 'Foo', content: $('<b>FOO!</b>') },\n        { label: 'Bar', content: function() { \n              alert("Generating bar");\n              return $('<b>BAR!</b>');\n        } },\n    ])\n\nAs you can see, `content` can be a *jQuery* element or a function. If it is a function, it will be called *once* the first time the tab is accessed and cached for when the tab is accessed again.\n\nThe CSS classes used by `tabs` follow:\n\n* `tabstrip`: the class of a table holding each tab (but not the content)\n* `content`: the class of the `div` holding each tab's content\n* `tabs`: the class of a `div` containing the entire suite: tabs and content together\n* `tab`: the class of each individual tab (a `span`)	721	tabs	Simple switchable tabs for HTML/jQuery	0
	722	unnamed		0
	724	please copy me on click		0
	725	please copy me on click	Constructs an element that replaces itself with a selected textarea when clicked	0
`iterate_adjacent(array, default, func)` iterates adjacent pairs of elements of `array` by calling `func(array[i], array[i+1])` for each `i`.  When `i` is the last index of the array, calls `func(i, default)`.  So `func` will be called `array.length` times.  Note that this is different from a popular variant in which `func` is called `array.length-1` times, which has no default element.\n\n`iterate_adjacent` is a side-effectful function: it has no return value, `func` is expected to perform side effects.\n\nExample:\n\n    var diffs = [];\n    iterate_adjacent(strings, '', function(str, nextStr) {\n        diffs.push(compute_diff(str, nextStr));\n    });\n\nThis code populates `diffs` with the successive differences between the strings in `strings` (assuming a suitable definition for `compute_diff`.	755	iterate adjacent	Iterates over the elements of an array together with their successors.	0
	842	make autocomplete	Create a jquery autocomplete input widget with support for custom formatting and stylizing.	0
This is a good way to say "please copy this to the clipboard" from a browser.  First, note that it is purely functional, so you have to do something with the result:\n\n    var result = please_copy_me_on_click($(someElement), "copy me!")\n\nThen put `result` somewhere in the DOM.  When `result` is clicked, it `someElement` will replace itself with a textarea containing the text "copy me", which will be selected, so all the user has to do is to push Ctrl-C (or however his OS does it) and the text will be copied.\n\nYou can see it in action if you click the code implementing it below (it is used in CodeCatalog :-)\n\nNote that the `element` argument has to be a jQuery object. Also note the textarea is given no styling, so it will probably look wrong unless you mess with the CSS.  For example:\n\n    // in the style section\n    .foo * { width: 750px; background: white }\n\nThen, using the code above:\n\n    result.addClass('foo');\n\nNow the textarea will be the same width as whatever `someElement` is given to work with.	726	please copy me on click	Constructs an element that replaces itself with a selected textarea when clicked	0
	728	unnamed		0
	730	count lines		0
	731	count lines	Counts the number of lines in a string	0
	734	unnamed		0
	736	make pre		0
	737	make pre	Makes an HTML <pre> element containing some text.	0
Internet explorer does something "normalizes away" the whitespace in a `<pre>` element when you set its contents with `.innerHtml` (and therefore when you use jQuery's `.text()` method).  `make_pre` works around that normalization to give you a pre containing some text in a cross-browser way.	738	make pre	Makes an HTML <pre> element containing some text.	0
Internet Explorer "normalizes away" the whitespace in a `<pre>` element when you set its contents with `.innerHtml` (and therefore when you use jQuery's `.text()` method).  `make_pre` works around that normalization to give you a pre containing some text in a cross-browser way.	739	make pre	Makes an HTML <pre> element containing some text.	0
	741	unnamed		0
	743	toggle button		0
	744	toggle button	Creates a button that toggles between two states of another element	0
`toggle_button(text, text_alt, element, element_alt)` returns a two element array, `[div, btn]`.   `div` is initially inhabited by `element` and the button initially has text `text`.  When the button is pressed, `div` now shows `element_alt` and the button shows `text_alt`.  If the button is pressed again, it switches back to the initial state.\n\n`element_alt` can be a function, in which case it is called once when the button is first pressed, and its result is used as the alternate element.  This alternate element is cached for future uses of that state (e.g. pressing the button 3 times will still only call the function once).\n\n`element` and `element_alt` are required to be jQuery objects.  `div` and `btn` will be jQuery objects.	745	toggle button	Creates a button that toggles between two states of another element	0
`lazy_highlight_element(prefix, suffix, element, language)` syntax-highlights a `<pre>` element using the [SHJS] library with a lazily loaded syntax file.  `prefix` and `suffix` define the location that you keep your syntax files.  For example, on CodeCatalog, the javascript syntax file is located at `/static/shjs/lang/sh_javascript.min.js`, so we set `prefix` to `"/static/shjs/lang/"` and `suffix` to `".min.js"`.  `element` is the DOM `<pre>` element to highlight, and `language` is the name of the language in all lowercase (see the SHJS syntax files for standard language names).\n\nThis code depends jQuery and `sh_main.js` having been loaded.  In particular it relies on the global `sh_languages` dictionary and the `sh_highlightElement` function.\n\n  [SHJS]: http://shjs.sourceforge.net/	747	lazy highlight element	Highlights an element using SHJS using a dynamically loaded syntax file.	0
`lazy_highlight_element(prefix, suffix, element, language)` syntax-highlights a `<pre>` element using the [SHJS] library with a lazily loaded syntax file.  `prefix` and `suffix` define the location where you keep your syntax files.  For example, on CodeCatalog, the javascript syntax file is located at `/static/shjs/lang/sh_javascript.min.js`, so we set `prefix` to `"/static/shjs/lang/"` and `suffix` to `".min.js"`.  `element` is the DOM `<pre>` element to highlight, and `language` is the name of the language in all lowercase (see the SHJS syntax files for standard language names).\n\nThis code depends jQuery and `sh_main.js` having been loaded.  In particular it relies on the global `sh_languages` dictionary and the `sh_highlightElement` function.\n\n  [SHJS]: http://shjs.sourceforge.net/	748	lazy highlight element	Highlights an element using SHJS using a dynamically loaded syntax file.	0
`lazy_highlight_element(prefix, suffix, element, language)` syntax-highlights a `<pre>` element using the [SHJS] library with a lazily loaded syntax file.  `prefix` and `suffix` define the location where you keep your syntax files.  For example, on CodeCatalog, the javascript syntax file is located at `/static/shjs/lang/sh_javascript.min.js`, so we set `prefix` to `"/static/shjs/lang/"` and `suffix` to `".min.js"`.  `element` is the DOM `<pre>` element to highlight, and `language` is the name of the language in all lowercase (see the SHJS syntax files for standard language names).\n\nThis code depends jQuery and `sh_main.js` having been loaded.  In particular it relies on the global `sh_languages` dictionary and the `sh_highlightElement` function.\n\n  [SHJS]: http://shjs.sourceforge.net/	749	lazy highlight element	Highlights an element using SHJS with a dynamically loaded syntax file.	0
	750	iterate adjacent		0
	752	iterate adjacent	Iterates over the elements of an array together with their successors.	0
`iterate_adjacent(array, default, func)` iterates adjacent pairs of elements of `array` by calling `func(array[i], array[i+1])` for each `i`.  When `i` is the last index of the array, calls `func(i, default)`.  So `func` will be called `array.length` times.  Note that this is different from a popular variant in which `func` is called `array.length-1` times, which has no default element.\n\nExample:\n\n    var diffs = [];\n    iterate_adjacent(strings, '', function(str, nextStr) {\n        diffs.push(compute_diff(str, nextStr));\n    });\n\nThis code populates `diffs` with the successive differences between the strings in `strings` (assuming a suitable definition for `compute_diff`.	754	iterate adjacent	Iterates over the elements of an array together with their successors.	0
	841	make autocomplete	Convert a given jquery node into an autocomplete-style input box, supporting custom key / value pairs.	0
	848	pairs	Generates an infinite list of all pairs of the elements of two infinite lists.	0
	850	diagonal	Generate a list of all elements in a (possibly) infinite list of lists	0
	905	unnamed		0
	907	format currency USD		0
	908	format currency USD	Takes a number and returns it formatted as a number of US dollars	0
For example:  `formatCurrencyUSD(3145.726) == "$3,145.73'`.	909	format currency USD	Takes a number and returns it formatted as a number of US dollars	0
`iterate_adjacent(array, default, func)` iterates adjacent pairs of elements of `array` by calling `func(array[i], array[i+1])` for each `i`.  When `i` is the last index of the array, calls `func(i, default)`.  So `func` will be called `array.length` times.  Note that this is different from a popular variant in which `func` is called `array.length-1` times, which has no default element.\n\n`iterate_adjacent` is a side-effectful function: it has no return value, `func` is expected to perform side effects.\n\nExample:\n\n    var diffs = [];\n    iterate_adjacent(strings, '', function(str, nextStr) {\n        diffs.push(compute_diff(str, nextStr));\n    });\n\nThis code populates `diffs` with the successive differences between the strings in `strings` (assuming a suitable definition for `compute_diff`).	757	iterate adjacent	Iterates over the elements of an array together with their successors.	0
	758	dynamic link element	The raw element for a dynamic link.	0
	760	dynamic link	Creates an HTML link that executes a javascript action when clicked.	0
	762	toggle element	Create toggle behavior using a given jquery element.	0
	767	screen offset	The offset of a DOM node relative to the screen.	0
	769	preserving screen position	Maintain the same screen position relative to an element while executing a function that presumably modifies the content on the page.	0
`preserving_screen_position(element, mods)` executes the function `mods` while trying to maintain the position of `element` on the screen.  `mods()` can move things around in the DOM, add, hide, and delete elements, and `element` will be in the same position on the *screen* as it was before `mods()` was executed.  If `element` is deleted during `mods()`, it is reasonable to expect the universe to implode.	779	preserving screen position	Maintain the same screen position relative to an element while executing a function that presumably modifies the content on the page.	0
	780	screen offset	The offset of a DOM node relative to the upper left of the screen, in pixels.	0
	781	foreach	For each element in the given sequence, call body with the element as a parameter.	0
	783	count equal	Counts the number of elements of a list which are equal to some other element of the list	0
	784	count equal	Counts the number of elements of a list which are equal to some other element of the list	0
For example:\n\n    ghci> countEqual [1,2,2,4,7,7,7]\n    5	787	count equal	Counts the number of elements of a list which are equal to some other element of the list	0
	788	count equal	Counts the number of elements of a list which are equal to some other element of the list	1
Duplicate of [count equal](http://www.codecatalog.net/280/).	789	count equal	Counts the number of elements of a list which are equal to some other element of the list	1
	790	replace nth	Returns a list with the nth element replaced with a given element	0
`replaceNth(n,x,xs)` yields `xs` with its `n`th index replaced by `x` if `n` was in range, and `xs` otherwise.   *n* is assumed to be a nonnegative integer.\n\nFor example:\n\n    ghci> replaceNth 4 42 [0..9]\n    [0,1,2,3,42,5,6,7,8,9]\n   \n    ghci> replaceNth 4 42 [0,1,2]\n    [0,1,2]\n	794	replace nth	Returns a list with the nth element replaced with a given element	0
	795	timestamp to string	Return the string representation of a timestamp object.	0
	797	timestamp to string	Return the string representation of a timestamp object.	0
	799	timestamp to string	Return the string representation of a timestamp object.	0
	801	timestamp to string	Return the string representation of a timestamp object.	0
	803	timestamp to string	Return the string representation of a timestamp object.	0
	805	timestamp to string	Return the string representation of a timestamp object.	0
	807	timestamp to string	Return the string representation of a timestamp object.	0
	809	timestamp to string	Return the string representation of a timestamp object.	1
	810	timestamp to string	Return the string representation of a timestamp object.	1
	811	timestamp to string	Return the string representation of a timestamp object.	1
	812	timestamp to string	Return the string representation of a timestamp object.	1
	813	timestamp to string	Return the string representation of a timestamp object.	1
	814	timestamp to string	Return the string representation of a timestamp object.	1
	824	make autocomplete kv	Convert a given jquery node into an autocomplete-style input box, supporting custom key / value pairs.	0
	829	unnamed		1
	831	powerSet	The power set of a given list, e.g. powerSet [1,2,3] --> [[],[3],[2],[2,3],[1],[1,3],[1,2],[1,2,3]]. Code adapted from http://yubinkim.com/?p=87	0
	833	powerSet	The power set of a given list, e.g. powerSet [1,2,3] --> [[1],[2],[3],[1,2],[1,3],[2,3],[1,2,3]] or some permutation of it. 	0
	835	powerSet	The power set of a given list, e.g. powerSet [1,2,3] --> [[],[1],[2],[3],[1,2],[1,3],[2,3],[1,2,3]] or some permutation of it. 	0
`powerSet xs` takes a list `xs` and returns the collection of all ordered sublists of `xs`.  For example:\n\n    ghci> powerSet [1,2,3]\n    [[],[1],[2],[3],[1,2],[1,3],[2,3],[1,2,3]]\n\nThe order of results is not guaranteed.\n\nAdapted from [Yubin Kim's blog](http://yubinkim.com/?p=87).	836	powerSet	The power set of a given list, e.g. powerSet [1,2,3] --> [[],[1],[2],[3],[1,2],[1,3],[2,3],[1,2,3]] or some permutation of it. 	0
`powerSet xs` takes a list `xs` and returns the collection of all ordered sublists of `xs`.  For example:\n\n    ghci> powerSet [1,2,3]\n    [[],[1],[2],[3],[1,2],[1,3],[2,3],[1,2,3]]\n\nThe order of results is not guaranteed.\n\nAdapted from [Yubin Kim's blog](http://yubinkim.com/?p=87).	837	power set	The power set of a given list, e.g. powerSet [1,2,3] --> [[],[1],[2],[3],[1,2],[1,3],[2,3],[1,2,3]] or some permutation of it. 	0
`powerSet xs` takes a list `xs` and returns the collection of all ordered sublists of `xs`.  For example:\n\n    ghci> powerSet [1,2,3]\n    [[],[1],[2],[3],[1,2],[1,3],[2,3],[1,2,3]]\n\nThe order of results is not guaranteed.\n\nAdapted from [Yubin Kim's blog](http://yubinkim.com/?p=87).	838	power set	Finds the collection of all ordered sublists of a list.	0
`powerSet xs` takes a list `xs` and returns the collection of all ordered sublists of `xs`.  For example:\n\n    ghci> powerSet [1,2,3]\n    [[],[1],[2],[3],[1,2],[1,3],[2,3],[1,2,3]]\n\nThe order of results is not guaranteed (That is, the order of the elements of the outer list.  The inner lists will maintain the order from the input list; `[3,1,2]` will never occur in the output for this example).\n\nAdapted from [Yubin Kim's blog](http://yubinkim.com/?p=87).	840	power set	Finds the collection of all ordered sublists of a list.	0
	844	on enter	Fire an event on a jquery element when the enter key is pressed.	0
`diagonal` traverses all the elements of a two dimensional matrix by traversing the "negative diagonals".  If we are trying to traverse this matrix:\n\n    (0,0) (0,1) (0,2) ...\n    (1,0) (1,1) (1,2) ...\n    (2,0) (2,1) (2,2) ...\n    ...\n\nThe order traversed by `diagonal` will be:\n\n    (0,0) (0,1) (1,0) (0,2) (1,1) (2,0) (0,3) (1,2) (2,1) ...\n\nWhich can be seen as concatenating the diagonal "stripes":\n\n    (0,0)\n    (0,1) (1,0)\n    (0,2) (1,1) (2,0)\n    (0,3) (1,2) (2,1) (3,0)\n    ...\n\nSo even if `diagonal` is given a matrix infinite in both directions, it will still output every element in the matrix. \n\nIf it is not a perfect matrix, so some inner lists are of different lengths, then `diagonal` does a reasonable thing and still generates all the elements.	852	diagonal	Generate a list of all elements in a (possibly) infinite list of lists	0
`diagonal` traverses all the elements of a two dimensional matrix by traversing the "negative diagonals".  If we are trying to traverse this matrix:\n\n    (0,0) (0,1) (0,2) ...\n    (1,0) (1,1) (1,2) ...\n    (2,0) (2,1) (2,2) ...\n    ...\n\nThe order traversed by `diagonal` will be:\n\n    (0,0) (0,1) (1,0) (0,2) (1,1) (2,0) (0,3) (1,2) (2,1) ...\n\nWhich can be seen as concatenating the diagonal "stripes":\n\n    (0,0)\n    (0,1) (1,0)\n    (0,2) (1,1) (2,0)\n    (0,3) (1,2) (2,1) (3,0)\n    ...\n\nSo even if `diagonal` is given a matrix infinite in both directions, it will still output every element in the matrix. \n\nIf it is not a perfect matrix, so some inner lists are of different lengths, then `diagonal` does a reasonable thing and still generates all the elements.	853	diagonal	Generate a list of all elements in a (possibly infinite) list of lists	0
	855	pairs	Generates an infinite list of all pairs of the elements of two possibly infinite lists.	0
	856	pairs	Generates a list of all pairs of the elements of two possibly infinite lists.	0
	857	inits	Finds the list of all prefixes of a list	0
    ghci> inits [1..10]\n    [[],[1],[1,2],[1,2,3],[1,2,3,4],[1,2,3,4,5]]	859	inits	Finds the list of all prefixes of a list	0
    ghci> inits [1..5]\n    [[],[1],[1,2],[1,2,3],[1,2,3,4],[1,2,3,4,5]]	860	inits	Finds the list of all prefixes of a list	0
	861	tails	Finds the list of all tails (suffixes) of a list	0
    ghci> tails [1..5]\n    [[1,2,3,4,5],[2,3,4,5],[3,4,5],[4,5],[5],[]]	863	tails	Finds the list of all tails (suffixes) of a list	0
	864	partitions	Finds the list of all partitions of a list	0
`partitions` finds all the ways you can split a list `xs` into `ys` and `zs` such that `ys ++ zs = xs`. \n\n    ghci> mapM_ print $ partitions [1..4]\n    ([],[1,2,3,4])\n    ([1],[2,3,4])\n    ([1,2],[3,4])\n    ([1,2,3],[4])\n    ([1,2,3,4],[])	866	partitions	Finds the list of all partitions of a list	0
	867	unnamed		0
	869	unique id		0
	870	unique id	Allocates a (locally) unique ID	0
Each time `unique_id`, a distinct integer will be returned.  The distinctness guarantee is only valid for one "run" of the program -- the identifier is not globally unique.	871	unique id	Allocates a (locally) unique ID	0
	872	unnamed		0
	874	for kv		0
	876	for kv	Iterates over the keys and values of an object, ignoring prototype methods	0
	877	unnamed		0
	879	repeat string		0
	880	repeat string	Concatenate a string with itself a given number of times	0
`repeat_string(s,n)` produces the string `s + s + ... + s`, where `s` occurs `n` times.   For example:\n\n    node.js> repeat_string("foo", 5)\n    "foofoofoofoofoo"\n\nIf `n` is zero, then `repeat_string(s,n)` will produce the empty string.	881	repeat string	Concatenate a string with itself a given number of times	0
	883	unnamed		0
	885	terminal path		0
	886	terminal path	Given a tree, finds the shortest distance from the root to a descendant with no children.	0
In the call `terminal_path(tree, children)`, `tree` is a node (could be anything), and `children` is a function which takes a node and returns a list of nodes.  The call returns the shortest path from `tree` to one of its descendants with no children.	888	terminal path	Given a tree, finds the shortest distance from the root to a descendant with no children.	0
	892	unnamed		0
	894	object		0
	895	object	A convenient way to define javascript classes.	0
`object` shortens and encapsulates this pattern:\n\n    SomeClass = function(...) {...};\n    SomeClass.prototype.baz = function(...) {...};\n    SomeClass.prototype.quux = function(...) {...};\n\nThat can be written without repeating the name `SomeClass` so much, and more declaratively, as:\n\n    SomeClass = object({\n        init: function(...) {...},\n        baz:  function(...) {...},\n        quux: function(...) {...}\n    });\n\n`init` is a special key which maps to the `SomeClass` function itself.  All other methods map to `SomeClass.prototype`.	896	object	A convenient way to define javascript classes.	0
`object` shortens and encapsulates this pattern:\n\n    SomeClass = function(...) {...};\n    SomeClass.prototype.baz = function(...) {...};\n    SomeClass.prototype.quux = function(...) {...};\n\nThat can be written without repeating the name `SomeClass` so much, and more declaratively, as:\n\n    SomeClass = object({\n        init: function(...) {...},\n        baz:  function(...) {...},\n        quux: function(...) {...}\n    });\n\n`init` is a special key which maps to the `SomeClass` function itself.  All other methods map to `SomeClass.prototype`.  If `init` is not given, a default one that does nothing will be created.	897	object	A convenient way to define javascript classes.	0
	898	unnamed		0
	900	thunk		0
	901	thunk	Creates a nullary function which caches its result for future calls	0
A [thunk] is a "suspended computation", that is, a computation that is performed the first time it is needed and its result is cached for future uses.  It is the backbone of [lazy evaluation].  The `thunk` function implements it very simply.  Pass `thunk` a function `f`, and it returns another function which calls `f` the first time it is called.  For example:\n\n    var sum = thunk(function() {\n        var r = 0;\n        for (var i = 0; i < 1000000; i++) {\n            r += i;\n        }\n        return r;\n    });\n    \n    console.log(sum());  // computes a while, then 500000500000\n    console.log(sum());  // returns 500000500000 immediately\n\n  [thunk]: http://en.wikipedia.org/wiki/Thunk_%28functional_programming%29\n  [lazy evaluation]: http://en.wikipedia.org/wiki/Lazy_evaluation	902	thunk	Creates a nullary function which caches its result for future calls	0
`unique` takes a list and returns a list with all duplicate elements removed. There is no stability guarantee: the elements in the returned list could be in any order.\n\n    >>> unique([3,1,4,1,5,9,2,6,5,3,5])\n    [1, 2, 3, 4, 5, 6, 9]    # not necessarily in sorted order either	904	unique	Returns a list with duplicates removed	0
For example:  `formatCurrencyUSD(3145.726) == '$3,145.73'`.	910	format currency USD	Takes a number and returns it formatted as a number of US dollars	0
	913	unnamed		0
	915	read currency USD		0
	916	read currency USD	Takes a string formatted as US dollar currency and returns a floating point number of dollars.	0
Example: `readCurrencyUSD("$1,234.56") = 1234.56`.  Left inverse to [format currency USD](/335/).	917	read currency USD	Takes a string formatted as US dollar currency and returns a floating point number of dollars.	0
`rate_limited_callback(rate,cb)` returns a function which, when called, calls `cb()` after `rate` milliseconds, compressing nearby calls and only firing on the *last* one.  So for example:\n\n    var rlcb = rate_limited_callback(1000, function() { alert("Boo!" });\n    // 500 milliseconds pass\n    rlcb();\n    // 750 milliseconds pass\n    rlcb();\n    // 250 milliseconds pass\n    rlcb();\n    // 1 second passes\n    // alert box: BOO!\n    // state is now reset to what it was right after rlcb was defined\n\nThis is useful for defining a real time search box like Google's instant search, if you want it to be responsive but not spam your server with ridiculous numbers of requests.	918	rate limited callback	Calls a function after a specified delay, compressing frequent calls into one.	0
`maximum_by(measure, xs)` finds the element `x` of `xs` with the highest value of `measure(x)`.  In the case of ties, it takes the first one.  For example:\n\n    >>> maximum_by(len, ['my', 'spoon', 'is', 'too', 'big'])\n    'spoon'	920	maximum by	Finds the maximum of a list of elements using a measure function.	0
	923	split lines	Splits the given string into a list of lines	0
	926	zip	Form a list of pairs of corresponding elements from two lists	0
For example:\n\n    > zip([1,2,3],['a','b','c'])\n    [ [ 1, 'a' ], [ 2, 'b' ], [ 3, 'c' ] ]\n\nIn the case where the lists are different lengths, takes only those pairs where there would be an element from each; i.e. the minimum of the two lengths.	929	zip	Form a list of pairs of corresponding elements from two lists	0
	930	sub dictionary	Checks whether all key-value pairs in one dictionary are present in another	0
Example:\n\n\n    > sub_dictionary({ 'a': 1, 'b': 2 }, { 'a': 1, 'b': 2, 'c': 3 })\n    true\n    > sub_dictionary({ 'a': 1, 'b': 2 }, { 'a': 1, 'b': 3, 'c': 3 })\n    false\n    > sub_dictionary({ 'a': 1, 'b': 2 }, { 'a': 1, 'c': 3 })\n    false	932	sub dictionary	Checks whether all key-value pairs in one dictionary are present in another	0
Example:\n\n\n    > sub_dictionary({ 'a': 1, 'b': 2 }, { 'a': 1, 'b': 2, 'c': 3 })\n    true\n    > sub_dictionary({ 'a': 1, 'b': 2 }, { 'a': 1, 'b': 3, 'c': 3 })\n    false\n    > sub_dictionary({ 'a': 1, 'b': 2 }, { 'a': 1, 'c': 3 })\n    false	934	sub dictionary	Checks whether all key-value pairs in the first dictionary are present in the second	0
Example:\n\n\n    > sub_dictionary({ a: 1, b: 2 }, { a: 1, b: 2, c: 3 })\n    true\n    > sub_dictionary({ a: 1, b: 2 }, { a: 1, b: 3, c: 3 })\n    false\n    > sub_dictionary({ a: 1, b: 2 }, { a: 1, c: 3 })\n    false	935	sub dictionary	Checks whether all key-value pairs in the first dictionary are present in the second	0
	936	unzip kv	Takes a list of key-value pairs and builds a dictionary with those pairs	0
Example:\n\n    > unzip_kv([['a',1], ['b',2]])\n    { a: 1, b: 2 }\n	939	unzip kv	Takes a list of key-value pairs and builds a dictionary with those pairs	0
	940	parallel arrays to dictionary	Takes an array of keys and an array of values and returns a dictionary	0
Example:\n\n    > parallel_arrays_to_dictionary(['a','b','c'], [1,2,3])\n    { a: 1, b: 2, c: 3 }\n	942	parallel arrays to dictionary	Takes an array of keys and an array of values and returns a dictionary	0
Given a dictionary `d`: if `d[k]=v`, then `k in dict_inverse_multi(d)[v]`.\n\n    >>> dict_inverse_multi({1: 'Open', 2: 'Resolved', 3: 'Closed'})\n    {'Resolved': set([2]), 'Open': set([1]), 'Closed': set([3])}\n\n    >>> dict_inverse_multi({1: 'Open', 2: 'Closed', 3: 'Closed'})\n    {'Open': set([1]), 'Closed': set([2, 3])}\n	943	dict inverse multi	Given a dictionary, returns a dictionary that maps the values back the sets of keys that mapped to them.	0
A *cons-list* is a "list" of the following form:\n\n    (3,(1,(4,(1,(5,())))))\nWhich represents the regular python list `[1,2,3,4,5]`. \n\nFormally: a *cons-list* is either `()` or `(x,xs)`, where `xs` is another cons-list.\n\n`traverse_cons_list` traverses a cons-list in order from front to back.\n\n    >>> for i in traverse_cons_list((1,(2,(3,(4,()))))): print i\n    1\n    2\n    3\n    4\n\n	944	traverse cons list	Returns a generator that traverses a cons list from front to back.	0
	945	hello	Hello, World!	0
	946	instance methods	Returns a dictionary of methods that are callable on a given object.	0
	947	<__main__.Interface instance at 0x2610050>		1
    label_table({ \n       'foo': $('<b>Hello</b>'), \n       'bar': $('<input type="text" value="World" />'),\n    })\n\nWould render something like:\n\n<table>\n <tr>\n  <td>foo</td>\n  <td><b>Hello</b></td>\n </tr>\n <tr>\n  <td>bar</td>\n  <td><input type="text" value="World" /></td>\n </tr>\n</table>	948	label table	Creates a table that labels a dictionary of DOM nodes by their keys.	0
`strip_indent(text)` takes some multiline text, identifies the least amount of whitespace leading each line, and removes it.  It returns a tuple `(stripped, whitespace)`, where `stripped` is the text with the indentation removed, and `whitespace` is the whitespace that was removed.	949	strip indent	Removes as much indentation as possible from a multiline string.	0
`normalize_code(code_text)` takes a block of code as a string and returns it in the form preferred by the CodeCatalog ([strip leading and trailing whitespace](/spec/40) and left-justify with respect to tabs)	950	normalize code	Format a string to match CodeCatalog's conventions for code.	0
`normalize_code(code_text)` takes a block of code as a string and returns it in the form preferred by the CodeCatalog ([strip leading and trailing whitespace](/40/) and left-justify with respect to tabs)	951	normalize_code	Format a string to match CodeCatalog's conventions for code.	0
`normalize_code(code_text)` takes a block of code as a string and returns it in the form preferred by the CodeCatalog (strip leading and trailing whitespace and left-justify with respect to tabs)	952	normalize_code	Format a string to match CodeCatalog's conventions for code.	0
`normalize_code(code_text)` takes a block of code as a string and returns it in the form preferred by the CodeCatalog (strip leading and trailing whitespace and left-justify with respect to tabs)	953	normalize code	Format a string to match CodeCatalog's conventions for code.	0
`flatten` performs a *shallow* flatten, concatenating all the elements of a list of lists.  So:\n\n    > flatten([[1,2],[3],[4,5]])\n    [1,2,3,4,5]\n\n    > flatten([[1,2],[[3,4,5]],[6]])\n    [1,2,[3,4,5],6]\n\nNote how the list `[3,4,5]` is preserved, because it is more than two levels deep.	1016	flatten	Flattens a list of lists by one level.	0
`size` is the size in pixels of the resulting image, and defaults to the [gravatar](http://www.gravatar.com) default image size 80.  `default` is the image to use if the email has no associated gravatar.  Or `default` can be one of the following strings (taken from the [developer documentation](http://en.gravatar.com/site/implement/images/)).\n\n* `404`: do not load any image if none is associated with the email hash, instead return an HTTP 404 (File Not Found) response\n* `mm`: (mystery-man) a simple, cartoon-style silhouetted outline of a person (does not vary by email hash)\n* `identicon`: a geometric pattern based on an email hash\n* `monsterid`: a generated 'monster' with different colors, faces, etc\n* `wavatar`: generated faces with differing features and backgrounds\n* `retro`: awesome generated, 8-bit arcade-style pixelated faces	954	gravatar url	Constructs the gravatar url for a given email address.	0
Takes a JSON string, returns a JSON string with whitespace inserted to make it more readable.	955	prettify json	A pretty reformatter for JSON strings	0
`wrap_fields(wrapper, dictionary)`, when `wrapper` is a dictionary of unary functions, returns `dictionary` where any keys `k` that are also in `wrapper` are passed through `wrapper[k]`.  The function does not modify the original dictionary, but returns a copy.\n\nFor example:\n\n    >>> wrappers = { \n    ...     'user': lambda u: '<<' + u + '>>', \n    ...     'email': lambda e: e.lower(),\n    ... }\n    >>> user = { \n    ...     'user': 'luke', \n    ...     'email': 'YOURMOM@Example.com', \n    ...     'favorite color': 'red' \n    ... }\n    >>> wrap_fields(wrappers, user)\n    {'email': 'yourmom@example.com', 'user': '<<luke>>', 'favorite color': 'red'}	956	wrap fields	Takes a dictionary of wrapper functions and uses it to wrap the values of another dictionary.	0
	958	unnamed	Some sort of mock POP server.	1
Foo	963	unnamed	Some sort of mock POP server.	1
	964	unnamed	Some sort of mock POP server.	1
	965	unnamed		1
	966	unnamed	Some sort of mock POP server.	1
	967	unnamed		1
	968	gray code	Generate an n-bit gray code	0
An *n*-bit [gray code] is a sequence of *n*-bit strings such that each element in the sequence differs from the previous element in only one bit.  Every possible *n*-bit string occurs in the code.  For example, the 3-bit gray code is:\n\n    000\n    001\n    011\n    010\n    110\n    111\n    101\n    100\n\n   [gray code]: http://en.wikipedia.org/wiki/Gray_code	970	gray code	Generate an n-bit gray code	0
An *n*-bit [gray code] is a sequence of *n*-bit strings such that each element in the sequence differs from the previous element in only one bit.  Every possible *n*-bit string occurs in the code.  For example, the 3-bit gray code is:\n\n    000\n    001\n    011\n    010\n    110\n    111\n    101\n    100\n\nImplementation by [Brent Yorgey](http://projects.haskell.org/diagrams/gallery/Gray.html).\n\n   [gray code]: http://en.wikipedia.org/wiki/Gray_code	971	gray code	Generate an n-bit gray code	0
	974	floating point regexp	A regular expression for matching floating point numbers	0
From [regular-expressions.info](http://www.regular-expressions.info/floatingpoint.html).	976	floating point regexp	A regular expression for matching floating point numbers	0
	977	unnamed		0
	979	escape for regexp		0
	980	escape for regexp	Escape all regular expression metacharacters so a string can be used literally	0
	982	dynamic_link (deprecated)	Creates an HTML link which calls a callback when clicked.	1
	984	dynamic_link (deprecated)	Creates an HTML link which calls a callback when clicked. blah	1
	985	dynamic_link (deprecated)	Creates an HTML link which calls a callback when clicked.	1
	987	unnamed		0
	989	trace		0
	990	trace	Log the arguments to the console then return the last one.	0
`trace` is useful for inline debugging.  Say I have a function like:\n\n    function foo(x,y) {\n        return bar(y,x+y)\n    }\n\nAnd I want to see if `bar` is giving the right output for those inputs.  Normally I would change foo to:\n\n    function foo(x,y) {\n        var r = bar(y,x+y);\n        console.log(x, y, r);\n        return r;\n    }\n\nWith `trace`, I can instead write it as:\n\n    function foo(x,y) {\n        return trace(x, y, bar(y,x+y));\n    }\n\n`trace` always returns its last argument, so these last two writings of `foo` are exactly equivalent.	991	trace	Log the arguments to the console then return the last one.	0
	992	unnamed		0
	994	reduce args left		0
	995	reduce args left	Convert a binary function to a variadic function by left-reducing (folding) the arguments.	0
When writing tricky functions, sometimes it is easier to specify the case for two operands, but easier to use the function if it is specified for an arbitrary number of operands.  `reduce_args_left` converts the former to the latter.  As a simple example, here is a function that adds all of its arguments:\n\n    function sum() {\n        var r = 0;\n        for (var i = 0; i < arguments.length; i++) {\n            r = r + arguments[i];\n        }\n    }\n\nThis is cumbersome and obscures the important part of `sum`: the adding.  With `reduce_args_left` we can write this more easily:\n\n    var sum = reduce_args_left(sum(x,y) { return x+y });\n\nNote that this new definition is subtly different: if zero arguments are given, this new variant will return `undefined` instead of `0`.  `reduce_args_left` only works for non-empty argument lists.	996	reduce args left	Convert a binary function to a variadic function by left-reducing (folding) the arguments.	0
	997	shallow copy	Make a shallow clone of an object	0
	1001	unnamed		0
	1003	replace		0
	1004	replace	Replace all occurrences of an element in an array	0
`replace(e, r, xs)` returns an array which is just like `xs` except that all occurrences of `e` (compared by `===`) have been replaced with `r`.  The original array `xs` is unchanged.\n\n    > replace(null, 42, [0, null, 1, null, 2])\n    [0, 42, 1, 42, 2]	1005	replace	Replace all occurrences of an element in an array	0
	1007	unnamed		0
	1009	arguments to array		0
	1010	arguments to array	Converts a javascript arguments object to a proper Array	0
The `arguments` object in javascript is like an array, but it is nerfed with fewer methods than a regular `Array` object.  This function takes an `arguments` object and returns an `Array`:\n\n    > var foo = function() { return arguments.slice(1) }\n    > foo(1,2,3);\n    ERROR Object has no method 'slice'\n\n    > var bar = function() { return arguments_to_array(arguments).slice(1) }\n    > bar(1,2,3)\n    [2, 3]	1011	arguments to array	Converts a javascript arguments object to a proper Array	0
	1012	unnamed		0
	1014	flatten		0
	1015	flatten	Flattens a list of lists by one level.	0
Duplicate of [count equal](http://www.codecatalog.net/280/).	1017	count equal	Counts the number of elements of a list which are equal to some other element of the list	0
Duplicate of [count equal](http://www.codecatalog.net/280/).	1018	count equal	Counts the number of elements of a list which are equal to some other element of the list	1
	1019	Data.MeldableHeap	The Haskell meldable heap library	0
From the [meldable-heap](http://hackage.haskell.org/package/meldable-heap) package on hackage.	1021	Data.MeldableHeap	The Haskell meldable heap library	0
From the [meldable-heap](http://hackage.haskell.org/package/meldable-heap) package on hackage.\n\n    % cabal install meldable-heap	1022	Data.MeldableHeap	The Haskell meldable heap library	0
	1023	enum increasing	Enumerates the nodes of a graph by an increasing measure function	0
`enumIncreasing measure successors x0` starts at the node `x0` and enumerates successively increasing nodes reachable from `x0`, paired with their measures.  The following monotonicity property must hold:\n\n    all (>= measure x) [ measure s | s <- successors x ]\n\nThat is, the successors of a node must have measures no smaller than the node itself.  This is required to ensure the returned list is increasing. \n\nFor example, consider the infinite graph of numbers, starting with `1`, such that there is an edge from `x` to `x+10` and from `x` to `x*2`.  We can enumerate all the reachable members of this graph in increasing order using `enumIncreasing`:\n\n    ghci> take 20 $ enumIncreasing id (\\x -> [x+10,x*2]) 1\n    [(1,1),(2,2),(4,4),(8,8),(11,11),(12,12),(14,14),(16,16),(18,18),(21,21),\n    (22,22),(24,24),(26,26),(28,28),(31,31),(32,32),(34,34),(36,36),(38,38),(41,41)]\n	1025	enum increasing	Enumerates the nodes of a graph by an increasing measure function	0
`enumIncreasing measure successors x0` starts at the node `x0` and enumerates successively increasing nodes reachable from `x0`, paired with their measures.  The following monotonicity property must hold:\n\n    all (>= measure x) [ measure s | s <- successors x ]\n\nThat is, the successors of a node must have measures no smaller than the node itself.  This is required to ensure the returned list is increasing. \n\nFor example, consider the infinite graph of numbers, starting with `1`, such that there is an edge from `x` to `x+10` and from `x` to `x*2`.  We can enumerate all the reachable members of this graph in increasing order using `enumIncreasing`:\n\n    ghci> take 20 $ enumIncreasing id (\\x -> [x+10,x*2]) 1\n    [(1,1),(2,2),(4,4),(8,8),(11,11),(12,12),(14,14),(16,16),(18,18),(21,21),\n    (22,22),(24,24),(26,26),(28,28),(31,31),(32,32),(34,34),(36,36),(38,38),(41,41)]\n\nRequires `{-# LANGUAGE PatternGuards #-}`.	1026	enum increasing	Enumerates the nodes of a graph by an increasing measure function	0
`bits` takes a nonnegative integer and returns a sequence of bits -- binary digits -- in its binary encoding, **from least to most significant**.  Note that this is backwards from the usual way that binary numbers are *written*, but it is often more convenient for working with them programmatically.\n\n    ghci> bits 6   -- 6 = 110 in binary\n    [False,True,True]\n\nThe reason this spec does not handle negative integers is that we need to have a bit width to encode twos complement.  Eg. for *8-bit* integers, -2 = 11111110, but for *16-bit* integers, -2 = 1111111111111110.  However, because the least significant bits are returned first, we can do this in languages which can return infinite lists.  Eg. in Haskell:\n\n    bits> bits (-6)   -- 1...1010 in binary\n    [False,True,False,True,True,True,True,...\n	1027	bits	Get the (little endian) list of bits encoding a nonnegative integer	0
	1028	base digits	Gets the reversed digits of an integer in a given base	0
Returns `[]` for `0`.  Gives an infinite twos-complement-esque sequence for negative numbers.\n\n    ghci> baseDigits 10 12345\n    [5,4,3,2,1]\n    \n    ghci> baseDigits 10 0\n    []\n\n    ghci> take 10 $ baseDigits 10 (-2)\n    [8,9,9,9,9,9,9,9,9,9]	1030	base digits	Gets the reversed digits of an integer in a given base	0
	1031	unnamed		0
	1034	regexp tokenizer		0
	1035	regexp tokenizer	Tokenize a string by a set of regular expressions	0
`regexp_tokenizer` takes a dictionary mapping regexps to functions (saying what to do with the match object) and returns a parser that finds the longest leading token.  If such a token was found, the parser returns a two element array, the first element being the token found (and processed by the function), the second being the remainder of the unparsed string.  Otherwise, the parser returns `null`.\n\nFor example:\n\n    var parser = regexp_tokenizer({\n        '\\\\w+': function(m) { return { type: 'identifier', name: m[0] } },\n        '\\\\s+': function(m) { return { type: 'whitespace' } },\n        '[+*/-]': function(m) { return { type: 'operator', name: m[0] } }\n    })\n    \n    > parser('hello + world')\n    [ { type: 'identifier', name: 'hello' }, ' + world' ]\n    > parser(' + world')\n    [ { type: 'whitespace' }, '+ world' ]\n    > parser('+ world')\n    [ { type: 'operator', name: '+' }, ' world' ]\n    > parser(' world')\n    [ { type: 'whitespace' }, 'world' ]\n    > parser('world')\n    null\n    > parser('world\\0')\n    [ { type: 'identifier', name: 'world' }, '\\u0000' ]\n\n\nNote how `parser('world')` returned `null` instead of an `identifier` token?  That is because this parser was designed for use in a realtime situation where the input may not yet be complete, so it refuses to return a token at the end of the string in case there is more input.  To use this in a non-realtime setting, append `\\0` or some other unused character to the end of the string.	1036	regexp tokenizer	Tokenize a string by a set of regular expressions	0
	1037	tokenizer	A function that extracts a token from the beginning of a string and returns the remainder	0
`regexp_tokenizer` takes a dictionary mapping regexps to functions (saying what to do with the match object) and returns a [tokenizer](/379) that finds the longest leading token.  If such a token was found, the tokenizer returns a two element array, the first element being the token found (and processed by the function), the second being the remainder of the unparsed string.  Otherwise, the tokenizer returns `null`.\n\nFor example:\n\n    var tok = regexp_tokenizer({\n        '\\\\w+': function(m) { return { type: 'identifier', name: m[0] } },\n        '\\\\s+': function(m) { return { type: 'whitespace' } },\n        '[+*/-]': function(m) { return { type: 'operator', name: m[0] } }\n    })\n    \n    > tok('hello + world')\n    [ { type: 'identifier', name: 'hello' }, ' + world' ]\n    > tok(' + world')\n    [ { type: 'whitespace' }, '+ world' ]\n    > tok('+ world')\n    [ { type: 'operator', name: '+' }, ' world' ]\n    > tok(' world')\n    [ { type: 'whitespace' }, 'world' ]\n    > tok('world')\n    null\n    > tok('world\\0')\n    [ { type: 'identifier', name: 'world' }, '\\u0000' ]\n\n\nNote how `tok('world')` returned `null` instead of an `identifier` token?  That is because this tokenizer was designed for use in a realtime situation where the input may not yet be complete, so it refuses to return a token at the end of the string in case there is more input.  To use this in a non-realtime setting, append `\\0` or some other unused character to the end of the string.	1038	regexp tokenizer	Tokenize a string by a set of regular expressions	0
	1039	unnamed		0
	1041	multi tokenizer		0
`multi_tokenizer` takes a [tokenizer](/379) as an argument and returns a tokenizer which applies its argument until it fails and returns the list of result.  `multi_tokenizer(t)` *never* fails (it returns an empty list instead).\n\nFor example:\n\n    var word_tokenizer = function(str) {\n        if (var m = /^(\\w+)\\s*/(str)) {\n            return [m[1], str.slice(m[0].length)]\n        }\n        else {\n            return null;\n        }\n    };\n\n    > word_tokenizer('foo bar baz')\n    [ 'foo', 'bar baz' ]\n    \n    > mutli_tokenizer(word_tokenizer)('foo bar baz')\n    [ [ 'foo', 'bar', 'baz' ], '' ]	1042	multi tokenizer		0
	1043	unnamed		0
	1045	map tokenizer		0
	1046	map tokenizer	Maps the result of a tokenizer by a function	0
`map_tokenizer(f, tok)` maps the result of the [tokenizer](/379) `tok` by a function `f`, and returns the resulting tokenizer.  For example:\n\n    var if_tokenizer = function(str) {\n        if (/^if/(str)) {\n            return [ 'if', str.slice(2) ]\n        }\n        else {\n            return null;\n        }\n    }\n\n    > if_tokenizer('iface')\n    [ 'if', 'ace' ]\n\n    > map_tokenizer(function(r) { return r.toUpperCase() }, if_tokenizer)('iface')\n    [ 'IF', 'ace' ]	1047	map tokenizer	Maps the result of a tokenizer by a function	0
A `tokenizer` is a function that takes a string and returns either a two element array or `null` (indicating a failure to find a token).  The first element is some value, the *token*, and the second element is a suffix of the string that was passed -- the portion of the string that was not consumed by the tokenizer.\n\nFor example, this is a tokenizer that extracts an `if` token:\n\n    var if_tokenizer = function(str) {\n        if (/^if/(str)) {\n            return [ 'if', str.slice(2) ]\n        }\n        else {\n            return null;\n        }\n    }\n\n    > if_tokenizer("hello")\n    null\n    > if_tokenizer("iface")\n    [ 'if', 'ace' ]\n\nThe first element can be anything: it does not need to be a substring of the original string as it is here; it does not even need to be a string.\n\nFunctions on tokenizers:\n\n* [regexp tokenizer](/377) - build a tokenizer out of a set of regular expressions\n* [multi tokenizer](/380) - repeat a tokenizer as many times as possible\n* [map tokenizer](/382) - map the result of a tokenizer by a function	1048	tokenizer	A function that extracts a token from the beginning of a string and returns the remainder	0
`multi_tokenizer` takes a [tokenizer](/379) as an argument and returns a tokenizer which applies its argument until it fails and returns the list of result.  `multi_tokenizer(t)` *never* fails (it returns an empty list instead).\n\nFor example:\n\n    var word_tokenizer = function(str) {\n        if (var m = /^(\\w+)\\s*/(str)) {\n            return [m[1], str.slice(m[0].length)]\n        }\n        else {\n            return null;\n        }\n    };\n\n    > word_tokenizer('foo bar baz')\n    [ 'foo', 'bar baz' ]\n    \n    > mutli_tokenizer(word_tokenizer)('foo bar baz')\n    [ [ 'foo', 'bar', 'baz' ], '' ]	1049	multi tokenizer	Repeats a tokenizer as many times as possible and returns the list of results	0
	1050	extend	Add all the properties of one object to another	0
`extend(target,src)` destructively copies the properties of `src` into `target`, adding to the properties `target` already has.  If `target` and `src` share keys, `src` wins.  Returns the modified `target`.\n\n    > var obj = { foo: 1, bar: 2 };\n    > extend(obj, { bar: 3, baz: 4 });\n    { foo: 1, bar: 3, baz: 4 }\n    > obj\n    { foo: 1, bar: 3, baz: 4 }	1053	extend	Add all the properties of one object to another	0
	1054	range	Construct a numeric sequence given its endpoints [left,right)	0
`left` and `right` must be integers.  `right` is taken to be an open endpoint -- the resulting sequence will not contain it.  If `right <= left`, the empty list is returned.\n\n    > range(0,10)\n    [ 0, 1, 2, 3, 4, 5, 6, 7, 8, 9 ]	1056	range	Construct a numeric sequence given its endpoints [left,right)	0
`left` and `right` must be integers.  `right` is taken to be an open endpoint -- the resulting sequence will not contain it.  If `right <= left`, the empty list is returned.\n\n    > range(0,10)\n    [ 0, 1, 2, 3, 4, 5, 6, 7, 8, 9 ]\n    > range(5,0)\n    []	1057	range	Construct a numeric sequence given its endpoints [left,right)	0
`extend(target,src)` destructively copies the properties (attributes, methods) of `src` into `target`, adding to the properties `target` already has.  If `target` and `src` share keys, `src` wins.  Returns the modified `target`.\n\n    > var obj = { foo: 1, bar: 2 };\n    > extend(obj, { bar: 3, baz: 4 });\n    { foo: 1, bar: 3, baz: 4 }\n    > obj\n    { foo: 1, bar: 3, baz: 4 }	1058	extend	Add all the properties of one object to another	0
	1059	unnamed		0
	1061	splice replace		0
	1062	splice replace	Replace an item in a list with a sequence of items.	0
`splice_replace(e, replacements, xs)` finds the first occurrence of `e` in `xs` and replaces it with the *sequence* `replacements`:\n\n    > splice_replace(null, [4,5], [1,2,3,null,6,null,7])\n    [ 1, 2, 3, 4, 5, 6, null, 7 ]\n\nThis function is pure &mdash; the original list is not modified.	1063	splice replace	Replace an item in a list with a sequence of items.	0
`splice_replace(e, replacements, xs)` replaces all occurrences of of `e` in `xs` with the *sequence* `replacements`:\n\n    > splice_replace(null, ["foo","bar"], [1,2,3,null,6,null,7])\n    [ 1, 2, 3, "foo", "bar", 6, "foo", "bar", 7 ]\n\nThis function is pure &mdash; the original list is not modified.	1065	splice replace	Replace an item in a list with a sequence of items.	0
`splice_replace(e, replacements, xs)` replaces all occurrences of `e` in `xs` with the *sequence* `replacements`:\n\n    > splice_replace(null, ["foo","bar"], [1,2,3,null,6,null,7])\n    [ 1, 2, 3, "foo", "bar", 6, "foo", "bar", 7 ]\n\nThis function is pure &mdash; the original list is not modified.	1066	splice replace	Replace an item in a list with a sequence of items.	0
	1067	unnamed		0
	1069	choice tokenizer		0
	1070	choice tokenizer	Try multiple tokenizers in sequence until one of them succeeds	0
`choice_tokenizer` takes a list of [tokenizers](/379/) and returns a tokenizer which tries each tokenizer in sequence until one of them succeeds.  If none of them succeed, then `choice_tokenizer` fails.\n\n    > var tok = choice_tokenizer([\n                    regexp_tokenizer({'foo': function() { return 1 }),\n                    regexp_tokenizer({'bar': function() { return 2 })\n                ])\n    > tok('foot')\n    [ 1, 't' ]\n    > tok ('bart')\n    [ 2, 't' ]\n    > tok ('bazt')\n    null	1071	choice tokenizer	Try multiple tokenizers in sequence until one of them succeeds	0
A `tokenizer` is a function that takes a string and returns either a two element array or `null` (indicating a failure to find a token).  The first element is some value, the *token*, and the second element is a suffix of the string that was passed -- the portion of the string that was not consumed by the tokenizer.\n\nFor example, this is a tokenizer that extracts an `if` token:\n\n    var if_tokenizer = function(str) {\n        if (/^if/(str)) {\n            return [ 'if', str.slice(2) ]\n        }\n        else {\n            return null;\n        }\n    }\n\n    > if_tokenizer("hello")\n    null\n    > if_tokenizer("iface")\n    [ 'if', 'ace' ]\n\nThe first element can be anything: it does not need to be a substring of the original string as it is here; it does not even need to be a string.\n\nFunctions on tokenizers:\n\n* [regexp tokenizer](/377) - build a tokenizer out of a set of regular expressions\n* [multi tokenizer](/380) - repeat a tokenizer as many times as possible\n* [map tokenizer](/382) - map the result of a tokenizer by a function\n* [choice tokenizer](/300) - try a list of tokenizers in sequence until one of them succeeds	1072	tokenizer	A function that extracts a token from the beginning of a string and returns the remainder	0
	1074	unnamed		0
	1076	string tokenizer		0
	1077	string tokenizer	A tokenizer that parses a constant string.	0
`string_tokenizer(str,value)` is a [tokenizer](/379) that parses any string starting with `str` and yields `value`.  It fails otherwise.	1079	string tokenizer	A tokenizer that parses a constant string.	0
A `tokenizer` is a function that takes a string and returns either a two element array or `null` (indicating a failure to find a token).  The first element is some value, the *token*, and the second element is a suffix of the string that was passed -- the portion of the string that was not consumed by the tokenizer.\n\nFor example, this is a tokenizer that extracts an `if` token:\n\n    var if_tokenizer = function(str) {\n        if (/^if/(str)) {\n            return [ 'if', str.slice(2) ]\n        }\n        else {\n            return null;\n        }\n    }\n\n    > if_tokenizer("hello")\n    null\n    > if_tokenizer("iface")\n    [ 'if', 'ace' ]\n\nThe first element can be anything: it does not need to be a substring of the original string as it is here; it does not even need to be a string.\n\nFunctions on tokenizers:\n\n* [regexp tokenizer](/377) - build a tokenizer out of a set of regular expressions\n* [multi tokenizer](/380) - repeat a tokenizer as many times as possible\n* [map tokenizer](/382) - map the result of a tokenizer by a function\n* [choice tokenizer](/300) - try a list of tokenizers in sequence until one of them succeeds\n* [string tokenizer](/393) - parse a constant string	1080	tokenizer	A function that extracts a token from the beginning of a string and returns the remainder	0
`string_tokenizer(str,func)` is a [tokenizer](/379) that parses any string starting with `str` and calls `value` when this happens, yielding its result.  It fails otherwise.	1082	string tokenizer	A tokenizer that parses a constant string.	0
    >>> indent_by("xxxx", "  foo\\nbar\\n")\n    "xxxx  foo\\nxxxxbar\\n"\n\nThe trailing `"\\n"` will be there even if the original string didn't have it.	1085	indent_by	Prefix every line of a multiline string by a string ("indent").	0
	1090	language to codemirror mode	A mapping from language name string to url and mime-type for CodeMirror.	0
	1092	download script	Downloads and runs a javascript script from a url and calls a callback when it's done	0
	1096	download stylesheet	Download a stylesheet from a url.	0
*Does not work in IE8 and possibly other IE versions.*	1102	download stylesheet	Download a stylesheet from a url.	0
	1105	unnamed		0
	1107	merge		0
	1108	merge	Merge an infinite 2D increasing array into a flat ordered list	0
`merge` takes a (possibly infinite) list of (possibly infinite) lists, and flattens the elements in increasing order.  The list of lists has the following preconditions:\n\n* Each list must be increasing (non-strictly): `all increasing xs`\n* The must be increasing (non-strictly): `increasing (map head xs)`	1110	merge	Merge an infinite 2D increasing array into a flat ordered list	0
	1111	enum field	A django field for a finite, named enumerated type	0
Usage:\n\n    Class Card(models.Model):\n        suit = EnumField(values=('Clubs', 'Diamonds', 'Spades', 'Hearts'))\n\n    c = Card()\n    c.suit = 'Clubs'\n    c.save()	1113	enum field	A django field for a finite, named enumerated type	0
Usage:\n\n    Class Card(models.Model):\n        suit = EnumField(values=('Clubs', 'Diamonds', 'Spades', 'Hearts'))\n\n    c = Card()\n    c.suit = 'Clubs'\n    c.save()\n\n[Taken from stackoverflow](http://stackoverflow.com/questions/21454/specifying-a-mysql-enum-in-a-django-model/1530858#1530858).	1114	enum field	A django field for a finite, named enumerated type	0
Usage:\n\n    Class Card(models.Model):\n        suit = EnumField(values=('Clubs', 'Diamonds', 'Spades', 'Hearts'))\n\n    c = Card()\n    c.suit = 'Clubs'\n    c.save()\n\n[Taken from stackoverflow](http://stackoverflow.com/questions/21454/specifying-a-mysql-enum-in-a-django-model/1530858#1530858).	1115	enum field	A django field that maps to an SQL ENUM type	0
	1116	unnamed		0
	1118	enum field		0
	1119	enum field	A django field representing a one of a finite set of values	0
Usage:\n\n    class Foo(models.Model):\n        status = EnumField(values=["Single", "It's Complicated", "In a Relationship", "Married" ]\n\n    foo = Foo()\n    foo.status = "Single"\n    foo.save()\n\n`status` will be stored as an integer in `range(0,4)` in the database, in order given by `values`. \n\n`EnumField` works with any value type (`string` in this example) other than `int`.  It doesn't work with `int` because we need to be able to dynamically tell the difference between an unconverted and a converted value, and they are the same type when the value type is `int`.	1120	enum field	A django field representing a one of a finite set of values	0
**DEPRECATED**: use [this](/409/) instead.\n\nUsage:\n\n    Class Card(models.Model):\n        suit = EnumField(values=('Clubs', 'Diamonds', 'Spades', 'Hearts'))\n\n    c = Card()\n    c.suit = 'Clubs'\n    c.save()\n\n[Taken from stackoverflow](http://stackoverflow.com/questions/21454/specifying-a-mysql-enum-in-a-django-model/1530858#1530858).	1121	enum field	A django field that maps to an SQL ENUM type	0
**DEPRECATED**: use [this](/409/) instead.\n\nUsage:\n\n    Class Card(models.Model):\n        suit = EnumField(values=('Clubs', 'Diamonds', 'Spades', 'Hearts'))\n\n    c = Card()\n    c.suit = 'Clubs'\n    c.save()\n\n[Taken from stackoverflow](http://stackoverflow.com/questions/21454/specifying-a-mysql-enum-in-a-django-model/1530858#1530858).	1122	enum field	A django field that maps to an SQL ENUM type	1
	1123	models	Standard django model classes	0
Usage:\n\n    class Foo(models.Model):\n        status = EnumField(values=["Single", "It's Complicated", "In a Relationship", "Married" ]\n\n    foo = Foo()\n    foo.status = "Single"\n    foo.save()\n\n`status` will be stored as an integer in `range(0,4)` in the database, in order given by `values`. \n\n`EnumField` works with any value type (`string` in this example) other than `int`.  It doesn't work with `int` because we need to be able to dynamically tell the difference between an unconverted and a converted value, and they are the same type when the value type is `int`.	1126	enum field	A django field representing one of a finite set of values	0
For example:\n\n    >>> dict_inverse({0: 'Open', 1: 'Resolved', 2: 'Closed'})\n    {'Resolved': 1, 'Open': 0, 'Closed': 2}\n\nThis function throws an exception if the given dictionary is not one-to-one (invertible).\n\n\n    >>> dict_inverse({0: 'Open', 1: 'Closed', 2: 'Closed'})\n    ValueError: Dictionary given to dict_inverse is not one-to-one.  \n                       Duplicate value: Closed\n                       Mapped to by: 1 and 2\n	1127	dict inverse	Creates a dictionary that maps values back to keys from another dictionary.	0
	1131	timestamp to string	Return the string representation of a timestamp object.	0
	1132	Date	The javascript Date class.	0
	1133	timestamp to string	Return the string representation of a Date as an interval of time since the present moment. ex: 3 days ago.	0
	1134	timestamp to string	Return the string representation of a Date as an interval of time since the present moment. ex: 3 days ago.	0
	1135	Math	The javascript Math library.	0
	1141	on enter	Fire an event on a jquery element when the enter key is pressed.	0
	1142	Inverse OpenGL Modelview	Transforms a point by the inverse of the current ModelView matrix, i.e.  from eye space to object space	0
	1144	eye2object	Transforms a point by the inverse of the current ModelView matrix, i.e.  from eye space to object space	0
	1147	timestamp to string	Return the string representation of a Date as an interval of time since the present moment. ex: 4 days ago.	0
	1148	datetime	The python datetime module.  This is a structure that combines date and time objects.	0
	1150	datetime to ticks	Convert the given datetime object into ms since the epoch.	0
	1153	time	The python time library.  A representation of a raw time in ticks since the epoch and a related library.	0
	1156	abs	Return the absolute value of a number. The argument may be a plain or long integer or a floating point number. If the argument is a complex number, its magnitude is returned.	0
	1158	all	Return True if all elements of the iterable are true (or if the iterable is empty).	0
Equivalent to:\n\n    def all(iterable):\n        for element in iterable:\n            if not element:\n                return False\n        return True	1159	all	Return True if all elements of the iterable are true (or if the iterable is empty).	0
	1160	any	Return True if any element of the iterable is true. If the iterable is empty, return False.	0
Equivalent to:\n\n    def any(iterable):\n        for element in iterable:\n            if element:\n                return True\n        return False	1161	any	Return True if any element of the iterable is true. If the iterable is empty, return False.	0
	1162	bin	Convert an integer number to a binary string.	0
The result is a valid Python expression. If x is not a Python int object, it has to define an __index__() method that returns an integer.	1163	bin	Convert an integer number to a binary string.	0
	1164	eye to object	Transforms a point by the inverse of the current ModelView matrix, i.e.  from eye space to object space	0
	1165	eye to object	Transforms a point by the inverse of the current ModelView matrix, i.e.  from eye space to object space.	0
	1166	Python thing	Example of code	0
\.


--
-- Data for Name: zoo_version; Type: TABLE DATA; Schema: public; Owner: codecatalog
--

COPY zoo_version (versionptr_id, "timestamp", id, user_id, active, comment, serial) FROM stdin;
330	2011-05-23 03:23:50.319423+00	896	1	f		4
287	2011-05-16 05:09:49.159053+00	795	2	f		1
291	2011-05-16 05:11:41.754762+00	811	2	t		2
295	2011-05-16 05:10:18.392071+00	803	2	f		1
360	2011-06-03 07:49:50.424278+00	996	1	t		4
336	2011-05-23 22:39:18.279551+00	906	1	t		1
304	2011-05-16 10:39:37.869351+00	827	1	t	Needs a reference to the library site or something.	1
337	2011-05-23 23:18:23.3493+00	916	1	f		3
366	2011-06-07 04:22:56.854927+00	1006	1	t	Added foreach dependency	2
306	2011-05-17 09:58:28.276068+00	835	29	f		3
343	2011-05-26 20:42:21.716945+00	926	1	f		1
303	2011-05-18 06:27:09.340001+00	843	2	f		2
272	2011-05-16 06:35:42.543082+00	819	1	f		5
313	2011-05-19 22:56:06.557122+00	851	1	t		1
369	2011-06-07 07:36:17.961713+00	1016	1	t		4
347	2011-05-26 21:10:13.947011+00	936	1	f		1
314	2011-05-19 23:19:32.366223+00	859	1	f		2
1	2011-05-27 08:39:02.124787+00	945	1	t		3
320	2011-05-20 04:37:50.039209+00	867	1	f		1
401	2011-06-28 06:28:33.796468+00	1100	1	f		5
323	2011-05-20 05:21:13.029155+00	875	1	t	Renamed the iterator i to the more suggestive k	2
84	2011-05-27 10:11:28.751874+00	954	1	t		5
403	2011-06-28 06:23:43.148778+00	1098	2	f		2
373	2011-06-10 05:58:16.648226+00	1025	1	f		2
327	2011-05-21 03:46:54.400872+00	883	1	f		1
329	2011-05-23 02:17:32.675242+00	891	1	t	Fixed, thanks :-)	2
378	2011-06-11 10:19:44.86926+00	1033	1	t	Added for kv dependency	2
73	2011-05-31 08:35:05.635938+00	963	2	f		4
353	2011-05-31 23:50:35.238685+00	972	1	t		1
356	2011-06-01 09:45:59.729619+00	980	1	t		3
405	2011-06-30 07:52:58.284307+00	1110	1	t		4
359	2011-06-03 07:40:47.850099+00	988	1	t		1
380	2011-06-11 10:38:38.290331+00	1041	1	f		2
380	2011-06-11 10:48:38.09873+00	1049	1	t		4
409	2011-07-09 13:43:11.030334+00	1120	1	f		4
386	2011-06-14 08:21:51.633525+00	1056	1	f		2
410	2011-07-09 13:55:38.240564+00	1128	1	t	Added dict_inverse dependency	3
388	2011-06-14 21:03:12.386928+00	1063	1	f		4
390	2011-06-18 18:49:22.938803+00	1070	1	f		3
393	2011-06-18 21:02:29.704095+00	1077	1	f		3
395	2011-06-22 11:53:25.309995+00	1084	29	t		2
399	2011-06-28 03:53:28.994753+00	1091	2	t		1
294	2011-07-13 07:22:30.7181+00	1136	2	f		2
421	2011-07-20 06:48:56.536648+00	1152	2	f	we decided to not reference soft dependencies in python	2
432	2011-07-20 07:40:28.171605+00	1160	2	f		1
416	2011-07-19 05:21:55.666003+00	1144	46	f		2
288	2011-05-16 05:09:49.476859+00	796	2	t		1
296	2011-05-16 05:10:18.709882+00	804	2	t		1
295	2011-05-16 05:11:51.481178+00	812	2	t		2
254	2011-05-16 06:49:56.54562+00	820	1	t		7
305	2011-05-16 10:40:02.21742+00	828	1	t	Please document more :'(	1
330	2011-05-23 03:20:41.030263+00	892	1	f		1
330	2011-05-23 03:24:21.936893+00	897	1	t		5
362	2011-06-03 08:34:45.365683+00	997	1	t		1
306	2011-05-18 00:24:45.481888+00	836	1	f		4
312	2011-05-19 23:03:00.212259+00	852	1	f		2
335	2011-05-23 22:39:26.997854+00	907	1	f		2
314	2011-05-19 23:19:41.231859+00	860	1	t		3
321	2011-05-20 04:37:50.48186+00	868	1	t		1
401	2011-06-28 06:27:37.639125+00	1099	2	f	made compatible with IE	4
322	2011-05-20 06:28:31.242689+00	876	1	t		3
337	2011-05-23 23:23:12.496155+00	917	1	t		4
328	2011-05-21 03:46:54.932278+00	884	1	f		1
401	2011-06-28 07:22:15.820849+00	1101	2	t	Fixed bugs	6
367	2011-06-07 04:23:21.65369+00	1007	1	f		1
344	2011-05-26 20:42:22.027818+00	927	1	f		1
348	2011-05-26 21:10:14.247243+00	937	1	f		1
281	2011-06-08 09:24:45.78629+00	1017	2	f		4
94	2011-05-27 09:50:43.723894+00	946	2	t		4
151	2011-05-27 10:12:35.015188+00	955	1	t		3
373	2011-06-10 06:09:12.168615+00	1026	1	t		3
73	2011-05-31 08:35:16.241443+00	964	2	f		5
191	2011-04-20 11:08:36.946855+00	526	1	f		2
191	2011-05-31 23:54:35.057997+00	973	1	t	Fixed two bugs at once	3
154	2011-06-01 10:09:21.171292+00	981	1	t	Change to better implementation a la SO discussion	2
377	2011-06-11 10:20:02.628221+00	1034	1	f		2
358	2011-06-03 07:41:04.705414+00	989	1	f		2
380	2011-06-11 10:42:42.547655+00	1042	1	f		3
407	2011-07-08 08:36:06.566293+00	1111	1	f		1
407	2011-07-09 13:44:06.728831+00	1121	1	f		5
386	2011-06-14 08:22:48.482936+00	1057	1	t		3
384	2011-06-14 05:34:23.36301+00	1050	1	f		1
389	2011-06-14 21:04:05.846832+00	1064	1	t	Added foreach dependency	2
390	2011-06-18 18:52:05.267673+00	1071	1	t		4
413	2011-07-11 13:01:45.094951+00	1129	29	f		1
394	2011-06-18 21:02:56.897134+00	1078	1	f		2
27	2011-03-26 09:44:08.313297+00	72	1	f		2
27	2011-03-26 09:44:45.132699+00	73	1	f		3
27	2011-03-26 09:46:14.245833+00	74	1	f		4
27	2011-06-25 06:56:16.573357+00	1085	2	t		5
400	2011-06-28 04:13:55.250718+00	1092	1	t		1
301	2011-07-13 07:22:59.276217+00	1137	2	f	This now takes a standard javascript Date object.	2
308	2011-05-18 07:20:00.252249+00	844	2	f		1
195	2011-07-19 05:22:42.730686+00	1145	46	t		2
422	2011-07-20 07:00:34.885101+00	1153	2	t		1
432	2011-07-20 07:40:52.225095+00	1161	2	t		2
363	2011-06-03 08:34:45.746713+00	998	1	t		1
297	2011-05-16 05:10:19.192561+00	805	2	f		1
331	2011-05-23 03:20:41.552863+00	893	1	f		1
289	2011-05-16 05:09:58.537224+00	797	2	f		1
289	2011-05-16 05:12:16.255541+00	813	2	t		2
332	2011-05-23 03:54:37.636214+00	898	1	f		1
158	2011-04-09 20:48:47.893063+00	431	\N	f		1
158	2011-05-16 10:56:38.178723+00	829	1	t		2
401	2011-06-28 04:13:55.861387+00	1093	1	f		1
368	2011-06-07 04:23:22.350797+00	1008	1	t		1
335	2011-05-23 22:39:59.332522+00	908	1	f		3
306	2011-05-18 00:24:51.837385+00	837	1	f		5
309	2011-05-18 07:20:00.547317+00	845	2	t		1
272	2011-05-16 06:52:31.153738+00	821	1	f		6
312	2011-05-19 23:03:17.623145+00	853	1	t		3
174	2011-04-17 02:57:54.016576+00	461	1	f		2
174	2011-04-17 02:59:15.978519+00	462	1	f		3
316	2011-05-19 23:20:22.807462+00	861	1	f		1
174	2011-04-17 03:02:37.613939+00	463	1	f		4
174	2011-04-17 03:03:22.427891+00	464	1	f		5
174	2011-05-25 06:10:45.956299+00	918	1	t		6
320	2011-05-20 04:39:40.421458+00	869	1	f		2
344	2011-05-26 20:43:13.520009+00	928	1	t		2
324	2011-05-21 03:07:04.301129+00	877	1	f		1
281	2011-06-08 09:24:51.657143+00	1018	2	t		5
348	2011-05-26 21:11:13.639656+00	938	1	t		2
327	2011-05-21 03:47:02.470764+00	885	1	f		2
115	2011-04-03 05:18:08.393605+00	321	\N	f		1
115	2011-05-27 09:57:31.631911+00	947	1	t		2
402	2011-06-28 07:23:20.21518+00	1102	2	t		2
42	2011-05-27 11:50:51.535789+00	956	1	t		6
227	2011-04-23 19:36:53.633996+00	618	1	f		2
227	2011-04-23 19:37:53.900478+00	619	1	f		3
227	2011-04-23 19:40:43.941801+00	620	1	f		4
73	2011-05-31 08:35:21.800839+00	965	2	f		6
227	2011-04-23 19:41:08.242978+00	621	1	f		5
227	2011-04-24 00:28:33.01673+00	630	1	f		6
354	2011-06-01 01:25:22.229211+00	974	1	f		1
227	2011-06-10 10:37:49.150048+00	1027	1	t	Added "binary digits" to make this function show up when you search for "digit"	7
164	2011-06-01 10:10:29.606365+00	982	1	f		5
408	2011-07-08 08:36:08.563235+00	1112	1	t		1
358	2011-06-03 07:41:17.215824+00	990	1	f		3
377	2011-06-11 10:20:34.045224+00	1035	1	f		3
407	2011-07-09 13:44:10.110446+00	1122	1	t		6
382	2011-06-11 10:43:22.595756+00	1043	1	f		1
413	2011-07-11 13:02:32.251597+00	1130	29	t		2
385	2011-06-14 05:34:23.658567+00	1051	1	f		1
384	2011-06-14 08:28:45.122581+00	1058	1	t	Added stuff for searchability	3
388	2011-06-14 21:07:50.72875+00	1065	1	f	It actually replaces all occurrences, not just the first.	5
294	2011-07-13 07:37:26.157246+00	1138	2	f		3
379	2011-06-18 18:53:03.064864+00	1072	1	f		3
393	2011-06-18 21:04:17.981752+00	1079	1	f		4
294	2011-07-20 06:20:13.720325+00	1146	2	t	added currentTime as a parameter to reduce assumptions	5
396	2011-06-27 13:19:17.88026+00	1086	29	t		1
423	2011-07-20 07:00:35.182383+00	1154	2	t		1
433	2011-07-20 07:42:52.189926+00	1162	2	f		1
290	2011-05-16 05:09:58.873882+00	798	2	t		1
298	2011-05-16 05:10:19.504463+00	806	2	t		1
299	2011-05-16 05:55:25.86157+00	814	2	t		2
330	2011-05-23 03:20:48.016173+00	894	1	f		2
267	2011-05-09 07:08:46.14578+00	751	2	f		1
267	2011-05-09 07:09:37.720713+00	753	1	f	Changed language to javascript	2
267	2011-05-16 06:53:24.638528+00	822	1	f		3
211	2011-04-21 19:47:27.626437+00	575	\N	f	The global variables startx and starty will make this code hard to reuse.  Can we factor those out somehow?  Perhaps mouse can take them as pointers?	1
211	2011-05-16 19:33:09.229775+00	830	\N	t	It's not possible to change the declaration of the mouse callback function, since that interface is specified by GLUT. \n\nIt's possible to mitigate the namespace pollution a bit by putting the snippet in a seperate file and marking the global variables static (so only the functions get exported)...	2
333	2011-05-23 03:54:38.078749+00	899	1	t		1
306	2011-05-18 00:25:16.671684+00	838	1	f		6
364	2011-06-03 08:37:10.992631+00	999	1	t		1
303	2011-05-18 09:05:00.064633+00	846	1	t	improved formatting slightly, added elt dependency	3
311	2011-05-19 23:07:46.695588+00	854	1	t	Changed to diagonal based version which handles finite lists.	2
335	2011-05-23 22:40:44.493704+00	909	1	f		4
317	2011-05-19 23:20:23.03788+00	862	1	t		1
401	2011-06-28 04:25:52.956218+00	1094	2	f		2
320	2011-05-20 04:39:49.472003+00	870	1	f		3
325	2011-05-21 03:07:04.969702+00	878	1	t		1
339	2011-05-25 07:36:25.947202+00	919	29	f	This entry can be deleted, subsequences in Data.List does the same.	1
327	2011-05-21 03:47:42.609409+00	886	1	f		3
343	2011-05-26 20:44:38.471336+00	929	1	t		2
367	2011-06-07 04:23:34.61218+00	1009	1	f		2
347	2011-05-26 21:11:42.865879+00	939	1	t		2
403	2011-06-28 07:23:43.364068+00	1103	2	t		3
48	2011-03-29 20:17:04.371372+00	198	\N	f		5
48	2011-05-27 10:04:34.464442+00	948	1	t		6
222	2011-05-27 23:15:13.973242+00	957	1	t		2
371	2011-06-10 05:45:31.74507+00	1019	1	f		1
73	2011-05-31 08:35:25.586538+00	966	2	f		7
355	2011-06-01 01:25:22.520037+00	975	1	t		1
357	2011-06-01 19:32:50.935069+00	983	1	f		2
375	2011-06-10 10:39:26.265011+00	1028	1	f		1
358	2011-06-03 07:44:06.641148+00	991	1	t		4
377	2011-06-11 10:31:35.717069+00	1036	1	f		4
407	2011-07-08 08:37:16.545874+00	1113	1	f		2
383	2011-06-11 10:43:23.061294+00	1044	1	t		1
385	2011-06-14 05:34:41.402918+00	1052	1	t	Return the target, jQuery style	2
411	2011-07-09 13:48:56.97851+00	1123	1	t		1
388	2011-06-14 21:01:08.128478+00	1059	1	f		1
388	2011-06-14 21:08:44.582293+00	1066	1	t	Remove double of	6
392	2011-06-18 20:51:51.579962+00	1073	1	t		1
379	2011-06-18 21:05:07.688798+00	1080	1	t		4
397	2011-06-27 13:28:54.444565+00	1087	29	t	Note: Throws an error for the empty list.	1
294	2011-07-13 07:38:16.982795+00	1139	2	f		4
293	2011-07-13 07:17:29.559867+00	1131	2	f		2
293	2011-07-20 06:30:24.560953+00	1147	2	t		5
421	2011-07-20 07:00:59.040477+00	1155	2	t		3
433	2011-07-20 07:43:01.40443+00	1163	2	t		2
360	2011-06-03 07:45:26.30957+00	992	1	f		1
330	2011-05-23 03:20:59.436902+00	895	1	f		3
291	2011-05-16 05:09:59.69852+00	799	2	f		1
299	2011-05-16 05:10:21.788244+00	807	2	f		1
331	2011-06-06 07:54:08.240143+00	1000	1	t	Added dependency	2
332	2011-05-23 03:54:44.487192+00	900	1	f		2
254	2011-05-16 06:24:10.073312+00	815	1	f		3
335	2011-05-23 23:12:09.800231+00	910	1	t		5
401	2011-06-28 04:26:05.078511+00	1095	2	f		3
19	2011-05-25 07:41:26.858069+00	920	2	t		6
367	2011-06-07 04:23:49.822575+00	1010	1	f		3
307	2011-05-18 00:25:44.460421+00	839	1	t	Added type signature	3
306	2011-05-17 09:55:10.993265+00	831	29	f		1
345	2011-05-26 20:52:21.167616+00	930	1	f		1
272	2011-05-18 09:59:57.871262+00	847	1	t	Added preserving screen position dependency	7
372	2011-06-10 05:45:32.038575+00	1020	1	t		1
310	2011-05-19 23:07:57.596643+00	855	1	f		2
316	2011-05-19 23:20:43.642833+00	863	1	t		2
349	2011-05-26 21:13:03.928696+00	940	1	f		1
320	2011-05-20 04:40:26.135276+00	871	1	t		4
404	2011-06-28 07:24:28.892412+00	1104	2	t		1
25	2011-03-28 02:09:29.344533+00	117	\N	f		9
324	2011-05-21 03:07:11.878594+00	879	1	f		2
25	2011-03-28 04:10:10.036005+00	118	1	f		10
328	2011-05-21 03:48:32.28697+00	887	1	t	Added foreach dependency	2
25	2011-03-29 09:23:08.716158+00	159	\N	f		11
376	2011-06-10 10:39:26.527587+00	1029	1	t		1
25	2011-05-27 10:04:58.974017+00	949	1	t		12
73	2011-05-27 23:38:36.61841+00	958	1	f		3
73	2011-05-31 09:33:42.460548+00	967	1	t		8
382	2011-06-11 10:43:33.093144+00	1045	1	f		2
354	2011-06-01 01:26:10.014996+00	976	1	t		2
407	2011-07-08 08:37:46.676802+00	1114	1	f	Citation	3
164	2011-06-01 19:48:54.289361+00	984	1	f		6
384	2011-06-14 05:36:50.365946+00	1053	1	f		2
412	2011-07-09 13:48:57.374296+00	1124	1	t		1
389	2011-06-14 21:01:08.694222+00	1060	1	f		1
414	2011-07-13 07:18:41.624939+00	1132	2	t		1
301	2011-05-16 09:22:26.673639+00	823	1	f		1
390	2011-06-18 18:48:34.858134+00	1067	1	f		1
301	2011-07-13 07:40:12.77999+00	1140	1	t	ping	3
418	2011-07-20 06:46:36.642059+00	1148	2	t		1
379	2011-06-11 10:32:39.541334+00	1037	1	f		1
394	2011-06-18 21:07:46.836094+00	1081	1	t	Changed to calling a function when parsed	3
393	2011-06-18 21:02:12.665034+00	1074	1	f		1
430	2011-07-20 07:27:24.200683+00	1156	2	t		1
33	2011-03-26 10:15:34.422537+00	87	1	f		2
33	2011-03-29 12:53:54.939909+00	183	\N	f		3
33	2011-06-28 03:45:55.087723+00	1088	2	t		12
416	2011-07-25 07:17:22.100074+00	1164	2	f		3
292	2011-05-16 05:10:00.022631+00	800	2	t		1
300	2011-05-16 05:10:22.089944+00	808	2	t		1
254	2011-05-16 06:31:07.770159+00	816	1	f		4
402	2011-06-28 06:23:31.781065+00	1096	2	f		1
332	2011-05-23 03:55:18.324677+00	901	1	f		3
307	2011-05-17 09:55:11.436291+00	832	29	f		1
306	2011-05-18 00:29:54.731745+00	840	1	t		7
302	2011-05-16 09:59:22.374102+00	824	2	f		1
310	2011-05-19 20:09:06.87495+00	848	29	f		1
310	2011-05-19 23:08:07.58129+00	856	1	t		3
318	2011-05-19 23:22:15.49465+00	864	1	f		1
189	2011-05-25 07:42:49.822843+00	921	2	t	Changed to Haskell naming conventions	5
322	2011-05-20 05:12:35.474188+00	872	1	f		1
324	2011-05-21 03:07:23.016606+00	880	1	f		3
365	2011-06-07 04:20:47.325271+00	1001	1	f		1
327	2011-05-21 03:53:01.933862+00	888	1	t		4
346	2011-05-26 20:52:21.875433+00	931	1	f		1
350	2011-05-26 21:13:04.187279+00	941	1	t		1
367	2011-06-07 04:26:02.045675+00	1011	1	t		4
405	2011-06-30 07:46:43.567984+00	1105	1	f		1
371	2011-06-10 05:45:59.646968+00	1021	1	f		2
375	2011-06-10 10:41:09.027186+00	1030	1	t		2
62	2011-05-27 10:05:36.752296+00	950	1	f		9
62	2011-03-29 09:58:23.444607+00	161	\N	f		6
62	2011-03-29 11:18:06.451567+00	162	\N	f		7
62	2011-03-29 11:18:51.802008+00	163	\N	f		8
95	2011-05-29 18:39:07.998734+00	959	38	t	changed list comprehension to generator expression	2
377	2011-06-11 10:37:17.048481+00	1038	1	t		5
351	2011-05-31 23:10:51.070678+00	968	1	f		1
407	2011-07-08 08:38:44.93942+00	1115	1	f		4
382	2011-06-11 10:43:43.190119+00	1046	1	f		3
356	2011-06-01 09:42:01.662886+00	977	1	f		1
164	2011-06-01 19:49:11.798337+00	985	1	t		7
361	2011-06-03 07:45:26.69765+00	993	1	t		1
386	2011-06-14 08:20:31.059382+00	1054	1	f		1
410	2011-07-09 13:49:29.632806+00	1125	1	f	Deps	2
388	2011-06-14 21:01:18.479901+00	1061	1	f		2
391	2011-06-18 18:48:35.431841+00	1068	1	t		1
308	2011-07-13 08:24:00.044084+00	1141	2	t		2
293	2011-07-13 07:19:56.720126+00	1133	2	f		3
394	2011-06-18 21:02:13.464878+00	1075	1	f		1
393	2011-06-18 21:08:10.721862+00	1082	1	t		5
33	2011-05-23 23:14:03.942355+00	911	1	f		11
33	2011-03-29 13:00:13.241356+00	185	2	f		4
33	2011-03-29 13:20:07.088633+00	189	2	f		5
33	2011-04-03 05:00:50.03744+00	299	2	f		6
33	2011-04-17 06:08:04.750474+00	483	1	f		7
33	2011-04-20 03:48:31.502999+00	511	7	f		8
33	2011-04-20 14:15:55.142092+00	528	17	f		9
33	2011-04-21 11:30:21.704208+00	568	23	f		10
30	2011-04-17 06:13:36.256307+00	488	1	f		4
30	2011-04-20 03:46:12.236652+00	510	7	f		5
30	2011-04-20 14:15:20.218509+00	527	17	f		6
30	2011-04-20 23:44:57.706747+00	556	24	f		7
30	2011-04-21 11:30:01.095061+00	567	23	f		8
30	2011-05-08 02:38:25.013122+00	686	1	f		9
30	2011-06-28 03:46:16.494485+00	1089	2	t		11
419	2011-07-20 06:46:37.056121+00	1149	2	f		1
419	2011-07-20 07:27:59.483062+00	1157	2	t		2
416	2011-07-25 07:17:42.879663+00	1165	2	t		4
303	2011-05-16 09:59:22.666342+00	825	2	f		1
297	2011-05-16 05:11:22.526867+00	809	2	t		2
324	2011-05-21 03:09:09.219696+00	881	1	t		4
254	2011-05-16 06:31:30.517688+00	817	1	f		5
311	2011-05-19 20:09:07.19824+00	849	29	f		1
329	2011-05-22 09:27:31.241856+00	889	\N	f	xs[0] is never visited	1
314	2011-05-19 23:18:59.423264+00	857	1	f		1
306	2011-05-17 09:57:31.266394+00	833	29	f		2
332	2011-05-23 04:00:22.707618+00	902	1	t		4
319	2011-05-19 23:22:15.766125+00	865	1	t		1
302	2011-05-18 06:24:40.208302+00	841	2	f		2
323	2011-05-20 05:12:36.0238+00	873	1	f		1
406	2011-06-30 07:46:44.215908+00	1106	1	f		1
409	2011-07-09 13:50:19.576635+00	1126	1	t		5
2	2011-03-24 03:25:03.536321+00	2	\N	f		1
2	2011-03-24 03:32:21.40101+00	7	\N	t		2
3	2011-03-24 03:27:33.009991+00	3	\N	f		1
3	2011-03-24 03:37:55.774714+00	11	\N	t		2
4	2011-03-24 03:27:33.574024+00	4	\N	f		1
4	2011-03-24 03:32:22.565613+00	8	\N	t		2
5	2011-03-24 03:28:21.652293+00	5	\N	f		1
5	2011-03-24 03:38:02.450116+00	12	\N	f		2
5	2011-03-24 06:41:53.411593+00	13	\N	t		3
6	2011-03-24 03:28:22.196256+00	6	\N	f		1
6	2011-03-24 03:37:09.937875+00	9	\N	t		2
7	2011-03-26 08:18:31.330374+00	14	\N	f		1
7	2011-03-26 08:18:39.617851+00	16	\N	f		2
7	2011-03-26 08:18:57.439007+00	17	\N	f		3
7	2011-03-26 08:21:56.613878+00	18	\N	t		4
8	2011-03-26 08:18:31.862361+00	15	\N	t		1
10	2011-03-26 08:30:29.063341+00	20	\N	t		1
11	2011-03-26 08:35:25.041723+00	24	\N	f		1
11	2011-03-26 08:35:34.005102+00	26	\N	f		2
11	2011-03-26 08:35:42.546715+00	27	\N	f		3
11	2011-03-26 08:36:11.679454+00	28	\N	t		4
12	2011-03-26 08:35:25.585711+00	25	\N	f		1
12	2011-03-29 12:53:50.647929+00	181	\N	f		2
12	2011-03-29 13:04:16.630798+00	186	4	t		3
13	2011-03-26 08:36:36.811721+00	29	\N	f		1
13	2011-03-26 08:37:07.434963+00	31	\N	f		2
13	2011-03-26 08:38:58.713345+00	33	\N	f		3
13	2011-03-26 08:44:41.768428+00	34	\N	t		4
15	2011-03-26 09:02:52.346807+00	35	\N	f		1
15	2011-03-26 09:05:07.069598+00	38	1	f		2
15	2011-03-26 09:05:19.551395+00	39	1	f		3
15	2011-03-26 09:09:44.771245+00	40	1	t		4
16	2011-03-26 09:02:52.930408+00	36	\N	f		1
16	2011-03-26 09:05:01.316298+00	37	1	f		2
16	2011-03-28 05:02:01.576115+00	119	\N	t		3
17	2011-03-26 09:11:14.0796+00	41	\N	f		1
17	2011-03-26 09:11:56.830856+00	43	1	f		2
17	2011-03-26 09:12:02.467916+00	44	1	t		3
18	2011-03-26 09:11:14.615649+00	42	\N	f		1
18	2011-03-26 09:12:08.265947+00	45	1	t		2
21	2011-03-26 09:24:05.377177+00	51	\N	f		1
21	2011-03-26 09:24:13.510381+00	53	1	f		2
21	2011-03-26 09:24:22.202137+00	54	1	f		3
21	2011-03-26 09:24:50.67343+00	55	1	t		4
22	2011-03-26 09:24:05.913226+00	52	\N	t		1
23	2011-03-26 09:26:53.383913+00	56	\N	f		1
23	2011-03-26 09:27:02.098067+00	58	1	f		2
23	2011-03-26 09:27:40.576572+00	59	1	f		3
23	2011-03-26 09:28:23.649962+00	60	1	t		4
24	2011-03-26 09:26:53.973063+00	57	\N	f		1
24	2011-03-26 09:28:34.275751+00	61	1	t		2
360	2011-06-03 07:45:34.283186+00	994	1	f		2
366	2011-06-07 04:20:48.239139+00	1002	1	f		1
409	2011-07-09 13:38:35.076313+00	1116	1	f		1
28	2011-03-26 09:44:01.741039+00	71	\N	t		1
31	2011-03-26 09:59:11.278235+00	81	\N	f		1
31	2011-03-26 09:59:29.193756+00	83	1	f		2
31	2011-03-26 09:59:40.468602+00	84	1	t		3
32	2011-03-26 09:59:11.842279+00	82	\N	f		1
32	2011-03-26 09:59:50.2935+00	85	1	t		2
34	2011-03-26 10:50:56.434699+00	91	\N	f		1
34	2011-03-26 10:52:12.189963+00	94	1	f		2
34	2011-03-26 10:52:21.87614+00	95	1	t		3
35	2011-03-26 10:50:56.99869+00	92	\N	f		1
35	2011-03-26 10:52:06.49716+00	93	1	f		2
35	2011-03-26 10:53:26.022801+00	96	1	t		3
36	2011-03-26 11:29:49.565969+00	97	\N	f		1
36	2011-03-26 11:30:28.462824+00	100	1	f		2
36	2011-03-26 11:31:02.875827+00	101	1	t		3
37	2011-03-26 11:29:50.218413+00	98	\N	f		1
37	2011-03-26 11:30:01.585331+00	99	1	t		2
38	2011-03-26 11:31:24.32082+00	102	\N	f		1
38	2011-03-26 11:31:42.562339+00	105	1	f		2
38	2011-03-26 11:32:06.920741+00	106	1	f		3
38	2011-03-26 11:40:48.756721+00	113	1	t		4
40	2011-03-26 11:32:36.113138+00	107	\N	f		1
40	2011-03-26 11:32:53.974014+00	110	1	f		2
40	2011-03-26 11:33:08.364123+00	111	1	f		3
40	2011-03-26 11:40:25.406809+00	112	1	t		4
416	2011-07-19 05:21:03.897477+00	1142	46	f		1
339	2011-05-25 08:30:13.554814+00	922	1	t	In cases like this I just change the snippet to delegate to the standard library function.  Sometimes I also deprecate it if there are no other language implementations.	2
345	2011-05-26 20:53:15.679519+00	932	1	f		2
9	2011-03-26 08:30:28.439063+00	19	\N	f		1
349	2011-05-26 21:13:59.839947+00	942	1	t		2
9	2011-03-26 08:30:42.898248+00	21	\N	f		2
9	2011-03-26 08:31:27.537+00	22	\N	f		3
9	2011-03-26 08:34:38.133025+00	23	\N	f		4
1	2011-03-24 03:25:02.974715+00	1	\N	f		1
1	2011-03-24 03:37:44.736693+00	10	\N	f		2
25	2011-03-26 09:33:56.734926+00	62	\N	f		1
25	2011-03-26 09:34:05.669017+00	64	1	f		2
25	2011-03-26 09:34:29.486843+00	65	1	f		3
25	2011-03-26 09:36:06.110424+00	66	1	f		4
25	2011-03-26 09:39:06.434186+00	68	1	f		5
25	2011-03-27 05:34:17.912596+00	114	\N	f		6
25	2011-03-27 05:36:21.248628+00	115	\N	f		7
25	2011-03-27 05:37:47.046812+00	116	1	f		8
62	2011-05-27 10:06:05.077335+00	951	1	f	Changed spec href to new style	10
47	2011-05-29 18:49:12.108742+00	960	38	f	Re-implementation using generator expressions	2
352	2011-05-31 23:10:51.350759+00	969	1	t		1
357	2011-06-03 07:01:02.875782+00	986	1	t		3
357	2011-06-01 09:42:02.352563+00	978	1	f		1
293	2011-05-16 05:10:02.154181+00	801	2	f		1
293	2011-07-13 07:20:20.89052+00	1134	2	f		4
27	2011-03-26 09:44:01.168432+00	70	\N	f		1
30	2011-05-23 23:17:06.012055+00	912	1	f		10
30	2011-03-26 09:56:41.124354+00	76	\N	f		1
30	2011-03-26 09:57:52.193201+00	79	1	f		2
30	2011-04-17 06:08:13.027185+00	484	1	f		3
420	2011-07-20 06:47:51.944672+00	1150	2	t		1
431	2011-07-20 07:38:48.953496+00	1158	2	f		1
434	2011-08-29 09:49:40.58743+00	1166	49	t		1
41	2011-03-26 11:32:36.673275+00	108	\N	f		1
41	2011-03-26 11:32:45.239154+00	109	1	f		2
41	2011-03-28 05:02:05.056692+00	121	\N	t		3
45	2011-03-29 05:22:44.736226+00	130	\N	f		1
45	2011-03-29 05:34:14.495133+00	134	\N	t		2
365	2011-06-07 04:20:58.464086+00	1003	1	f		2
370	2011-06-07 07:34:19.201285+00	1013	1	t		1
371	2011-06-10 05:46:11.827475+00	1022	1	t		3
50	2011-03-29 08:07:55.495371+00	150	1	f	It's just all wrong if it isn't.  Will strip off wrong amounts, will return wrong thing as second result, etc.	1
50	2011-03-29 08:16:05.039902+00	151	2	t	Only if you assume that the universe exists, silly!	2
377	2011-06-11 10:19:16.503825+00	1031	1	f		1
63	2011-03-29 09:08:15.346346+00	153	\N	f		1
63	2011-03-29 09:11:58.76987+00	155	\N	t		2
64	2011-03-29 09:19:37.868811+00	156	\N	t		1
66	2011-03-29 12:01:40.811953+00	165	2	f		1
66	2011-03-29 12:22:10.131506+00	175	\N	f		2
66	2011-03-29 12:39:52.715591+00	177	\N	f		3
66	2011-03-29 12:44:14.107822+00	178	2	f		4
66	2011-03-29 12:47:11.696467+00	179	2	f		5
66	2011-03-29 12:53:08.011403+00	180	\N	f		6
66	2011-03-29 13:14:58.550212+00	187	2	f		7
66	2011-03-29 13:16:26.254991+00	188	\N	f		8
66	2011-03-29 13:36:18.241355+00	191	\N	f		9
66	2011-03-29 13:36:58.767729+00	192	\N	f		10
66	2011-03-29 13:39:26.448308+00	193	\N	f		11
66	2011-03-29 13:41:47.852571+00	194	\N	f		12
66	2011-03-29 13:45:30.691498+00	195	\N	f		13
66	2011-03-29 13:47:44.142498+00	196	\N	f		14
66	2011-04-03 01:53:50.004999+00	243	\N	f		15
66	2011-04-03 01:55:05.19438+00	244	2	f		16
66	2011-04-03 01:56:44.438529+00	245	2	f		17
66	2011-04-03 02:00:45.556149+00	246	2	t		18
67	2011-03-29 12:02:45.090093+00	169	2	t	none available	1
68	2011-03-29 12:19:15.606227+00	170	2	f		1
68	2011-03-29 12:19:25.335494+00	172	2	f		2
68	2011-03-29 12:19:41.293629+00	173	2	f		3
68	2011-03-29 12:20:00.964486+00	174	2	t		4
70	2011-03-29 12:39:01.311272+00	176	2	f	If you call this with text == "" or similar all-whitespace variants, this method crashes due to attempts to treat [] like a string.	1
70	2011-03-29 13:21:17.496173+00	190	2	t	I fixed this!	2
72	2011-03-30 07:23:06.432827+00	199	\N	t		1
74	2011-03-31 00:21:57.502912+00	201	\N	t		1
75	2011-03-31 10:21:24.189817+00	202	2	f		1
75	2011-03-31 10:21:37.103011+00	204	2	f		2
75	2011-03-31 10:21:52.44581+00	205	2	f		3
75	2011-04-03 00:16:01.058768+00	237	2	f		4
75	2011-04-03 00:16:05.347058+00	238	2	t		5
77	2011-03-31 12:49:05.774322+00	206	1	f	I don't think this implementation matches the spec.  I would expect xs = [1,2,3] ; pop_random(xs) -> 2 ; xs = [1,3], but as it stands the original sequence is unmodified.  This might be a spec bug.	1
77	2011-04-03 00:17:04.130694+00	240	2	t	This was a spec bug.  I wanted random_item.	2
79	2011-04-01 16:11:29.882227+00	209	1	t		1
81	2011-04-01 16:13:50.492769+00	213	1	f		1
81	2011-04-01 16:19:33.992339+00	217	1	f		2
81	2011-04-01 16:42:33.406844+00	228	1	t		3
82	2011-04-01 16:21:19.463358+00	218	1	f		1
82	2011-04-01 16:21:24.920714+00	220	1	f		2
82	2011-04-01 16:21:34.657569+00	221	1	f		3
82	2011-04-01 16:21:51.981634+00	222	1	t		4
83	2011-04-01 16:21:19.606774+00	219	1	t		1
85	2011-04-01 16:35:48.947677+00	224	1	f		1
85	2011-04-01 17:33:08.851605+00	229	1	t		2
86	2011-04-02 19:25:18.341725+00	230	1	f		1
86	2011-04-02 19:27:28.133648+00	232	1	f		2
86	2011-04-02 19:28:04.111244+00	233	1	f		3
86	2011-04-02 19:37:02.331896+00	234	1	f		4
86	2011-04-02 19:43:03.027735+00	235	1	t		5
87	2011-04-02 19:25:18.577707+00	231	1	t		1
88	2011-04-03 02:27:15.413267+00	247	1	f		1
88	2011-04-03 02:27:20.538321+00	249	1	f		2
88	2011-04-03 02:27:28.405127+00	250	1	f		3
88	2011-04-03 02:27:49.52616+00	251	1	t		4
89	2011-04-03 02:27:15.551169+00	248	1	t		1
90	2011-04-03 02:30:46.969979+00	252	2	f		1
90	2011-04-03 02:30:56.8842+00	254	2	f		2
90	2011-04-03 02:38:31.495487+00	256	2	t		3
91	2011-04-03 02:30:47.220029+00	253	2	t		1
92	2011-04-03 02:41:37.021173+00	258	1	f		1
92	2011-04-03 02:41:57.403123+00	260	1	f		2
92	2011-04-03 02:42:39.107603+00	261	1	f		3
92	2011-04-03 02:47:25.241361+00	264	1	f		4
92	2011-04-03 02:55:23.646505+00	268	1	t		5
93	2011-04-03 02:41:37.324643+00	259	1	t		1
96	2011-04-03 03:33:43.427411+00	271	1	f		1
96	2011-04-03 03:33:47.341238+00	273	1	f		2
96	2011-04-03 03:33:50.621862+00	274	1	f		3
96	2011-04-03 03:33:51.219063+00	275	1	f		4
96	2011-04-03 03:34:03.161957+00	276	1	f		5
96	2011-04-03 03:34:29.152331+00	277	1	t		6
97	2011-04-03 03:33:43.712485+00	272	1	t		1
98	2011-04-03 03:35:24.769611+00	278	1	f		1
98	2011-04-03 03:35:35.259566+00	281	1	f		2
94	2011-04-03 02:50:50.067404+00	265	1	f		1
94	2011-04-03 02:51:01.650185+00	267	1	f		2
94	2011-04-03 02:55:45.109833+00	269	1	f		3
48	2011-03-29 06:50:45.73173+00	142	\N	f		1
48	2011-03-29 06:51:18.036118+00	146	1	f		2
48	2011-03-29 06:51:59.242254+00	147	1	f		3
48	2011-03-29 06:55:18.684032+00	148	1	f		4
84	2011-04-01 16:35:48.800005+00	223	1	f		1
84	2011-04-01 16:35:57.399683+00	225	1	f		2
84	2011-04-01 16:36:10.440147+00	226	1	f		3
84	2011-04-01 16:39:15.253043+00	227	1	f		4
42	2011-03-28 06:59:23.006643+00	122	\N	f		1
62	2011-03-29 09:08:15.142185+00	152	\N	f		1
62	2011-03-29 09:09:28.140003+00	154	\N	f		2
62	2011-03-29 09:21:36.671994+00	157	\N	f		3
62	2011-03-29 09:22:35.505245+00	158	\N	f		4
62	2011-03-29 09:24:20.617149+00	160	\N	f		5
42	2011-03-28 06:59:32.850933+00	124	1	f		2
42	2011-03-28 06:59:55.097034+00	125	1	f		3
42	2011-03-28 07:08:58.489372+00	126	1	f		4
42	2011-03-28 08:58:25.217999+00	128	1	f		5
44	2011-03-29 05:22:44.224304+00	129	\N	f		1
95	2011-04-03 02:50:50.374776+00	266	1	f		1
43	2011-03-28 06:59:23.463672+00	123	\N	f		1
47	2011-03-29 05:37:07.753204+00	137	\N	f		1
43	2011-03-28 07:09:08.668191+00	127	\N	f		2
73	2011-03-31 00:21:57.042362+00	200	\N	f		1
73	2011-03-31 17:17:19.028971+00	207	\N	f		2
380	2011-06-11 10:38:27.311136+00	1039	1	f		1
382	2011-06-11 10:46:46.684631+00	1047	1	t		4
98	2011-04-03 03:35:47.096488+00	282	1	f		3
98	2011-04-03 03:37:03.366076+00	283	1	f		4
98	2011-04-03 03:42:19.665998+00	284	1	f		5
98	2011-04-03 03:49:17.786553+00	285	1	f		6
98	2011-04-03 03:49:56.157025+00	287	1	t		7
99	2011-04-03 03:35:25.265135+00	279	1	f		1
99	2011-04-03 03:49:37.702643+00	286	1	f		2
99	2011-04-03 05:07:03.331768+00	300	\N	t		3
100	2011-04-03 03:35:25.623746+00	280	1	t		1
103	2011-04-03 04:43:36.690147+00	295	2	t		1
104	2011-04-03 04:43:36.959778+00	296	2	f		1
104	2011-04-03 04:44:32.68753+00	297	2	t		2
105	2011-04-03 05:09:56.920702+00	301	2	f		1
105	2011-04-03 05:10:37.463542+00	303	2	f		2
105	2011-04-03 05:11:24.029623+00	304	2	t		3
107	2011-04-03 05:13:03.454613+00	305	2	f		1
107	2011-04-03 05:13:11.983621+00	307	2	f		2
107	2011-04-03 05:13:26.182758+00	308	2	t		3
108	2011-04-03 05:13:03.712626+00	306	2	t		1
109	2011-04-03 05:14:06.102868+00	309	2	f		1
109	2011-04-03 05:18:02.091013+00	320	2	f		2
109	2011-04-03 05:18:35.421548+00	322	2	f		3
109	2011-04-03 05:32:47.708549+00	333	1	t		4
110	2011-04-03 05:14:06.347297+00	310	2	f		1
110	2011-04-03 05:19:11.825726+00	323	2	t		2
111	2011-04-03 05:15:29.246216+00	311	2	f		1
111	2011-04-03 05:15:37.662292+00	313	2	f		2
111	2011-04-03 05:15:47.530305+00	314	2	f		3
111	2011-04-03 05:16:02.041292+00	315	2	t		4
112	2011-04-03 05:15:29.484845+00	312	2	t		1
113	2011-04-03 05:16:52.621309+00	316	2	f		1
113	2011-04-03 05:17:00.155925+00	318	2	f		2
113	2011-04-03 05:17:13.524801+00	319	2	t		3
114	2011-04-03 05:16:52.88542+00	317	2	t		1
116	2011-04-03 05:21:29.866676+00	324	\N	t		1
117	2011-04-03 05:21:51.464311+00	325	\N	t		1
118	2011-04-03 05:21:52.037339+00	326	\N	t		1
119	2011-04-03 05:28:55.307435+00	327	\N	t		1
120	2011-04-03 05:28:55.878028+00	328	\N	t		1
121	2011-04-03 05:30:49.013817+00	329	\N	t		1
122	2011-04-03 05:30:49.556193+00	330	\N	t		1
123	2011-04-03 05:32:03.036787+00	331	\N	t		1
124	2011-04-03 05:32:03.673458+00	332	\N	t		1
26	2011-03-26 09:33:57.277635+00	63	\N	f		1
26	2011-03-26 09:37:04.504369+00	67	\N	f		2
26	2011-03-26 09:42:13.574332+00	69	1	f		3
26	2011-03-26 10:37:01.755565+00	88	\N	f		4
26	2011-03-26 10:38:22.0889+00	89	1	f		5
26	2011-03-26 10:47:08.21719+00	90	\N	f		6
26	2011-03-29 12:53:52.995778+00	182	\N	f		7
26	2011-04-06 06:32:05.03054+00	417	\N	f		8
26	2011-04-09 21:38:50.535149+00	442	\N	f		9
26	2011-04-09 21:49:46.430025+00	443	\N	t		10
126	2011-04-03 23:07:15.191398+00	335	\N	f		1
126	2011-04-03 23:11:25.922201+00	337	1	t		2
125	2011-04-03 23:07:14.39535+00	334	\N	f		1
125	2011-04-03 23:07:22.927071+00	336	1	f		2
125	2011-04-03 23:11:31.799189+00	338	1	f		3
125	2011-04-03 23:11:52.364962+00	339	1	f		4
125	2011-04-03 23:13:23.671282+00	340	1	f		5
125	2011-04-04 15:51:22.054868+00	386	\N	f		6
125	2011-04-04 15:52:47.596936+00	387	\N	f		7
125	2011-04-04 15:55:14.475962+00	388	\N	t		8
137	2011-04-04 05:47:34.536546+00	363	\N	f		1
137	2011-04-04 05:47:41.661151+00	365	1	f		2
137	2011-04-04 05:47:54.86558+00	366	1	f		3
137	2011-04-04 05:49:10.014204+00	367	1	t		4
106	2011-04-03 05:09:57.120882+00	302	2	f		1
106	2011-04-04 05:04:46.517197+00	341	\N	t		2
127	2011-04-04 05:17:47.210322+00	342	\N	t		1
128	2011-04-04 05:17:47.67072+00	343	\N	t		1
139	2011-04-04 05:50:19.621078+00	369	\N	f		1
139	2011-04-04 05:50:29.388588+00	371	1	f		2
139	2011-04-04 05:50:40.468556+00	372	1	f		3
139	2011-04-04 05:52:06.204536+00	374	1	f		4
139	2011-04-17 06:06:59.039458+00	482	1	t		5
130	2011-04-04 05:19:46.653282+00	345	\N	t		1
129	2011-04-04 05:19:46.142779+00	344	\N	f		1
129	2011-04-04 05:19:58.464139+00	346	1	f		2
129	2011-04-04 05:20:30.106663+00	347	1	t		3
131	2011-04-04 05:23:33.574244+00	348	\N	t		1
132	2011-04-04 05:23:33.997456+00	349	\N	t		1
146	2011-04-06 03:33:11.027212+00	390	\N	t		1
140	2011-04-04 05:50:20.040015+00	370	\N	f		1
140	2011-04-04 05:51:04.237444+00	373	1	t		2
135	2011-04-04 05:31:35.772438+00	355	\N	f		1
135	2011-04-04 05:31:45.10065+00	357	1	f		2
135	2011-04-04 05:33:01.364854+00	358	1	f		3
135	2011-04-04 05:40:55.404751+00	360	1	t		4
76	2011-03-31 10:21:24.389675+00	203	2	f		1
76	2011-04-03 00:12:14.147092+00	236	\N	f		2
76	2011-04-03 00:16:32.009113+00	239	2	f		3
76	2011-04-03 00:18:15.910395+00	241	2	f		4
76	2011-04-03 00:18:49.095702+00	242	2	f		5
76	2011-04-03 02:37:21.496118+00	255	\N	f		6
76	2011-04-03 02:40:50.461406+00	257	2	f		7
76	2011-04-03 02:43:31.65392+00	262	2	f		8
76	2011-04-03 02:44:16.412224+00	263	2	f		9
76	2011-04-03 03:28:57.373763+00	270	2	f		10
76	2011-04-04 05:39:50.728567+00	359	2	f		11
76	2011-04-04 05:43:25.323803+00	361	2	t		12
136	2011-04-04 05:31:36.380299+00	356	\N	f		1
136	2011-04-04 05:45:16.533461+00	362	1	t		2
142	2011-04-04 05:52:36.97391+00	376	\N	f		1
142	2011-04-06 08:45:08.862213+00	418	1	t		2
153	2011-04-09 17:21:33.694517+00	422	\N	f		1
153	2011-04-09 17:21:50.74864+00	424	1	f		2
153	2011-04-09 17:21:56.397955+00	425	1	f		3
153	2011-04-09 17:26:14.390456+00	426	1	f		4
153	2011-04-09 17:27:03.082426+00	427	1	t		5
145	2011-04-06 03:33:10.548293+00	389	\N	f		1
145	2011-04-06 03:33:20.780435+00	391	1	f		2
145	2011-04-06 03:33:47.27726+00	392	1	f		3
145	2011-04-06 03:38:09.592551+00	393	1	t		4
141	2011-04-04 05:52:36.428506+00	375	\N	f		1
141	2011-04-04 05:52:43.917774+00	377	1	f		2
141	2011-04-04 05:53:20.173526+00	378	1	f		3
141	2011-04-04 05:57:15.757163+00	379	1	t		4
150	2011-04-06 04:44:25.874055+00	407	1	t		1
144	2011-04-04 05:58:45.08219+00	381	\N	t		1
149	2011-04-06 04:44:25.633687+00	406	1	f		1
149	2011-04-06 04:44:46.720459+00	408	1	t		2
143	2011-04-04 05:58:44.608513+00	380	\N	f		1
143	2011-04-04 05:58:50.54814+00	382	1	f		2
143	2011-04-04 05:59:09.600284+00	383	1	f		3
143	2011-04-04 06:02:47.396747+00	384	1	f		4
143	2011-04-04 06:03:03.126399+00	385	1	t		5
80	2011-04-01 16:13:50.345315+00	212	1	f		1
80	2011-04-01 16:13:56.992106+00	214	1	f		2
80	2011-04-01 16:14:09.993127+00	215	1	f		3
80	2011-04-01 16:14:42.687255+00	216	1	f		4
80	2011-04-07 01:40:53.091674+00	419	\N	t		5
78	2011-04-01 16:11:29.750838+00	208	1	f		1
78	2011-04-01 16:11:34.974961+00	210	1	f		2
78	2011-04-01 16:11:47.133656+00	211	1	f		3
78	2011-04-07 01:41:02.238923+00	420	\N	f		4
78	2011-04-09 16:52:24.686056+00	421	1	t		5
152	2011-04-06 04:45:15.39707+00	410	1	f		1
152	2011-04-06 04:45:32.545924+00	411	1	t		2
155	2011-04-09 20:43:43.225801+00	428	\N	t		1
148	2011-04-06 03:38:36.120353+00	395	\N	f		1
148	2011-04-06 03:40:12.90526+00	398	1	f		2
148	2011-04-06 03:42:51.373393+00	399	1	f		3
148	2011-04-06 04:53:09.054302+00	413	\N	f		4
148	2011-04-06 05:45:32.0127+00	414	1	t		5
156	2011-04-09 20:46:00.185809+00	429	\N	t		1
157	2011-04-09 20:47:02.571192+00	430	\N	t		1
159	2011-04-09 20:48:48.469054+00	432	\N	t		1
160	2011-04-09 20:50:09.255852+00	433	\N	t		1
161	2011-04-09 20:50:09.82508+00	434	\N	t		1
162	2011-04-09 20:50:41.472851+00	435	\N	t		1
163	2011-04-09 20:50:42.068679+00	436	\N	t		1
165	2011-04-09 20:53:08.064668+00	438	\N	t		1
14	2011-03-26 08:36:37.354509+00	30	\N	f		1
14	2011-03-26 08:37:40.274092+00	32	\N	t		2
169	2011-04-11 08:56:55.578482+00	453	2	f		1
169	2011-04-18 05:09:38.909158+00	505	2	t		2
172	2011-04-11 09:00:23.551064+00	457	2	f		1
172	2011-04-18 09:55:44.246363+00	507	1	t		2
171	2011-04-11 08:57:26.913999+00	455	2	f		1
171	2011-04-11 08:58:16.215311+00	456	2	f		2
171	2011-04-17 10:43:44.18522+00	502	1	t		3
170	2011-04-11 08:57:26.623101+00	454	2	f		1
170	2011-04-17 10:42:13.966345+00	501	1	f		2
170	2011-04-17 10:44:32.117715+00	503	1	t		3
65	2011-03-29 12:01:40.584332+00	164	2	f		1
65	2011-03-29 12:02:02.35219+00	166	2	f		2
65	2011-03-29 12:02:17.32801+00	167	2	f		3
65	2011-03-29 12:02:25.91138+00	168	2	f		4
65	2011-04-18 09:56:51.715141+00	508	1	t		5
173	2011-04-11 09:00:23.861759+00	458	2	t		1
365	2011-06-07 04:21:10.404274+00	1004	1	f		3
175	2011-04-17 02:57:27.24356+00	460	\N	t		1
176	2011-04-17 03:03:54.429884+00	465	\N	f		1
176	2011-04-17 03:04:03.515419+00	467	1	f		2
176	2011-04-17 03:04:25.886729+00	468	1	f		3
176	2011-04-17 03:07:35.278348+00	470	1	t		4
177	2011-04-17 03:03:55.158382+00	466	\N	f		1
177	2011-04-17 03:05:30.39021+00	469	1	t		2
178	2011-04-17 04:45:40.767274+00	471	1	t		1
179	2011-04-17 04:45:41.090718+00	472	1	t		1
138	2011-04-04 05:47:34.989341+00	364	\N	f		1
138	2011-04-04 05:49:42.878177+00	368	1	f		2
138	2011-04-17 06:06:22.95554+00	481	1	t		3
71	2011-03-29 17:17:17.201014+00	197	1	f	I am still not sure what the naming convention should be.  This way is very java-esque, verbose, wordy, and specific (but not to the point of being formal, which is really where the ugliness is: trying to be specific without having a precise language to work with).  I think I would prefer terse with good disambiguation, if we can pull that off.  It is more technically challenging.	1
71	2011-04-17 06:13:52.52046+00	489	1	t	Fixed.	2
49	2011-03-29 06:50:46.103768+00	143	\N	f		1
49	2011-03-29 06:50:51.898172+00	144	1	f		2
49	2011-03-29 06:51:01.765094+00	145	1	f		3
49	2011-03-29 06:58:25.733298+00	149	1	f		4
49	2011-04-17 06:26:33.218256+00	498	1	t		5
102	2011-04-03 04:37:58.097781+00	289	2	f		1
102	2011-04-03 04:38:14.871998+00	291	2	f		2
102	2011-04-03 04:38:50.384267+00	294	2	f		3
102	2011-04-17 06:20:20.801989+00	496	1	f		4
102	2011-04-17 06:21:12.047716+00	497	1	t		5
168	2011-04-11 08:56:55.278151+00	452	2	f		1
168	2011-04-17 09:08:07.039429+00	500	1	t		2
101	2011-04-03 04:37:57.853573+00	288	2	f		1
101	2011-04-03 04:38:05.697717+00	290	2	f		2
101	2011-04-03 04:38:20.615309+00	292	2	f		3
101	2011-04-03 04:38:45.280606+00	293	2	f		4
101	2011-04-17 06:11:43.544967+00	486	1	f		5
101	2011-04-17 06:11:58.460373+00	487	1	t		6
183	2011-04-17 06:16:48.781073+00	491	1	t		1
182	2011-04-17 06:16:48.277087+00	490	1	f		1
182	2011-04-17 06:16:54.731889+00	492	1	f		2
182	2011-04-17 06:17:09.004625+00	493	1	f		3
182	2011-04-17 06:18:00.761319+00	494	1	f		4
182	2011-04-17 06:18:08.028311+00	495	1	t		5
184	2011-04-17 10:48:46.134018+00	504	1	f	PriorityQueue(9,8,7,6,5).pop() yields 9, not 5.  Need to heapify the initial list!	1
184	2011-04-18 05:10:12.298264+00	506	2	t	I fixed it to just call self.append(*args) in the init method.	2
196	2011-04-20 18:45:02.312566+00	533	22	f		1
196	2011-04-21 07:57:55.213402+00	565	13	t		2
186	2011-04-20 07:44:58.918889+00	515	1	t		1
185	2011-04-20 05:32:07.271716+00	512	9	f	Python's built-in `max` function is more general (accepts arbitrary Iterables) and efficient (doesn't copy the tail) than `maximum_by`. One way this could be "resolved" is by removing all dependencies on `maximum_by` (in other words, removing its reverse dependencies, which incidentally would be neat to have available on its page).	1
185	2011-04-20 07:46:52.79513+00	516	1	t	Only in python. I've added a Javascript snippet so that this spec still has a purpose :-).\n\nYou are talking about going through all snippets that depend on maximum_by and replacing the usage with the built-in max function?  That's interesting.  Mind making a UserVoice idea for that?	2
39	2011-03-26 11:31:24.876821+00	103	\N	f		1
39	2011-03-26 11:31:33.783723+00	104	1	f		2
39	2011-03-28 05:02:03.69578+00	120	\N	f		3
39	2011-04-06 05:56:14.12037+00	415	\N	f		4
39	2011-04-06 06:30:43.871351+00	416	\N	f		5
39	2011-05-05 07:34:24.814089+00	669	2	t		6
20	2011-03-26 09:21:01.182001+00	47	\N	f		1
20	2011-04-20 05:33:32.375186+00	514	9	t		2
133	2011-04-04 05:29:04.779944+00	350	\N	f		1
133	2011-04-04 05:29:24.387024+00	352	1	f		2
133	2011-04-04 05:29:36.086572+00	353	1	f		3
133	2011-04-04 05:30:53.317428+00	354	1	f		4
133	2011-04-28 06:17:34.889359+00	664	26	f		5
133	2011-04-28 07:01:11.385643+00	667	1	f		6
133	2011-04-28 07:01:28.055969+00	668	1	t		7
174	2011-04-17 02:57:26.662905+00	459	\N	f		1
19	2011-03-26 09:21:00.581838+00	46	\N	f		1
19	2011-03-26 09:21:12.172898+00	48	1	f		2
19	2011-03-26 09:21:35.277888+00	49	1	f		3
19	2011-03-26 09:23:26.949563+00	50	1	f		4
19	2011-04-20 05:32:20.154889+00	513	9	f		5
189	2011-04-20 10:44:03.789432+00	519	14	f		1
189	2011-04-22 15:40:44.850969+00	590	1	f		2
151	2011-04-06 04:45:15.179931+00	409	1	f		1
151	2011-04-06 04:46:16.393388+00	412	1	f		2
154	2011-04-09 17:21:34.321905+00	423	\N	f		1
164	2011-04-09 20:53:07.528643+00	437	\N	f		1
164	2011-04-09 20:53:15.093824+00	439	1	f		2
164	2011-04-09 20:53:49.749252+00	440	1	f		3
164	2011-04-09 21:36:56.318201+00	441	1	f		4
369	2011-06-07 07:34:25.150961+00	1014	1	f		2
373	2011-06-10 05:49:07.560993+00	1023	1	f		1
134	2011-04-04 05:29:05.166135+00	351	\N	f		1
134	2011-05-06 11:12:01.954268+00	679	1	t	Delegate straight to dependency	2
29	2011-03-26 09:56:40.571461+00	75	\N	f		1
29	2011-03-26 09:57:18.778775+00	77	1	f		2
29	2011-03-26 09:57:40.963775+00	78	1	f		3
29	2011-03-26 09:58:05.271512+00	80	1	f		4
29	2011-03-29 12:59:53.802619+00	184	2	f		5
29	2011-05-08 02:42:44.543642+00	688	1	t		6
147	2011-04-06 03:38:35.553427+00	394	\N	f		1
147	2011-04-06 03:38:46.019816+00	396	1	f		2
147	2011-04-06 03:39:58.809177+00	397	1	f		3
147	2011-04-06 03:46:04.732478+00	400	1	f		4
147	2011-04-06 03:47:45.276547+00	401	1	f		5
147	2011-04-06 03:59:48.8168+00	402	1	f		6
147	2011-04-06 04:01:21.285278+00	403	1	f		7
147	2011-04-06 04:12:09.993524+00	404	1	f		8
147	2011-04-06 04:20:43.192835+00	405	1	f		9
147	2011-05-08 02:56:30.191219+00	689	1	t		10
180	2011-04-17 05:47:54.712682+00	473	1	f		1
180	2011-04-17 05:48:59.115201+00	476	1	f		2
180	2011-04-17 05:49:46.954529+00	477	1	f		3
180	2011-04-17 05:52:36.915549+00	478	1	f		4
180	2011-04-17 05:54:18.870625+00	479	1	f		5
180	2011-04-17 05:54:41.663164+00	480	1	f		6
180	2011-04-17 09:04:52.982711+00	499	1	f		7
180	2011-04-20 01:45:41.803053+00	509	1	f		8
180	2011-05-08 05:14:01.935449+00	719	1	f		9
180	2011-05-08 05:22:43.846446+00	720	1	f	Added note about caching.	10
180	2011-05-08 05:24:02.483055+00	721	1	t	Wording	11
166	2011-04-09 21:52:07.293284+00	444	\N	f		1
166	2011-04-09 21:52:19.322204+00	446	1	f		2
166	2011-04-09 21:52:32.539475+00	447	1	f		3
166	2011-05-11 05:25:54.156883+00	760	2	t		4
167	2011-04-09 21:52:07.837881+00	445	\N	f		1
167	2011-04-09 21:53:18.102953+00	448	1	f		2
167	2011-04-09 22:17:42.912362+00	449	\N	f		3
167	2011-04-09 22:18:00.85055+00	450	1	f		4
167	2011-04-09 22:55:39.080155+00	451	1	f		5
167	2011-05-11 05:28:35.589902+00	761	2	t		6
69	2011-03-29 12:19:15.809422+00	171	2	f		1
69	2011-04-03 04:45:16.819966+00	298	2	f		2
69	2011-04-17 06:08:53.172029+00	485	1	f		3
69	2011-04-20 14:16:21.59206+00	529	17	t		4
192	2011-04-20 11:06:49.045612+00	522	1	f		1
192	2011-04-20 11:06:57.165174+00	524	1	f		2
192	2011-04-20 11:08:08.137481+00	525	1	t		3
193	2011-04-20 11:06:49.339242+00	523	1	t		1
197	2011-04-20 20:42:06.104081+00	539	\N	f	In order to enable reuse of this code, it should be written as a function from DataSet to unique.	1
197	2011-04-21 07:58:46.917603+00	566	13	t	I believe that should fix it	2
405	2011-06-30 07:46:50.608578+00	1107	1	f		2
33	2011-03-26 10:15:07.652577+00	86	\N	f		1
195	2011-04-20 14:31:54.182436+00	531	18	f		1
410	2011-07-09 13:38:35.661032+00	1117	1	f		1
261	2011-05-08 05:52:41.086435+00	732	1	t		1
258	2011-05-08 05:39:31.583722+00	723	1	f		1
258	2011-05-08 05:47:10.418448+00	727	1	f		2
258	2011-05-08 05:54:10.231303+00	733	1	t	Added the necessary dependencies	3
234	2011-04-24 08:07:10.079218+00	631	1	f		1
234	2011-04-24 08:07:56.996097+00	633	1	t		2
210	2011-04-21 19:44:57.14553+00	574	1	f	There is a note in simple_lowest_factor (www.codecatalog.net/202) that says this could be implemented as return simple_lowest_factor(n) == n.  If the performance is the same, I think a simpler implementation in terms of that function would be nicer.	1
210	2011-04-21 20:43:00.595078+00	576	13	t	I wrote both, and it's not that the performance isn't the same, it's that the assumptions are different. Note that that one allows for negative numbers. It all depends on what you're needing to do, and I think that clumping together methods unnecessarily defeats the purpose.	2
207	2011-04-21 07:38:29.861143+00	563	13	f		1
207	2011-04-21 19:36:22.173092+00	572	1	f		2
207	2011-04-21 20:52:33.080737+00	577	13	t		3
206	2011-04-21 07:38:29.614051+00	562	13	f		1
206	2011-04-21 19:33:47.072686+00	570	1	f		2
206	2011-04-21 19:34:26.823761+00	571	1	f		3
206	2011-04-21 19:36:50.388506+00	573	1	f		4
206	2011-04-21 20:53:46.119273+00	578	13	f		5
206	2011-04-21 20:54:27.302804+00	579	13	t		6
198	2011-04-20 21:06:38.639832+00	540	23	f		1
198	2011-04-20 21:08:44.419979+00	542	23	f		2
198	2011-04-20 21:09:26.811493+00	543	23	f		3
198	2011-04-24 20:19:22.630801+00	636	1	t		4
235	2011-04-24 08:07:10.33661+00	632	1	f		1
235	2011-04-24 08:20:12.926803+00	634	1	f		2
235	2011-04-24 08:20:36.587224+00	635	1	f		3
235	2011-04-25 04:27:03.691198+00	637	1	t		4
237	2011-04-27 07:30:46.521045+00	639	29	t		1
238	2011-04-27 07:30:46.810363+00	640	29	t		1
202	2011-04-20 22:28:53.173244+00	550	13	f		1
202	2011-04-20 22:35:17.650403+00	553	13	f		2
202	2011-04-20 22:36:06.996018+00	554	13	f		3
202	2011-04-27 20:02:10.042122+00	641	1	f		4
202	2011-04-27 20:02:36.784409+00	644	1	t		5
194	2011-04-20 14:31:53.91757+00	530	18	f		1
194	2011-04-21 02:30:48.834649+00	559	18	f		2
194	2011-04-21 02:31:42.877911+00	560	18	f		3
194	2011-04-22 09:08:05.641142+00	585	1	t		4
209	2011-04-21 18:23:19.27164+00	569	\N	f		1
209	2011-04-21 21:04:54.600144+00	581	24	f	Fixed. 	2
209	2011-04-22 10:39:06.696349+00	586	1	t		3
203	2011-04-20 22:28:53.48621+00	551	13	f		1
203	2011-04-20 22:33:39.152471+00	552	13	f		2
203	2011-04-27 20:02:51.252151+00	645	1	t		3
214	2011-04-22 15:39:13.978113+00	588	1	t		1
213	2011-04-22 15:39:13.511944+00	587	1	f		1
213	2011-04-22 15:39:30.750687+00	589	1	t		2
208	2011-04-21 07:55:48.570681+00	564	13	f		1
208	2011-04-22 16:13:39.680535+00	591	13	t		2
212	2011-04-22 09:03:09.083508+00	583	1	f	Is there a subtle difference or something?	1
266	2011-05-09 07:08:45.756614+00	750	2	f		1
266	2011-05-09 07:09:16.352445+00	752	1	f		2
266	2011-05-09 07:15:42.369606+00	754	1	f		3
236	2011-04-27 00:18:34.038185+00	638	1	f		1
334	2011-05-23 14:04:33.706808+00	903	29	t		1
190	2011-04-20 10:46:47.690629+00	520	14	f		1
190	2011-04-22 09:01:17.280509+00	582	1	f		2
337	2011-05-23 23:17:59.972505+00	913	1	f		1
189	2011-04-28 06:06:56.149001+00	663	26	f		3
189	2011-04-28 06:19:03.058302+00	665	26	f		4
340	2011-05-25 08:32:57.379168+00	923	1	t		1
346	2011-05-26 20:55:28.327969+00	933	1	t	Removed dependency	2
46	2011-03-29 05:37:07.381366+00	136	\N	f		1
46	2011-03-29 05:37:16.070159+00	138	1	f		2
46	2011-03-29 05:38:03.326452+00	139	1	f		3
46	2011-03-29 05:40:13.82832+00	140	1	f		4
46	2011-03-29 05:40:33.224266+00	141	1	f		5
191	2011-04-20 10:46:48.070764+00	521	14	f		1
212	2011-04-22 16:14:51.365131+00	592	13	t	You're right, I should have actually tried it out. I've accidentally generalized the idea that sets didn't exist until python3, haha.	2
187	2011-04-20 10:17:23.237792+00	517	13	f		1
187	2011-04-20 20:16:00.261124+00	536	13	f		2
187	2011-04-20 20:18:56.500934+00	538	13	f		3
187	2011-04-27 20:02:27.649241+00	643	1	f		4
187	2011-04-27 20:03:03.207527+00	646	1	f		5
187	2011-04-27 20:03:12.599757+00	647	1	t		6
188	2011-04-20 10:17:23.541475+00	518	13	f		1
188	2011-04-20 18:40:06.706618+00	532	22	f		2
188	2011-04-20 20:07:06.700221+00	534	13	f		3
188	2011-04-20 20:12:18.464255+00	535	13	f		4
188	2011-04-20 20:17:53.078554+00	537	13	f		5
188	2011-04-20 21:46:18.417136+00	545	13	f		6
188	2011-04-27 20:03:23.466653+00	648	1	t		7
200	2011-04-20 22:05:20.402124+00	546	13	f		1
200	2011-04-27 20:02:20.593782+00	642	1	f		2
200	2011-04-27 20:03:40.406625+00	649	1	f		3
200	2011-04-27 20:04:16.100412+00	650	1	t		4
216	2011-04-22 18:28:35.50839+00	598	1	t		1
215	2011-04-22 18:28:35.272176+00	597	1	f		1
215	2011-04-22 18:28:48.17922+00	599	1	t		2
262	2011-05-08 06:25:59.999686+00	734	1	f		1
262	2011-05-08 06:26:10.593658+00	736	1	f		2
262	2011-05-08 06:26:21.697838+00	737	1	f		3
262	2011-05-08 06:28:09.185938+00	738	1	f		4
262	2011-05-08 06:28:17.919398+00	739	1	t		5
204	2011-04-20 23:46:42.56505+00	557	24	f		1
204	2011-04-22 16:19:00.676917+00	593	28	f		2
204	2011-04-22 18:20:32.691626+00	596	1	f		3
204	2011-04-22 18:32:15.295559+00	601	1	t		4
217	2011-04-22 18:38:32.795977+00	602	1	t		1
218	2011-04-22 18:38:33.013671+00	603	1	t		1
219	2011-04-22 18:39:29.17312+00	604	1	t	j is supposed to be a random int between 0 and i, *inclusive*.  I don't know the semantics of Math.random well enough to verify this.	1
205	2011-04-20 23:46:42.862568+00	558	24	f		1
205	2011-04-21 07:18:20.81186+00	561	25	f		2
205	2011-04-21 21:04:17.416845+00	580	24	f		3
205	2011-04-22 16:19:51.465282+00	594	28	f		4
205	2011-04-22 18:13:59.271336+00	595	1	f		5
205	2011-04-22 18:31:17.257403+00	600	1	f		6
205	2011-04-22 18:40:29.642479+00	605	1	t		7
199	2011-04-20 21:06:39.007547+00	541	23	f		1
199	2011-04-20 21:09:47.056563+00	544	23	t		2
201	2011-04-20 22:05:20.728124+00	547	13	f		1
201	2011-04-20 22:11:44.596181+00	548	13	f		2
201	2011-04-20 22:17:55.720278+00	549	13	f		3
201	2011-04-20 22:41:18.400723+00	555	13	f		4
201	2011-04-27 20:05:47.843319+00	651	1	f		5
201	2011-04-27 20:06:18.033815+00	652	1	t		6
221	2011-04-23 03:21:36.550287+00	607	26	t		1
263	2011-05-08 06:26:03.790368+00	735	1	f		1
263	2011-05-08 06:30:16.789072+00	740	1	t	Added escape_html dependency	2
224	2011-04-23 03:53:29.746048+00	610	26	f		1
224	2011-04-23 04:01:07.185218+00	611	26	t		2
220	2011-04-23 02:46:44.891071+00	606	26	f		1
220	2011-04-23 18:10:42.6798+00	612	1	t		2
226	2011-04-23 19:29:36.121252+00	614	1	t		1
225	2011-04-23 19:29:35.779898+00	613	1	f		1
225	2011-04-23 19:30:27.524346+00	615	1	t		2
228	2011-04-23 19:34:16.896334+00	617	1	t		1
230	2011-04-23 19:47:18.749862+00	623	1	t		1
229	2011-04-23 19:47:18.502669+00	622	1	f		1
229	2011-04-23 19:48:14.492661+00	624	1	t		2
242	2011-04-27 20:47:38.392538+00	656	1	f		1
242	2011-04-27 20:47:52.206543+00	657	1	t		2
231	2011-04-23 19:54:02.549138+00	625	1	f		1
231	2011-04-23 19:56:18.272187+00	627	1	t		2
232	2011-04-23 19:54:02.801965+00	626	1	f		1
232	2011-04-23 20:01:30.09841+00	628	1	t		2
233	2011-04-23 23:37:40.20377+00	629	1	t		1
405	2011-06-30 07:47:08.2362+00	1108	1	f		3
409	2011-07-09 13:38:44.05589+00	1118	1	f		2
44	2011-03-29 05:22:51.929167+00	131	1	f		2
239	2011-04-27 20:46:46.607841+00	653	1	f		1
239	2011-04-27 20:52:52.912192+00	659	1	t		2
241	2011-04-27 20:47:38.178238+00	655	1	f		1
241	2011-04-27 20:50:57.736696+00	658	1	f		2
241	2011-04-27 20:56:18.93273+00	660	1	f		3
241	2011-04-27 20:56:43.738834+00	661	1	t		4
240	2011-04-27 20:46:46.82457+00	654	1	f		1
240	2011-04-27 21:56:02.091171+00	662	1	t		2
223	2011-04-23 03:22:36.902698+00	609	26	f		1
223	2011-04-28 06:28:45.143438+00	666	26	t		2
264	2011-05-08 06:56:51.241181+00	741	1	f		1
264	2011-05-08 06:56:58.458965+00	743	1	f		2
264	2011-05-08 06:57:11.413364+00	744	1	f		3
264	2011-05-08 07:00:28.775943+00	745	1	t		4
249	2011-05-08 03:25:40.838732+00	696	1	f		1
249	2011-05-08 03:25:51.102717+00	698	1	f		2
249	2011-05-08 03:26:32.046647+00	699	1	f		3
249	2011-05-08 03:30:49.107939+00	700	1	f		4
249	2011-05-08 03:31:39.37948+00	701	1	f	Added a note about dependencies.	5
249	2011-05-08 03:32:08.619233+00	702	1	f		6
249	2011-05-08 09:18:23.376707+00	747	1	f		7
249	2011-05-08 09:18:47.838774+00	748	1	f		8
249	2011-05-08 12:26:25.619545+00	749	1	t		9
190	2011-04-22 09:06:47.828196+00	584	1	f		3
245	2011-05-06 11:17:35.899666+00	680	1	f		1
245	2011-05-06 11:20:42.154771+00	682	1	t		2
246	2011-05-06 11:17:36.188884+00	681	1	f		1
246	2011-05-06 11:20:59.487874+00	683	1	t	forgot to return from the delegate	2
244	2011-05-05 08:50:00.687619+00	671	2	f	Initial post.	1
244	2011-05-05 08:52:03.406739+00	672	2	f	test	2
244	2011-05-05 08:53:31.684044+00	673	2	f	Not python	3
244	2011-05-05 09:32:29.049767+00	675	2	f	Fix for bug where you couldn't get the description	4
244	2011-05-06 05:30:39.620447+00	678	1	f	Fixed indentation	5
244	2011-05-06 11:22:40.98116+00	684	1	t	Refactored to use delegate_method.	6
243	2011-05-05 08:50:00.322845+00	670	2	f		1
243	2011-05-05 09:30:55.992778+00	674	2	f	Placeholder for testing	2
243	2011-05-05 09:40:42.610655+00	676	2	f	Clarity	3
243	2011-05-05 09:41:13.122246+00	677	2	f		4
243	2011-05-06 11:25:32.491567+00	685	1	t		5
44	2011-03-29 05:23:20.143216+00	132	1	f		3
227	2011-04-23 19:34:16.620394+00	616	1	f		1
44	2011-03-29 05:28:09.499344+00	133	1	f		4
44	2011-03-29 05:35:30.73131+00	135	1	f		5
268	2011-05-09 07:18:39.829375+00	756	1	t		1
190	2011-05-23 21:14:44.33799+00	904	1	t		4
338	2011-05-23 23:18:00.293569+00	914	1	t		1
341	2011-05-25 08:32:57.631814+00	924	1	t		1
345	2011-05-26 20:57:04.859588+00	934	1	f		3
46	2011-05-26 21:26:16.547282+00	943	1	t		6
62	2011-05-27 10:06:39.149019+00	952	1	f	Got rid of href (points nowhere)	11
222	2011-04-23 03:21:36.833886+00	608	26	f		1
47	2011-05-29 18:49:30.999984+00	961	38	t	formatting	3
351	2011-05-31 23:14:16.426375+00	970	1	f		2
266	2011-05-09 07:17:07.083579+00	755	1	f		4
266	2011-05-10 05:21:50.97262+00	757	1	t		5
248	2011-05-08 03:10:10.823773+00	691	1	f		1
248	2011-05-08 03:10:41.321028+00	692	1	t	Added elt dependency	2
269	2011-05-11 05:25:10.855866+00	758	2	t		1
247	2011-05-08 03:10:10.374445+00	690	1	f		1
247	2011-05-08 03:10:55.065004+00	693	1	f		2
247	2011-05-08 03:11:14.637146+00	694	1	f		3
247	2011-05-08 03:13:26.826966+00	695	1	t		4
250	2011-05-08 03:25:41.299871+00	697	1	t		1
270	2011-05-11 05:25:11.173554+00	759	2	t		1
271	2011-05-11 05:30:44.289735+00	762	2	t		1
252	2011-05-08 03:34:15.268154+00	704	1	t		1
251	2011-05-08 03:34:14.718678+00	703	1	f		1
251	2011-05-08 03:34:23.182168+00	705	1	f		2
251	2011-05-08 03:34:51.842938+00	706	1	f		3
251	2011-05-08 03:35:55.529144+00	707	1	t		4
253	2011-05-08 04:55:20.979584+00	708	1	f		1
253	2011-05-08 04:55:27.800262+00	710	1	f		2
253	2011-05-08 04:55:51.370494+00	711	1	f		3
253	2011-05-08 04:56:01.486478+00	712	1	t		4
256	2011-05-08 04:56:56.920298+00	715	1	t		1
255	2011-05-08 04:56:56.490124+00	714	1	f		1
255	2011-05-08 04:57:04.726202+00	716	1	f		2
255	2011-05-08 04:57:20.372085+00	717	1	t		3
181	2011-04-17 05:47:55.281466+00	474	1	f		1
181	2011-04-17 05:48:20.733295+00	475	1	f		2
181	2011-05-08 02:39:49.590283+00	687	1	f		3
181	2011-05-08 05:11:25.936377+00	718	1	t		4
257	2011-05-08 05:39:31.109935+00	722	1	f		1
257	2011-05-08 05:39:40.676768+00	724	1	f		2
257	2011-05-08 05:40:08.838958+00	725	1	f		3
257	2011-05-08 05:46:42.632335+00	726	1	t		4
274	2011-05-11 08:05:06.131265+00	768	2	f		1
274	2011-05-11 08:07:10.046908+00	771	2	t		2
260	2011-05-08 05:50:54.65855+00	729	1	t		1
259	2011-05-08 05:50:54.049341+00	728	1	f		1
259	2011-05-08 05:51:01.984854+00	730	1	f		2
259	2011-05-08 05:51:26.839074+00	731	1	t		3
276	2011-05-11 08:06:39.931365+00	770	2	f		1
276	2011-05-11 08:08:46.750691+00	772	2	f		2
276	2011-05-11 08:09:02.027357+00	773	2	t		3
265	2011-05-08 06:56:51.74474+00	742	1	f		1
265	2011-05-08 07:01:05.674266+00	746	1	f	Added dependencies	2
265	2011-05-11 05:32:15.827702+00	765	2	f		3
265	2011-05-11 05:33:10.897875+00	766	2	f		4
265	2011-05-11 08:20:48.959373+00	776	1	t	Indentation	5
277	2011-05-11 08:25:04.877535+00	777	1	f	Function appears to do nothing (other than execute `mods`) in IE.  Darn.	1
277	2011-05-11 08:26:43.322848+00	778	1	t	Version 8 specifically	2
275	2011-05-11 08:06:39.629588+00	769	2	f		1
275	2011-05-11 08:29:18.563634+00	779	1	t		2
273	2011-05-11 08:05:05.813926+00	767	2	f		1
273	2011-05-11 08:30:17.920985+00	780	1	t		2
278	2011-05-12 08:56:26.078962+00	781	2	t		1
279	2011-05-12 08:56:26.380105+00	782	2	t		1
282	2011-05-13 05:55:35.998348+00	785	1	t		1
283	2011-05-13 05:55:36.082368+00	786	1	t		1
280	2011-05-13 05:55:35.746043+00	783	1	f		1
280	2011-05-13 05:56:14.287709+00	787	1	t		2
286	2011-05-13 15:30:38.295457+00	792	1	t		1
285	2011-05-13 15:24:41.917996+00	791	1	f		1
285	2011-05-13 15:43:46.616844+00	793	1	t	Changed to alternate zipWith implementation.	2
284	2011-05-13 15:24:41.683564+00	790	1	f		1
284	2011-05-13 15:47:36.638581+00	794	1	t		2
315	2011-05-19 23:18:59.622549+00	858	1	t		1
287	2011-05-16 05:11:31.935889+00	810	2	t		2
318	2011-05-19 23:24:54.731152+00	866	1	t		2
351	2011-05-31 23:15:08.643714+00	971	1	t		3
322	2011-05-20 05:12:47.070549+00	874	1	f		2
360	2011-06-03 07:45:52.845984+00	995	1	f		3
326	2011-05-21 03:10:30.095288+00	882	1	t		1
356	2011-06-01 09:42:24.373199+00	979	1	f		2
254	2011-05-16 06:33:05.247122+00	818	1	f		6
254	2011-05-08 04:56:14.379296+00	713	1	f	Added elt dependency.	2
254	2011-05-08 04:55:21.675152+00	709	1	f		1
236	2011-05-23 02:16:45.490909+00	890	1	t	Fixed bug where xs[0] was never checked.	2
335	2011-05-23 22:39:17.957934+00	905	1	f		1
365	2011-06-07 04:22:34.773416+00	1005	1	t		4
267	2011-05-16 10:03:54.27005+00	826	2	t		4
307	2011-05-17 09:57:48.124677+00	834	29	f		2
337	2011-05-23 23:18:07.356873+00	915	1	f		2
302	2011-05-18 06:25:40.393864+00	842	2	t		3
272	2011-05-11 05:30:44.617415+00	763	2	f		1
272	2011-05-11 05:30:54.569097+00	764	2	f		2
272	2011-05-11 08:13:55.003032+00	774	2	f		3
272	2011-05-11 08:17:15.345297+00	775	1	f		4
342	2011-05-26 06:26:05.368752+00	925	29	t		1
312	2011-05-19 22:56:06.348972+00	850	1	f		1
358	2011-06-03 07:40:47.142465+00	987	1	f		1
345	2011-05-26 21:03:32.983146+00	935	1	t	Removed unsightly ticks	4
9	2011-05-27 07:20:28.313715+00	944	1	t		5
62	2011-05-27 10:07:05.790803+00	953	1	t		12
381	2011-06-11 10:38:27.645821+00	1040	1	t		1
43	2011-05-29 19:05:21.992599+00	962	38	t	Re-implemented using generator expressions	3
369	2011-06-07 07:34:52.006152+00	1015	1	f		3
369	2011-06-07 07:34:18.683287+00	1012	1	f		1
395	2011-06-22 11:52:41.113178+00	1083	29	f	Note that Haskell lists are not heterogeneous.	1
379	2011-06-11 10:47:23.961404+00	1048	1	f		2
281	2011-05-13 05:55:35.816594+00	784	1	f		1
281	2011-05-13 05:57:14.526832+00	788	1	f		2
281	2011-05-13 05:58:03.580552+00	789	1	f		3
374	2011-06-10 05:49:07.894586+00	1024	1	t		1
387	2011-06-14 08:20:31.503583+00	1055	1	t		1
378	2011-06-11 10:19:17.112548+00	1032	1	f		1
393	2011-06-18 21:02:21.29017+00	1076	1	f		2
390	2011-06-18 18:49:08.486571+00	1069	1	f		2
388	2011-06-14 21:01:45.099838+00	1062	1	f		3
403	2011-06-28 06:23:32.095671+00	1097	2	f		1
398	2011-06-28 03:53:28.621423+00	1090	2	t		1
406	2011-06-30 07:48:10.658694+00	1109	1	t	Fixed dependencies	2
409	2011-07-09 13:39:08.440662+00	1119	1	f		3
44	2011-07-09 13:54:38.371831+00	1127	1	t		6
415	2011-07-13 07:20:59.717729+00	1135	2	t		1
294	2011-05-16 05:10:02.51566+00	802	2	f		1
417	2011-07-19 05:21:04.161575+00	1143	46	t		1
421	2011-07-20 06:47:52.263373+00	1151	2	f		1
431	2011-07-20 07:39:42.378356+00	1159	2	t		2
435	2011-08-29 09:49:40.95412+00	1167	49	t	nana	1
\.


--
-- Data for Name: zoo_versionptr; Type: TABLE DATA; Schema: public; Owner: codecatalog
--

COPY zoo_versionptr (id, type) FROM stdin;
51	0
52	0
53	0
54	0
55	0
56	0
57	0
58	0
59	0
60	0
61	0
2	1
3	0
4	1
5	0
6	1
7	0
8	1
10	1
11	0
12	1
13	0
15	0
16	1
17	0
18	1
21	0
22	1
23	0
24	1
28	1
31	0
32	1
34	0
35	1
36	0
37	1
38	0
40	0
41	1
45	1
50	2
63	1
64	0
66	1
67	2
68	0
70	2
72	0
74	1
75	0
77	2
79	1
81	1
82	0
83	1
85	1
86	0
87	1
88	0
89	1
90	0
91	1
92	0
93	1
96	0
97	1
98	0
99	1
100	0
103	0
104	1
105	0
107	0
108	1
109	0
110	1
111	0
112	1
113	0
114	1
116	0
117	0
118	1
119	0
120	1
121	0
122	1
123	0
124	1
26	1
126	1
125	0
137	0
106	1
127	0
128	1
139	0
130	1
129	0
131	0
132	1
146	1
140	1
135	0
76	1
136	1
142	1
153	0
145	0
141	0
150	1
144	1
149	0
143	0
80	0
78	0
152	1
155	0
148	1
156	0
157	0
159	1
160	0
161	1
162	0
163	1
165	1
14	1
169	1
172	0
171	1
170	0
65	0
173	1
175	1
176	0
177	1
178	0
179	1
138	1
71	2
49	1
102	1
168	0
101	0
183	1
182	0
184	2
196	1
186	1
185	2
39	1
20	1
133	0
46	0
134	1
29	0
147	0
180	0
166	0
167	1
158	0
174	0
19	0
189	1
9	0
1	0
94	0
115	0
48	0
25	0
84	0
62	0
151	0
42	0
154	1
95	1
43	1
47	1
73	0
164	0
393	0
27	0
396	1
33	1
69	1
192	0
193	1
197	2
261	1
258	1
234	0
315	1
210	2
207	1
206	0
198	0
235	1
237	0
238	1
300	1
202	0
336	1
194	0
209	2
203	1
214	1
213	0
208	1
212	2
297	0
187	0
188	1
287	0
200	0
216	1
215	0
262	0
204	0
217	0
218	1
219	2
205	1
199	1
201	1
221	0
191	1
263	1
224	1
220	1
226	1
225	0
228	1
291	0
295	0
230	1
229	0
242	1
289	0
231	0
232	1
233	1
394	1
239	0
299	0
241	0
240	1
223	1
264	0
314	0
332	0
249	0
254	1
317	1
316	0
245	0
246	1
244	1
243	0
222	1
308	0
268	1
266	0
248	1
269	0
247	0
250	1
270	1
271	0
252	1
236	1
251	0
267	1
253	0
304	2
256	1
255	0
181	1
305	2
257	0
211	2
274	1
260	1
259	0
276	1
319	1
318	0
265	1
277	2
275	0
273	0
278	0
279	1
329	2
282	1
283	1
280	0
281	0
321	1
286	1
285	1
284	0
288	1
320	0
290	1
292	1
293	0
296	1
298	1
227	0
334	1
307	1
306	0
323	1
302	0
322	0
195	1
309	1
303	1
272	1
190	0
313	1
325	1
312	0
311	1
310	0
330	0
324	0
326	1
335	0
333	1
328	1
327	0
379	0
338	1
337	0
395	1
339	2
340	0
341	1
342	1
397	1
30	1
344	1
343	0
398	0
346	1
399	1
345	0
400	0
348	1
347	0
350	1
349	0
352	1
351	0
353	1
355	1
354	0
356	0
357	1
359	1
358	0
401	1
361	1
402	0
403	1
360	0
362	0
363	1
364	1
331	1
404	2
365	0
366	1
368	1
367	0
370	1
406	1
405	0
369	0
372	1
371	0
374	1
408	1
373	0
376	1
375	0
378	1
377	0
381	1
383	1
407	0
382	0
411	0
380	0
412	1
385	1
409	0
387	1
44	0
386	0
384	0
410	1
413	1
389	1
414	0
388	0
391	1
415	0
390	0
392	1
301	2
417	1
294	1
418	0
420	0
422	0
423	1
421	1
424	0
425	0
426	0
427	0
428	0
429	0
430	0
419	1
431	0
432	0
433	0
416	0
434	0
435	1
\.


--
-- Name: auth_group_name_key; Type: CONSTRAINT; Schema: public; Owner: codecatalog; Tablespace: 
--

ALTER TABLE ONLY auth_group
    ADD CONSTRAINT auth_group_name_key UNIQUE (name);


--
-- Name: auth_group_permissions_group_id_key; Type: CONSTRAINT; Schema: public; Owner: codecatalog; Tablespace: 
--

ALTER TABLE ONLY auth_group_permissions
    ADD CONSTRAINT auth_group_permissions_group_id_key UNIQUE (group_id, permission_id);


--
-- Name: auth_group_permissions_pkey; Type: CONSTRAINT; Schema: public; Owner: codecatalog; Tablespace: 
--

ALTER TABLE ONLY auth_group_permissions
    ADD CONSTRAINT auth_group_permissions_pkey PRIMARY KEY (id);


--
-- Name: auth_group_pkey; Type: CONSTRAINT; Schema: public; Owner: codecatalog; Tablespace: 
--

ALTER TABLE ONLY auth_group
    ADD CONSTRAINT auth_group_pkey PRIMARY KEY (id);


--
-- Name: auth_message_pkey; Type: CONSTRAINT; Schema: public; Owner: codecatalog; Tablespace: 
--

ALTER TABLE ONLY auth_message
    ADD CONSTRAINT auth_message_pkey PRIMARY KEY (id);


--
-- Name: auth_permission_content_type_id_key; Type: CONSTRAINT; Schema: public; Owner: codecatalog; Tablespace: 
--

ALTER TABLE ONLY auth_permission
    ADD CONSTRAINT auth_permission_content_type_id_key UNIQUE (content_type_id, codename);


--
-- Name: auth_permission_pkey; Type: CONSTRAINT; Schema: public; Owner: codecatalog; Tablespace: 
--

ALTER TABLE ONLY auth_permission
    ADD CONSTRAINT auth_permission_pkey PRIMARY KEY (id);


--
-- Name: auth_user_groups_pkey; Type: CONSTRAINT; Schema: public; Owner: codecatalog; Tablespace: 
--

ALTER TABLE ONLY auth_user_groups
    ADD CONSTRAINT auth_user_groups_pkey PRIMARY KEY (id);


--
-- Name: auth_user_groups_user_id_key; Type: CONSTRAINT; Schema: public; Owner: codecatalog; Tablespace: 
--

ALTER TABLE ONLY auth_user_groups
    ADD CONSTRAINT auth_user_groups_user_id_key UNIQUE (user_id, group_id);


--
-- Name: auth_user_pkey; Type: CONSTRAINT; Schema: public; Owner: codecatalog; Tablespace: 
--

ALTER TABLE ONLY auth_user
    ADD CONSTRAINT auth_user_pkey PRIMARY KEY (id);


--
-- Name: auth_user_user_permissions_pkey; Type: CONSTRAINT; Schema: public; Owner: codecatalog; Tablespace: 
--

ALTER TABLE ONLY auth_user_user_permissions
    ADD CONSTRAINT auth_user_user_permissions_pkey PRIMARY KEY (id);


--
-- Name: auth_user_user_permissions_user_id_key; Type: CONSTRAINT; Schema: public; Owner: codecatalog; Tablespace: 
--

ALTER TABLE ONLY auth_user_user_permissions
    ADD CONSTRAINT auth_user_user_permissions_user_id_key UNIQUE (user_id, permission_id);


--
-- Name: auth_user_username_key; Type: CONSTRAINT; Schema: public; Owner: codecatalog; Tablespace: 
--

ALTER TABLE ONLY auth_user
    ADD CONSTRAINT auth_user_username_key UNIQUE (username);


--
-- Name: django_content_type_app_label_key; Type: CONSTRAINT; Schema: public; Owner: codecatalog; Tablespace: 
--

ALTER TABLE ONLY django_content_type
    ADD CONSTRAINT django_content_type_app_label_key UNIQUE (app_label, model);


--
-- Name: django_content_type_pkey; Type: CONSTRAINT; Schema: public; Owner: codecatalog; Tablespace: 
--

ALTER TABLE ONLY django_content_type
    ADD CONSTRAINT django_content_type_pkey PRIMARY KEY (id);


--
-- Name: django_openid_auth_association_pkey; Type: CONSTRAINT; Schema: public; Owner: codecatalog; Tablespace: 
--

ALTER TABLE ONLY django_openid_auth_association
    ADD CONSTRAINT django_openid_auth_association_pkey PRIMARY KEY (id);


--
-- Name: django_openid_auth_nonce_pkey; Type: CONSTRAINT; Schema: public; Owner: codecatalog; Tablespace: 
--

ALTER TABLE ONLY django_openid_auth_nonce
    ADD CONSTRAINT django_openid_auth_nonce_pkey PRIMARY KEY (id);


--
-- Name: django_openid_auth_useropenid_claimed_id_key; Type: CONSTRAINT; Schema: public; Owner: codecatalog; Tablespace: 
--

ALTER TABLE ONLY django_openid_auth_useropenid
    ADD CONSTRAINT django_openid_auth_useropenid_claimed_id_key UNIQUE (claimed_id);


--
-- Name: django_openid_auth_useropenid_pkey; Type: CONSTRAINT; Schema: public; Owner: codecatalog; Tablespace: 
--

ALTER TABLE ONLY django_openid_auth_useropenid
    ADD CONSTRAINT django_openid_auth_useropenid_pkey PRIMARY KEY (id);


--
-- Name: django_session_pkey; Type: CONSTRAINT; Schema: public; Owner: codecatalog; Tablespace: 
--

ALTER TABLE ONLY django_session
    ADD CONSTRAINT django_session_pkey PRIMARY KEY (session_key);


--
-- Name: django_site_pkey; Type: CONSTRAINT; Schema: public; Owner: codecatalog; Tablespace: 
--

ALTER TABLE ONLY django_site
    ADD CONSTRAINT django_site_pkey PRIMARY KEY (id);


--
-- Name: south_migrationhistory_pkey; Type: CONSTRAINT; Schema: public; Owner: codecatalog; Tablespace: 
--

ALTER TABLE ONLY south_migrationhistory
    ADD CONSTRAINT south_migrationhistory_pkey PRIMARY KEY (id);


--
-- Name: zoo_bugreport_pkey; Type: CONSTRAINT; Schema: public; Owner: codecatalog; Tablespace: 
--

ALTER TABLE ONLY zoo_bugreport
    ADD CONSTRAINT zoo_bugreport_pkey PRIMARY KEY (version_id);


--
-- Name: zoo_dependency_pkey; Type: CONSTRAINT; Schema: public; Owner: codecatalog; Tablespace: 
--

ALTER TABLE ONLY zoo_dependency
    ADD CONSTRAINT zoo_dependency_pkey PRIMARY KEY (id);


--
-- Name: zoo_following_pkey; Type: CONSTRAINT; Schema: public; Owner: codecatalog; Tablespace: 
--

ALTER TABLE ONLY zoo_following
    ADD CONSTRAINT zoo_following_pkey PRIMARY KEY (id);


--
-- Name: zoo_snippet_pkey; Type: CONSTRAINT; Schema: public; Owner: codecatalog; Tablespace: 
--

ALTER TABLE ONLY zoo_snippet
    ADD CONSTRAINT zoo_snippet_pkey PRIMARY KEY (version_id);


--
-- Name: zoo_spec_pkey; Type: CONSTRAINT; Schema: public; Owner: codecatalog; Tablespace: 
--

ALTER TABLE ONLY zoo_spec
    ADD CONSTRAINT zoo_spec_pkey PRIMARY KEY (version_id);


--
-- Name: zoo_version_pkey; Type: CONSTRAINT; Schema: public; Owner: codecatalog; Tablespace: 
--

ALTER TABLE ONLY zoo_version
    ADD CONSTRAINT zoo_version_pkey PRIMARY KEY (id);


--
-- Name: zoo_version_versionptr_id_10278c2394c68629_uniq; Type: CONSTRAINT; Schema: public; Owner: codecatalog; Tablespace: 
--

ALTER TABLE ONLY zoo_version
    ADD CONSTRAINT zoo_version_versionptr_id_10278c2394c68629_uniq UNIQUE (versionptr_id, serial);


--
-- Name: zoo_versionptr_pkey; Type: CONSTRAINT; Schema: public; Owner: codecatalog; Tablespace: 
--

ALTER TABLE ONLY zoo_versionptr
    ADD CONSTRAINT zoo_versionptr_pkey PRIMARY KEY (id);


--
-- Name: auth_group_permissions_group_id; Type: INDEX; Schema: public; Owner: codecatalog; Tablespace: 
--

CREATE INDEX auth_group_permissions_group_id ON auth_group_permissions USING btree (group_id);


--
-- Name: auth_group_permissions_permission_id; Type: INDEX; Schema: public; Owner: codecatalog; Tablespace: 
--

CREATE INDEX auth_group_permissions_permission_id ON auth_group_permissions USING btree (permission_id);


--
-- Name: auth_message_user_id; Type: INDEX; Schema: public; Owner: codecatalog; Tablespace: 
--

CREATE INDEX auth_message_user_id ON auth_message USING btree (user_id);


--
-- Name: auth_permission_content_type_id; Type: INDEX; Schema: public; Owner: codecatalog; Tablespace: 
--

CREATE INDEX auth_permission_content_type_id ON auth_permission USING btree (content_type_id);


--
-- Name: auth_user_groups_group_id; Type: INDEX; Schema: public; Owner: codecatalog; Tablespace: 
--

CREATE INDEX auth_user_groups_group_id ON auth_user_groups USING btree (group_id);


--
-- Name: auth_user_groups_user_id; Type: INDEX; Schema: public; Owner: codecatalog; Tablespace: 
--

CREATE INDEX auth_user_groups_user_id ON auth_user_groups USING btree (user_id);


--
-- Name: auth_user_user_permissions_permission_id; Type: INDEX; Schema: public; Owner: codecatalog; Tablespace: 
--

CREATE INDEX auth_user_user_permissions_permission_id ON auth_user_user_permissions USING btree (permission_id);


--
-- Name: auth_user_user_permissions_user_id; Type: INDEX; Schema: public; Owner: codecatalog; Tablespace: 
--

CREATE INDEX auth_user_user_permissions_user_id ON auth_user_user_permissions USING btree (user_id);


--
-- Name: django_openid_auth_useropenid_user_id; Type: INDEX; Schema: public; Owner: codecatalog; Tablespace: 
--

CREATE INDEX django_openid_auth_useropenid_user_id ON django_openid_auth_useropenid USING btree (user_id);


--
-- Name: zoo_bugreport_target_versionptr_id; Type: INDEX; Schema: public; Owner: codecatalog; Tablespace: 
--

CREATE INDEX zoo_bugreport_target_versionptr_id ON zoo_bugreport USING btree (target_versionptr_id);


--
-- Name: zoo_dependency_snippet_id; Type: INDEX; Schema: public; Owner: codecatalog; Tablespace: 
--

CREATE INDEX zoo_dependency_snippet_id ON zoo_dependency USING btree (snippet_id);


--
-- Name: zoo_dependency_target_id; Type: INDEX; Schema: public; Owner: codecatalog; Tablespace: 
--

CREATE INDEX zoo_dependency_target_id ON zoo_dependency USING btree (target_id);


--
-- Name: zoo_following_followed_id; Type: INDEX; Schema: public; Owner: codecatalog; Tablespace: 
--

CREATE INDEX zoo_following_followed_id ON zoo_following USING btree (followed_id);


--
-- Name: zoo_following_follower_id; Type: INDEX; Schema: public; Owner: codecatalog; Tablespace: 
--

CREATE INDEX zoo_following_follower_id ON zoo_following USING btree (follower_id);


--
-- Name: zoo_snippet_spec_versionptr_id; Type: INDEX; Schema: public; Owner: codecatalog; Tablespace: 
--

CREATE INDEX zoo_snippet_spec_versionptr_id ON zoo_snippet USING btree (spec_versionptr_id);


--
-- Name: zoo_version_user_id; Type: INDEX; Schema: public; Owner: codecatalog; Tablespace: 
--

CREATE INDEX zoo_version_user_id ON zoo_version USING btree (user_id);


--
-- Name: zoo_version_versionptr_id; Type: INDEX; Schema: public; Owner: codecatalog; Tablespace: 
--

CREATE INDEX zoo_version_versionptr_id ON zoo_version USING btree (versionptr_id);


--
-- Name: auth_group_permissions_permission_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: codecatalog
--

ALTER TABLE ONLY auth_group_permissions
    ADD CONSTRAINT auth_group_permissions_permission_id_fkey FOREIGN KEY (permission_id) REFERENCES auth_permission(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: auth_message_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: codecatalog
--

ALTER TABLE ONLY auth_message
    ADD CONSTRAINT auth_message_user_id_fkey FOREIGN KEY (user_id) REFERENCES auth_user(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: auth_user_groups_group_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: codecatalog
--

ALTER TABLE ONLY auth_user_groups
    ADD CONSTRAINT auth_user_groups_group_id_fkey FOREIGN KEY (group_id) REFERENCES auth_group(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: auth_user_user_permissions_permission_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: codecatalog
--

ALTER TABLE ONLY auth_user_user_permissions
    ADD CONSTRAINT auth_user_user_permissions_permission_id_fkey FOREIGN KEY (permission_id) REFERENCES auth_permission(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: content_type_id_refs_id_728de91f; Type: FK CONSTRAINT; Schema: public; Owner: codecatalog
--

ALTER TABLE ONLY auth_permission
    ADD CONSTRAINT content_type_id_refs_id_728de91f FOREIGN KEY (content_type_id) REFERENCES django_content_type(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: django_openid_auth_useropenid_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: codecatalog
--

ALTER TABLE ONLY django_openid_auth_useropenid
    ADD CONSTRAINT django_openid_auth_useropenid_user_id_fkey FOREIGN KEY (user_id) REFERENCES auth_user(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: followed_id_refs_id_2387961b; Type: FK CONSTRAINT; Schema: public; Owner: codecatalog
--

ALTER TABLE ONLY zoo_following
    ADD CONSTRAINT followed_id_refs_id_2387961b FOREIGN KEY (followed_id) REFERENCES zoo_versionptr(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: follower_id_refs_id_46e930cd; Type: FK CONSTRAINT; Schema: public; Owner: codecatalog
--

ALTER TABLE ONLY zoo_following
    ADD CONSTRAINT follower_id_refs_id_46e930cd FOREIGN KEY (follower_id) REFERENCES auth_user(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: group_id_refs_id_3cea63fe; Type: FK CONSTRAINT; Schema: public; Owner: codecatalog
--

ALTER TABLE ONLY auth_group_permissions
    ADD CONSTRAINT group_id_refs_id_3cea63fe FOREIGN KEY (group_id) REFERENCES auth_group(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: snippet_id_refs_version_id_5f7a5a22; Type: FK CONSTRAINT; Schema: public; Owner: codecatalog
--

ALTER TABLE ONLY zoo_dependency
    ADD CONSTRAINT snippet_id_refs_version_id_5f7a5a22 FOREIGN KEY (snippet_id) REFERENCES zoo_snippet(version_id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: spec_versionptr_id_refs_id_65d62591; Type: FK CONSTRAINT; Schema: public; Owner: codecatalog
--

ALTER TABLE ONLY zoo_snippet
    ADD CONSTRAINT spec_versionptr_id_refs_id_65d62591 FOREIGN KEY (spec_versionptr_id) REFERENCES zoo_versionptr(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: target_id_refs_id_6ed6a4a0; Type: FK CONSTRAINT; Schema: public; Owner: codecatalog
--

ALTER TABLE ONLY zoo_dependency
    ADD CONSTRAINT target_id_refs_id_6ed6a4a0 FOREIGN KEY (target_id) REFERENCES zoo_versionptr(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: target_versionptr_id_refs_id_6f52b19a; Type: FK CONSTRAINT; Schema: public; Owner: codecatalog
--

ALTER TABLE ONLY zoo_bugreport
    ADD CONSTRAINT target_versionptr_id_refs_id_6f52b19a FOREIGN KEY (target_versionptr_id) REFERENCES zoo_versionptr(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: user_id_refs_id_34e7696; Type: FK CONSTRAINT; Schema: public; Owner: codecatalog
--

ALTER TABLE ONLY zoo_version
    ADD CONSTRAINT user_id_refs_id_34e7696 FOREIGN KEY (user_id) REFERENCES auth_user(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: user_id_refs_id_7ceef80f; Type: FK CONSTRAINT; Schema: public; Owner: codecatalog
--

ALTER TABLE ONLY auth_user_groups
    ADD CONSTRAINT user_id_refs_id_7ceef80f FOREIGN KEY (user_id) REFERENCES auth_user(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: user_id_refs_id_dfbab7d; Type: FK CONSTRAINT; Schema: public; Owner: codecatalog
--

ALTER TABLE ONLY auth_user_user_permissions
    ADD CONSTRAINT user_id_refs_id_dfbab7d FOREIGN KEY (user_id) REFERENCES auth_user(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: version_id_refs_id_2ff487dd; Type: FK CONSTRAINT; Schema: public; Owner: codecatalog
--

ALTER TABLE ONLY zoo_bugreport
    ADD CONSTRAINT version_id_refs_id_2ff487dd FOREIGN KEY (version_id) REFERENCES zoo_version(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: version_id_refs_id_6c35212c; Type: FK CONSTRAINT; Schema: public; Owner: codecatalog
--

ALTER TABLE ONLY zoo_snippet
    ADD CONSTRAINT version_id_refs_id_6c35212c FOREIGN KEY (version_id) REFERENCES zoo_version(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: version_id_refs_id_784c282b; Type: FK CONSTRAINT; Schema: public; Owner: codecatalog
--

ALTER TABLE ONLY zoo_spec
    ADD CONSTRAINT version_id_refs_id_784c282b FOREIGN KEY (version_id) REFERENCES zoo_version(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: versionptr_id_refs_id_45545734; Type: FK CONSTRAINT; Schema: public; Owner: codecatalog
--

ALTER TABLE ONLY zoo_version
    ADD CONSTRAINT versionptr_id_refs_id_45545734 FOREIGN KEY (versionptr_id) REFERENCES zoo_versionptr(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: public; Type: ACL; Schema: -; Owner: postgres
--

REVOKE ALL ON SCHEMA public FROM PUBLIC;
REVOKE ALL ON SCHEMA public FROM postgres;
GRANT ALL ON SCHEMA public TO postgres;
GRANT ALL ON SCHEMA public TO PUBLIC;


--
-- PostgreSQL database dump complete
--

